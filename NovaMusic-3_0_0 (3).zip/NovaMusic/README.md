# NovaMusic 3.0.0 — Galaxy Evolution

Project native Android (Kotlin + Jetpack Compose + Media3 ExoPlayer). Memutar lagu lokal dari perangkat.

## Cara jadi APK
1. Buka folder ini di **Android Studio** (Ladybug / 2024.2 atau lebih baru). Biarkan Gradle sync selesai.
2. Debug APK: menu **Build > Build APK(s)**. Hasil: `app/build/outputs/apk/debug/app-debug.apk`.
   Atau lewat terminal: `./gradlew assembleDebug`
3. Release APK: **Build > Generate Signed Bundle / APK**.

## Fitur
- Pemutaran di latar belakang + notifikasi media + kontrol layar kunci (MediaSession)
- Beranda: sapaan, acak/putar semua, terakhir diputar, baru ditambahkan, favorit
- Library: tab Lagu (urut judul/artis/terbaru/durasi), Album, Artis
- Pencarian judul/artis/album
- Playlist buatan sendiri + Favorit (tersimpan)
- Mini player + layar Now Playing (cover art, seek, shuffle, repeat)
- Antrean (putar berikutnya, tambah ke antrean, lompat ke lagu)
- Kecepatan putar, timer tidur, equalizer dengan preset
- Dua gaya UI yang bisa ditukar di Setting: **Glassmorphism** dan **Neobrutalism** (pratinjau langsung)
- Tema gelap/terang/sistem, 6 warna aksen, slider transparansi, border, hard shadow, kelengkungan, ukuran teks
- Setting lengkap: beranda, daftar rapat, bentuk cover, lanjutkan antrean, lewati hening, filter durasi, urutan bawaan, ekspor/impor cadangan, reset
- **Import Spotify**: dari tautan playlist publik, tempel teks, atau CSV (Exportify), lalu dicocokkan dengan lagu di perangkat

## Struktur
- `data/` — model Song, baca MediaStore, penyimpanan favorit/playlist
- `player/` — PlaybackService dan MusicViewModel (semua logika player)
- `ui/` — komponen, layar, Now Playing, MainScreen
- Ganti nama app: `res/values/strings.xml`. Ganti package/applicationId: `app/build.gradle.kts`.

## Ide pengembangan
Lirik, streaming online (Retrofit + API), widget, tema kustom, visualizer, Android Auto.

## Import seluruh lagu Spotify
Untuk mengimpor seluruh daftar lagu, gunakan jalur CSV:
1. Buka playlist Spotify melalui layanan ekspor CSV seperti Exportify (`https://exportify.net`) dan ikuti proses ekspornya.
2. Simpan hasil ekspor sebagai file `.csv` di perangkat.
3. Buka NovaMusic → Playlist → Import dari Spotify → File CSV → pilih file tadi.
4. Periksa jumlah lagu yang terbaca pada layar pratinjau, lalu pilih **Simpan di Playlist Spotify**.
5. Untuk membuat playlist yang langsung bisa diputar di NovaMusic, pilih **Buat playlist dari yang cocok**. Lagu harus sudah tersedia sebagai file audio lokal di perangkat.

Catatan:
- Import dari tautan Spotify publik menggunakan halaman embed dan dapat hanya mengembalikan sebagian lagu. Gunakan CSV untuk playlist panjang.
- CSV menyimpan metadata lagu (judul, artis, durasi, dan URI), bukan file audio Spotify. NovaMusic adalah pemutar file lokal; lagu Spotify tidak dapat diunduh atau diputar langsung dari metadata karena perlindungan/ketentuan Spotify.
- Jika jumlah pada pratinjau lebih sedikit daripada jumlah lagu di Spotify, pastikan ekspor CSV-nya lengkap lalu impor ulang.


## NovaMusic 2.0 — Galaxy Edition

### Pembaruan 2.0
- Auto Synced Lyrics: aplikasi mencari lirik berdasarkan judul, artis, album, dan durasi lagu melalui LRCLIB.
- Lirik bertimestamp mengikuti posisi pemutaran; baris aktif disorot di layar Now Playing dan lembar Lirik.
- Cache lirik lokal agar lagu yang sama tidak perlu selalu meminta data jaringan.
- Jika lirik bertimestamp tidak tersedia, aplikasi menampilkan lirik biasa bila tersedia. Ketersediaan lirik bergantung pada katalog penyedia.
- Tetap mendukung lirik manual yang disimpan lokal.
- Versi aplikasi dinaikkan menjadi 2.0 (versionCode 20).
- Workflow GitHub Actions mencari `settings.gradle.kts` atau `settings.gradle` sehingga dapat membangun project dari root maupun subfolder.

### Catatan Auto Lyrics
Auto Lyrics memerlukan koneksi internet saat pertama kali mencari lirik. Lirik tersinkron hanya dapat mengikuti lagu jika penyedia menyediakan timestamp LRC. Lagu instrumental, lagu yang belum tersedia di katalog, atau hasil tanpa timestamp tidak dapat menampilkan highlight per baris.

Sumber metadata lirik: [LRCLIB API documentation](https://lrclib.net/docs).


## Redesign visual 3.0.0 (UI saja, logic tidak berubah)
- **Logo baru**: bintang-orbit oranye (ikon peluncur adaptif + monokrom, splash, About, cover placeholder, ikon notifikasi).
- **Identitas**: dark premium `#050505`, aksen gradient `#FF9A1F → #F26A00`, palet **Nova** jadi bawaan (palet lama tetap ada).
- **Glassmorphism**: permukaan lebih jernih, garis tepi 10%, glow aksen halus, tombol utama bergradien + glow.
- **Typography & spacing**: tipografi Material dikustom (judul rapat, label renggang), tombol 46dp.
- **Cover placeholder**: gradient mesh gelap dengan logo Nova (Library, Album Lokal, MiniPlayer).
- **Splash**: animasi logo + glow (menggantikan video `loading.mp4`).
- **Tahap 2:** Beranda baru (header logo + wordmark, kartu statistik tunggal, ubin fitur berlencana ikon), Now Playing (cover kaca dengan glow, tombol putar bercahaya, header minimalis), Pengaturan (lencana ikon per grup, kartu Tentang berlogo), ikon navigasi bergaya outline, transisi tab dan Now Playing lebih halus.
- **Tahap 3:** Library (kontrol segmen kaca, kartu album berpanel, avatar artis bercincin gradien), Cari (keadaan kosong berilustrasi logo), Playlist (kartu berlencana gradien + panah, tombol tambah berlencana), dan halaman Detail (hero dengan cover besar di atas gradien aksen).
- Liquid Glass Navigation tidak diubah.

## Fitur dari 2.x
- **Loading screen video** (res/raw/loading.mp4): layar penuh, tanpa suara, memudar saat aplikasi siap.
- **Lirik**: otomatis dari LRCLIB (cache offline berbasis file), tersinkron, baris aktif disorot, auto-scroll halus, ketuk baris untuk melompat, terjemahan (cache offline), lirik buatan sendiri (format LRC didukung).
- **Latar kustom**: foto, video (loop, volume), blur, kegelapan, parallax (sensor kemiringan), latar album, warna dinamis dari cover, Studio Tema (warna sendiri), 4 desain pemutar, efek animasi, ikon aplikasi alternatif.
- **Statistik**: total waktu dengar, top 10 lagu/artis/album, aktivitas mingguan & bulanan, riwayat putar.
- **Spotify Import 2.0**: tautan / tempel teks / CSV, terima tautan lewat menu Bagikan Spotify, pencocokan manual, bagikan daftar yang belum ada, perbarui semua.
- **Audio & pemutar pintar**: crossfade sungguhan (tumpang tindih), gapless, fade in/out, equalizer tersimpan, timer tidur (+ akhir lagu, meredup), kecepatan, gestur, antrean pintar, urut ulang antrean, deteksi headset.
- **Library pintar**: generator playlist (lokal), playlist mood (perkiraan), duplikat, perbaikan metadata, folder pemindaian, timeline, artis favorit, pengingat musik harian, backup/restore (termasuk statistik).
- **About**: tampilan minimalis "rkaa". Foto profil: taruh `profile_rkaa.png` (atau .jpg) di `app/src/main/res/drawable-nodpi/`; kalau belum ada, ketuk lingkaran di About untuk memilih foto.

## Pembaruan APK
`applicationId` tetap `com.base.musicapp`, versionCode 30 / versionName 3.0.0. APK ditandatangani dengan kunci tetap `app/nova-signing.jks` supaya build berikutnya bisa meng-update build sebelumnya.
Catatan: APK lama yang dibuat dengan kunci debug acak (bawaan GitHub Actions) tidak bisa di-update oleh APK ini; uninstall sekali, setelah itu update berjalan normal.


## Tambahan: Spotify Playlist Importer -> Album Lokal + Navigasi Liquid Glass
- **Playlist -> Spotify -> Album Lokal**: tempel tautan playlist, tekan Import. Daftar lagu dibaca, tiap lagu dicari lewat YouTube Data API (judul + artis, durasi ikut dicocokkan) dan yang cocok disimpan ke Album Lokal. Juga bisa dari tempel teks atau CSV Exportify.
- Kunci API YouTube dibuat sendiri (Google Cloud, YouTube Data API v3) dan disimpan di `nova_secret.xml`, dikecualikan dari cadangan Android dan ekspor NovaMusic.
- Progress langsung (jumlah diproses, ditambahkan, duplikat, tak ketemu, gagal), tombol Batal, deteksi duplikat (judul+artis dan ID video, juga terhadap isi Album Lokal), serta riwayat impor (maks 50) dengan "Lanjutkan/Impor ulang" dan bagikan daftar yang tak ketemu.
- Kuota: ±101 poin per lagu dari 10.000/hari (±99 lagu per hari). Bila habis, impor berhenti dan dapat dilanjutkan besok; lagu yang sudah masuk dilewati tanpa memakai kuota.
- **Navigasi Liquid Glass**: kapsul melayang, kaca tembus pandang (terang/gelap), indikator aktif meluncur dengan pegas, bisa digeser dengan jari (tab pindah saat jari dilepas), transisi antar tab bergeser halus. Gaya Neobrutalism tetap solid tetapi memakai gerakan yang sama.
