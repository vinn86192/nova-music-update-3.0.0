package com.base.musicapp.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AColor
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.Color

/**
 * Pemuat cover dengan batas memori (16 MB) - menggantikan cache berbasis jumlah item yang boros RAM.
 * Ukuran kecil (256px) untuk daftar, besar (720px) hanya untuk Now Playing/latar.
 */
object ArtLoader {
    private val cache = object : LruCache<Long, Bitmap>(16 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount / 1024
    }

    fun peek(song: Song, big: Boolean = false): Bitmap? = cache.get(key(song, big))
    private fun key(song: Song, big: Boolean) = song.id * 2 + if (big) 1 else 0

    fun load(ctx: Context, song: Song, big: Boolean = false): Bitmap? {
        cache.get(key(song, big))?.let { return it }
        val px = if (big) 720 else 256
        val bmp = runCatching {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
            } else {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, song.uri)
                    r.embeddedPicture?.let { b ->
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(b, 0, b.size, o)
                        val sample = maxOf(1, maxOf(o.outWidth, o.outHeight) / px)
                        BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = sample })
                    }
                } finally { r.release() }
            }
        }.getOrNull()
        if (bmp != null) cache.put(key(song, big), bmp)
        return bmp
    }

    /** Warna dominan yang cerah/jenuh dari cover (untuk "Dynamic Color Extraction"). */
    fun dominantColor(bmp: Bitmap): Color? {
        val small = Bitmap.createScaledBitmap(bmp, 32, 32, true)
        val hsv = FloatArray(3)
        val weight = FloatArray(24)
        val sumH = FloatArray(24); val sumS = FloatArray(24); val sumV = FloatArray(24)
        for (y in 0 until 32) for (x in 0 until 32) {
            AColor.colorToHSV(small.getPixel(x, y), hsv)
            if (hsv[1] < 0.25f || hsv[2] < 0.2f) continue
            val bin = (hsv[0] / 15f).toInt().coerceIn(0, 23)
            val w = hsv[1] * (0.4f + hsv[2])
            weight[bin] += w; sumH[bin] += hsv[0] * w; sumS[bin] += hsv[1] * w; sumV[bin] += hsv[2] * w
        }
        if (small !== bmp) small.recycle()
        val best = weight.indices.maxByOrNull { weight[it] } ?: return null
        if (weight[best] <= 0f) return null
        val w = weight[best]
        val out = AColor.HSVToColor(floatArrayOf(sumH[best] / w, (sumS[best] / w).coerceIn(0.45f, 0.9f), (sumV[best] / w).coerceIn(0.75f, 1f)))
        return Color(out)
    }
}
