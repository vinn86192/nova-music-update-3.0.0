package com.base.musicapp.data

/** Satu lagu di daftar Spotify. [swappable] = urutan "Artis - Judul" belum pasti (hasil tempel teks). */
data class SpotifyTrack(
    val title: String,
    val artist: String,
    val durationMs: Long = 0L,
    val uri: String = "",
    val swappable: Boolean = false
)

data class SpotifyPlaylist(
    val id: String,
    val name: String,
    val url: String,
    val tracks: List<SpotifyTrack>,
    val importedAt: Long,
    val fromLink: Boolean
)

/** Hasil pencocokan lagu Spotify dengan lagu di perangkat ([song] null = tidak ditemukan). */
data class MatchResult(val track: SpotifyTrack, val song: Song?)

class SpotifyException(message: String) : Exception(message)

sealed interface ImportState {
    data object Idle : ImportState
    data object Loading : ImportState
    data class Error(val message: String) : ImportState
    data class Preview(
        val playlist: SpotifyPlaylist,
        val matches: List<MatchResult>,
        val note: String?
    ) : ImportState
}
