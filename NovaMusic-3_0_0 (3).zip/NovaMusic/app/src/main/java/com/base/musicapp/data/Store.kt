package com.base.musicapp.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Penyimpanan ringan: favorit, riwayat, playlist, playlist Spotify, antrean terakhir, lirik. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nova_music", Context.MODE_PRIVATE)
    private val lyrics = ctx.getSharedPreferences("nova_lyrics", Context.MODE_PRIVATE)
    /** Kunci API YouTube: berkas terpisah supaya bisa dikecualikan dari cadangan Android dan ekspor. */
    private val secret = ctx.getSharedPreferences("nova_secret", Context.MODE_PRIVATE)

    private fun readIds(key: String): List<Long> =
        (sp.getString(key, "") ?: "").split(",").mapNotNull { it.toLongOrNull() }

    fun favorites(): Set<Long> = readIds("fav").toSet()
    fun saveFavorites(s: Set<Long>) = sp.edit().putString("fav", s.joinToString(",")).apply()
    fun clearFavorites() = sp.edit().remove("fav").apply()

    fun recents(): List<Long> = readIds("recent")
    fun saveRecents(l: List<Long>) = sp.edit().putString("recent", l.joinToString(",")).apply()
    fun clearRecents() = sp.edit().remove("recent").apply()

    fun playlists(): Map<String, List<Long>> {
        val o = JSONObject(sp.getString("playlists", "{}") ?: "{}")
        val map = LinkedHashMap<String, List<Long>>()
        for (k in o.keys()) {
            val a = o.getJSONArray(k)
            map[k] = List(a.length()) { a.getLong(it) }
        }
        return map
    }

    fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        sp.edit().putString("playlists", o.toString()).apply()
    }

    // ---- sembunyikan lagu (mis. duplikat), folder dikecualikan, artis favorit
    fun hidden(): Set<Long> = readIds("hidden").toSet()
    fun saveHidden(s: Set<Long>) = sp.edit().putString("hidden", s.joinToString(",")).apply()

    private fun readStrings(key: String): Set<String> {
        val a = runCatching { JSONArray(sp.getString(key, "[]") ?: "[]") }.getOrNull() ?: return emptySet()
        return List(a.length()) { a.optString(it) }.filter { it.isNotEmpty() }.toSet()
    }
    private fun saveStrings(key: String, s: Set<String>) {
        val a = JSONArray(); s.forEach { a.put(it) }
        sp.edit().putString(key, a.toString()).apply()
    }
    fun excludedFolders(): Set<String> = readStrings("excl_folders")
    fun saveExcludedFolders(s: Set<String>) = saveStrings("excl_folders", s)
    fun favoriteArtists(): Set<String> = readStrings("fav_artists")
    fun saveFavoriteArtists(s: Set<String>) = saveStrings("fav_artists", s)

    // ---- koreksi metadata (override)
    fun overrides(): Map<Long, MetaOverride> = runCatching {
        val o = JSONObject(sp.getString("meta", "{}") ?: "{}")
        val m = HashMap<Long, MetaOverride>()
        for (k in o.keys()) {
            val v = o.getJSONObject(k)
            m[k.toLong()] = MetaOverride(v.optString("t").ifEmpty { null }, v.optString("a").ifEmpty { null }, v.optString("al").ifEmpty { null })
        }
        m
    }.getOrDefault(emptyMap())

    fun saveOverrides(m: Map<Long, MetaOverride>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), JSONObject().put("t", v.title ?: "").put("a", v.artist ?: "").put("al", v.album ?: "")) }
        sp.edit().putString("meta", o.toString()).apply()
    }

    // ---- pautan manual lagu Spotify -> lagu lokal
    fun spotifyLinks(): Map<String, Long> = runCatching {
        val o = JSONObject(sp.getString("sp_links", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getLong(it) }
    }.getOrDefault(emptyMap())

    fun saveSpotifyLinks(m: Map<String, Long>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, v) }
        sp.edit().putString("sp_links", o.toString()).apply()
    }

    // ---- tema kustom
    fun customThemes(): List<CustomTheme> = runCatching {
        val a = JSONArray(sp.getString("themes", "[]") ?: "[]")
        List(a.length()) {
            val o = a.getJSONObject(it)
            CustomTheme(o.getString("id"), o.optString("name", "Tema"), o.getInt("ac"), o.getInt("ac2"), o.getInt("bt"), o.getInt("bb"), o.optBoolean("dark", true))
        }
    }.getOrDefault(emptyList())

    fun saveCustomThemes(l: List<CustomTheme>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("ac", it.accent).put("ac2", it.accent2).put("bt", it.bgTop).put("bb", it.bgBottom).put("dark", it.dark)) }
        sp.edit().putString("themes", a.toString()).apply()
    }

    // ---- antrean terakhir
    fun queueIds(): List<Long> = readIds("q_ids")
    fun saveQueueIds(l: List<Long>) = sp.edit().putString("q_ids", l.joinToString(",")).apply()
    fun queueIndex(): Int = sp.getInt("q_idx", 0)
    fun queuePos(): Long = sp.getLong("q_pos", 0L)
    fun saveQueuePos(index: Int, pos: Long) = sp.edit().putInt("q_idx", index).putLong("q_pos", pos).apply()

    // ---- lirik
    fun clearLyrics() = lyrics.edit().clear().apply()

    // ---- playlist Spotify
    fun spotifyLists(): List<SpotifyPlaylist> = runCatching {
        val a = JSONArray(sp.getString("spotify", "[]") ?: "[]")
        List(a.length()) { readSpotify(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun saveSpotifyLists(l: List<SpotifyPlaylist>) {
        val a = JSONArray()
        l.forEach { a.put(writeSpotify(it)) }
        sp.edit().putString("spotify", a.toString()).apply()
    }

    private fun writeSpotify(p: SpotifyPlaylist): JSONObject {
        val tr = JSONArray()
        p.tracks.forEach {
            tr.put(JSONObject().put("t", it.title).put("a", it.artist).put("d", it.durationMs).put("u", it.uri).put("s", it.swappable))
        }
        return JSONObject().put("id", p.id).put("name", p.name).put("url", p.url)
            .put("at", p.importedAt).put("link", p.fromLink).put("tracks", tr)
    }

    private fun readSpotify(o: JSONObject): SpotifyPlaylist {
        val a = o.getJSONArray("tracks")
        val tracks = List(a.length()) {
            val t = a.getJSONObject(it)
            SpotifyTrack(t.optString("t"), t.optString("a"), t.optLong("d"), t.optString("u"), t.optBoolean("s"))
        }
        return SpotifyPlaylist(o.getString("id"), o.optString("name", "Playlist Spotify"), o.optString("url"), tracks, o.optLong("at"), o.optBoolean("link"))
    }

    // ---- kunci API YouTube (tidak ikut cadangan)
    fun ytKey(): String = secret.getString("yt_key", "") ?: ""
    fun saveYtKey(k: String) = secret.edit().putString("yt_key", k).apply()

    // ---- Album Lokal + riwayat impor
    private fun writeAlbumTrack(t: LocalAlbumTrack): JSONObject = JSONObject()
        .put("id", t.id).put("t", t.title).put("a", t.artist).put("v", t.videoId).put("vt", t.videoTitle)
        .put("ch", t.channel).put("th", t.thumbUrl).put("d", t.durationMs).put("sn", t.sourceName)
        .put("si", t.sourceId).put("k", t.key).put("at", t.addedAt)

    private fun readAlbumTrack(o: JSONObject) = LocalAlbumTrack(
        id = o.getString("id"), title = o.optString("t"), artist = o.optString("a"), videoId = o.getString("v"),
        videoTitle = o.optString("vt"), channel = o.optString("ch"), thumbUrl = o.optString("th"),
        durationMs = o.optLong("d"), sourceName = o.optString("sn"), sourceId = o.optString("si"),
        key = o.optString("k"), addedAt = o.optLong("at")
    )

    fun localAlbum(): List<LocalAlbumTrack> = runCatching {
        val a = JSONArray(sp.getString("local_album", "[]") ?: "[]")
        List(a.length()) { readAlbumTrack(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun saveLocalAlbum(l: List<LocalAlbumTrack>) {
        val a = JSONArray(); l.forEach { a.put(writeAlbumTrack(it)) }
        sp.edit().putString("local_album", a.toString()).apply()
    }

    private fun writeRecord(r: ImportRecord): JSONObject = JSONObject()
        .put("id", r.id).put("n", r.name).put("u", r.url).put("s", r.startedAt).put("f", r.finishedAt)
        .put("tot", r.total).put("add", r.added).put("dup", r.duplicates).put("nf", r.notFound)
        .put("fail", r.failed).put("st", r.status.name).put("nfl", JSONArray(r.notFoundList))

    private fun readRecord(o: JSONObject): ImportRecord {
        val l = o.optJSONArray("nfl")
        return ImportRecord(
            id = o.getString("id"), name = o.optString("n"), url = o.optString("u"),
            startedAt = o.optLong("s"), finishedAt = o.optLong("f"), total = o.optInt("tot"),
            added = o.optInt("add"), duplicates = o.optInt("dup"), notFound = o.optInt("nf"), failed = o.optInt("fail"),
            status = runCatching { ImportStatus.valueOf(o.optString("st")) }.getOrDefault(ImportStatus.INTERRUPTED),
            notFoundList = if (l == null) emptyList() else List(l.length()) { l.optString(it) }
        )
    }

    fun importHistory(): List<ImportRecord> = runCatching {
        val a = JSONArray(sp.getString("import_history", "[]") ?: "[]")
        List(a.length()) { readRecord(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun saveImportHistory(l: List<ImportRecord>) {
        val a = JSONArray(); l.forEach { a.put(writeRecord(it)) }
        sp.edit().putString("import_history", a.toString()).apply()
    }

    // ---- cadangan
    fun exportAll(settings: JSONObject): String {
        val root = JSONObject()
        root.put("app", "NovaMusic").put("version", 1)
        root.put("favorites", JSONArray(favorites().toList()))
        val pl = JSONObject()
        playlists().forEach { (k, v) -> pl.put(k, JSONArray(v)) }
        root.put("playlists", pl)
        val ly = JSONObject()
        lyrics.all.forEach { (k, v) -> if (v is String) ly.put(k, v) }
        root.put("lyrics", ly)
        val sa = JSONArray()
        spotifyLists().forEach { sa.put(writeSpotify(it)) }
        root.put("spotify", sa)
        val al = JSONArray(); localAlbum().forEach { al.put(writeAlbumTrack(it)) }
        root.put("localAlbum", al)
        val ih = JSONArray(); importHistory().forEach { ih.put(writeRecord(it)) }
        root.put("importHistory", ih)
        root.put("hidden", JSONArray(hidden().toList()))
        root.put("favArtists", JSONArray(favoriteArtists().toList()))
        root.put("excluded", JSONArray(excludedFolders().toList()))
        val ov = JSONObject()
        overrides().forEach { (k, v) -> ov.put(k.toString(), JSONObject().put("t", v.title ?: "").put("a", v.artist ?: "").put("al", v.album ?: "")) }
        root.put("meta", ov)
        val lk = JSONObject(); spotifyLinks().forEach { (k, v) -> lk.put(k, v) }
        root.put("spLinks", lk)
        val th = JSONArray()
        customThemes().forEach { th.put(JSONObject().put("id", it.id).put("name", it.name).put("ac", it.accent).put("ac2", it.accent2).put("bt", it.bgTop).put("bb", it.bgBottom).put("dark", it.dark)) }
        root.put("themes", th)
        root.put("settings", settings)
        return root.toString()
    }

    /** Digabung dengan data yang ada (tidak menimpa). Pengaturan ditangani pemanggil. */
    fun importAll(root: JSONObject) {
        root.optJSONArray("favorites")?.let { a ->
            saveFavorites(favorites() + List(a.length()) { a.getLong(it) })
        }
        root.optJSONObject("playlists")?.let { o ->
            val m = LinkedHashMap(playlists())
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                val ids = List(a.length()) { a.getLong(it) }
                m[k] = ((m[k] ?: emptyList()) + ids).distinct()
            }
            savePlaylists(m)
        }
        root.optJSONObject("lyrics")?.let { o ->
            val e = lyrics.edit()
            for (k in o.keys()) e.putString(k, o.getString(k))
            e.apply()
        }
        root.optJSONArray("hidden")?.let { a -> saveHidden(hidden() + List(a.length()) { a.getLong(it) }) }
        root.optJSONArray("favArtists")?.let { a -> saveFavoriteArtists(favoriteArtists() + List(a.length()) { a.getString(it) }) }
        root.optJSONArray("excluded")?.let { a -> saveExcludedFolders(excludedFolders() + List(a.length()) { a.getString(it) }) }
        root.optJSONObject("meta")?.let { o ->
            val m = HashMap(overrides())
            for (k in o.keys()) {
                val v = o.getJSONObject(k)
                m[k.toLong()] = MetaOverride(v.optString("t").ifEmpty { null }, v.optString("a").ifEmpty { null }, v.optString("al").ifEmpty { null })
            }
            saveOverrides(m)
        }
        root.optJSONObject("spLinks")?.let { o ->
            val m = HashMap(spotifyLinks())
            for (k in o.keys()) m[k] = o.getLong(k)
            saveSpotifyLinks(m)
        }
        root.optJSONArray("themes")?.let { a ->
            val incoming = List(a.length()) {
                val o = a.getJSONObject(it)
                CustomTheme(o.getString("id"), o.optString("name", "Tema"), o.getInt("ac"), o.getInt("ac2"), o.getInt("bt"), o.getInt("bb"), o.optBoolean("dark", true))
            }
            val ids = incoming.map { it.id }.toSet()
            saveCustomThemes(customThemes().filter { it.id !in ids } + incoming)
        }
        root.optJSONArray("localAlbum")?.let { a ->
            val have = localAlbum()
            val ids = have.map { it.id }.toSet()
            val add = List(a.length()) { readAlbumTrack(a.getJSONObject(it)) }.filter { it.id !in ids }
            saveLocalAlbum(have + add)
        }
        root.optJSONArray("importHistory")?.let { a ->
            val have = importHistory()
            val ids = have.map { it.id }.toSet()
            val add = List(a.length()) { readRecord(a.getJSONObject(it)) }.filter { it.id !in ids }
            saveImportHistory((add + have).sortedByDescending { it.startedAt }.take(50))
        }
        root.optJSONArray("spotify")?.let { a ->
            val incoming = List(a.length()) { readSpotify(a.getJSONObject(it)) }
            val ids = incoming.map { it.id }.toSet()
            saveSpotifyLists(spotifyLists().filter { it.id !in ids } + incoming)
        }
    }
}
