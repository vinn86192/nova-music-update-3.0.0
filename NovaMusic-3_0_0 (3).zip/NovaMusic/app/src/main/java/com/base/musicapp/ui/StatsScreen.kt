package com.base.musicapp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.PlayEvent
import com.base.musicapp.data.PlayStats
import com.base.musicapp.data.RankItem
import com.base.musicapp.data.StatsResult
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.player.fmt
import com.base.musicapp.player.fmtHours
import com.base.musicapp.ui.theme.Nova
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PageHeader(title: String, onBack: () -> Unit, subtitle: String? = null) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
        ScreenTitle(title, subtitle)
    }
}

@Composable
fun BarChart(values: List<Long>, labels: List<String>, modifier: Modifier = Modifier) {
    val c = Nova.c
    val max = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
    Column(modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val n = values.size.coerceAtLeast(1)
            val gap = if (n > 14) 2.dp.toPx() else 6.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            values.forEachIndexed { i, v ->
                val h = maxOf(3.dp.toPx(), v.toFloat() / max * size.height)
                drawRoundRect(
                    color = if (v == max && v > 0) c.accent else c.accent.copy(alpha = 0.42f),
                    topLeft = Offset(i * (bw + gap), size.height - h), size = Size(bw, h),
                    cornerRadius = CornerRadius(minOf(4.dp.toPx(), bw / 2))
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            labels.forEach { Text(it, color = c.muted, fontSize = 10.sp) }
        }
    }
}

@Composable
fun StatsScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    var range by remember { mutableIntStateOf(7) }
    var confirm by remember { mutableStateOf(false) }
    var version by remember { mutableIntStateOf(0) }
    val res by produceState<StatsResult?>(null, range, version) { value = vm.computeStats(range) }
    val r = res

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Statistik", onBack, "Waktu dengar dan lagu favoritmu") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf(7 to "7 hari", 30 to "30 hari", 0 to "Semua")) { (d, l) -> NovaChip(l, range == d, { range = d }) }
            }
        }
        if (r == null) { item { Text("Menghitung…", color = c.muted) }; return@LazyColumn }
        if (r.totalMs == 0L && r.plays == 0) {
            item { EmptyNote("Belum ada data. Putar beberapa lagu (minimal 5 detik) dan statistik akan muncul di sini.") }
        } else {
            item {
                val days = if (range > 0) range else 30
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Total waktu dengar", fmtHours(r.totalMs), Modifier.weight(1f))
                        StatCard("Jumlah putar", r.plays.toString(), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Lagu berbeda", r.uniqueSongs.toString(), Modifier.weight(1f))
                        StatCard("Rata-rata / hari", fmtHours(r.totalMs / days), Modifier.weight(1f))
                    }
                }
            }
            item {
                val week = r.dailyMs.takeLast(7)
                val fmtDay = SimpleDateFormat("EEE", Locale("id"))
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Aktivitas mingguan", color = c.onBg, fontWeight = FontWeight.Bold)
                    Text("Menit mendengarkan per hari", color = c.muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    BarChart(week.map { it.second }, week.map { fmtDay.format(Date(it.first)) })
                }
            }
            item {
                val fmtD = SimpleDateFormat("d MMM", Locale("id"))
                Column(Modifier.fillMaxWidth().panel().padding(14.dp)) {
                    Text("Aktivitas bulanan", color = c.onBg, fontWeight = FontWeight.Bold)
                    Text("30 hari terakhir", color = c.muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    BarChart(
                        r.dailyMs.map { it.second },
                        listOf(r.dailyMs.first().first, r.dailyMs[15].first, r.dailyMs.last().first).map { fmtD.format(Date(it)) }
                    )
                }
            }
            item { RankCard("Top 10 lagu", r.topTracks, showSub = true) }
            item { RankCard("Top artis", r.topArtists, showSub = false) }
            item { RankCard("Top album", r.topAlbums, showSub = true) }
            item { Text("Riwayat putar", color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            items(r.history.take(40)) { HistoryRow(it) }
            item { NovaButton("Hapus data statistik", { confirm = true }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, BtnKind.Secondary) }
        }
    }
    if (confirm) NovaDialog("Hapus statistik?", { confirm = false }, "Ya, hapus", { vm.clearStats(); version++; confirm = false }) {
        Text("Seluruh riwayat dan statistik mendengarkan akan dihapus.", color = c.onBg)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    val c = Nova.c
    Column(modifier.panel().padding(14.dp)) {
        Text(value, color = c.onBg, fontSize = 22.sp, fontWeight = if (Nova.look.neo) FontWeight.Black else FontWeight.ExtraBold)
        Text(label, color = c.muted, fontSize = 12.sp)
    }
}

@Composable
private fun RankCard(title: String, items: List<RankItem>, showSub: Boolean) {
    val c = Nova.c
    Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = c.onBg, fontWeight = FontWeight.Bold)
        if (items.isEmpty()) Text("Belum ada data", color = c.muted, fontSize = 12.sp)
        val max = (items.maxOfOrNull { it.plays } ?: 1).coerceAtLeast(1)
        items.forEachIndexed { i, it ->
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).clip(CircleShape).background(if (i == 0) c.accent else c.onBg.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                        Text("${i + 1}", color = if (i == 0) c.onAccent else c.onBg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(it.name, color = c.onBg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (showSub && it.sub.isNotBlank()) Text(it.sub, color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("${it.plays}x • ${fmtHours(it.ms)}", color = c.muted, fontSize = 11.sp)
                }
                Box(Modifier.padding(top = 4.dp, start = 34.dp).fillMaxWidth(it.plays.toFloat() / max).height(3.dp).clip(RoundedCornerShape(2.dp)).background(c.accent.copy(alpha = 0.6f)))
            }
        }
    }
}

@Composable
private fun HistoryRow(e: PlayEvent) {
    val c = Nova.c
    val f = remember { SimpleDateFormat("d MMM, HH:mm", Locale("id")) }
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (e.counted) Icons.Rounded.CheckCircle else Icons.Rounded.SkipNext, null, tint = if (e.counted) c.accent else c.muted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(e.title, color = c.onBg, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${e.artist} • ${f.format(Date(e.ts))}", color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(fmt(e.ms), color = c.muted, fontSize = 11.sp)
    }
}
