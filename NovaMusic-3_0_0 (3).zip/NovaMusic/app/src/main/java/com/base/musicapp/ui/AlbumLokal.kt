package com.base.musicapp.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.ImportPhase
import com.base.musicapp.data.ImportRecord
import com.base.musicapp.data.ImportStatus
import com.base.musicapp.data.LocalAlbumTrack
import com.base.musicapp.data.ThumbLoader
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.player.fmt
import com.base.musicapp.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF1ED760)
private val Amber = Color(0xFFFFB020)
private val dateFmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID"))

private fun openYoutube(ctx: Context, videoId: String) {
    fun go(u: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    try { go("vnd.youtube:$videoId") } catch (e: Exception) {
        try { go("https://www.youtube.com/watch?v=$videoId") } catch (e2: Exception) {
            Toast.makeText(ctx, "Tidak bisa membuka YouTube.", Toast.LENGTH_SHORT).show()
        }
    }
}

private fun share(ctx: Context, title: String, text: String) {
    ctx.startActivity(
        Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), title)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun statusColor(s: ImportStatus): Color = when (s) {
    ImportStatus.COMPLETED -> Green
    ImportStatus.RUNNING -> Green
    ImportStatus.CANCELED, ImportStatus.INTERRUPTED -> Amber
    ImportStatus.QUOTA, ImportStatus.NETWORK_ERROR -> Amber
    ImportStatus.KEY_ERROR -> Heart
}

// ================================================================ komponen kecil

@Composable
private fun Thumb(url: String, modifier: Modifier) {
    val c = Nova.c
    val bmp by produceState<ImageBitmap?>(ThumbLoader.peek(url)?.asImageBitmap(), url) {
        value = ThumbLoader.load(url)?.asImageBitmap()
    }
    val shape = artShape()
    Box(
        modifier.clip(shape).background(Brush.linearGradient(listOf(c.accent.copy(alpha = 0.26f), Color(0xFF0E0E10), c.accent2.copy(alpha = 0.18f)))),
        contentAlignment = Alignment.Center
    ) {
        Image(androidx.compose.ui.res.painterResource(com.base.musicapp.R.drawable.nova_logo), null, alpha = 0.9f, modifier = Modifier.fillMaxSize(0.52f))
        bmp?.let { Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
    }
}

/** Bar progres: [fraction] null = tak tentu (segmen bergerak). */
@Composable
private fun ProgressBar(fraction: Float?) {
    val c = Nova.c
    val look = Nova.look
    val anim by animateFloatAsState(fraction ?: 0f, tween(300), label = "pb")
    val t = rememberInfiniteTransition(label = "pbi")
    val sweep by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "sw")
    val shape = RoundedCornerShape(100.dp)
    Box(
        Modifier.fillMaxWidth().height(12.dp).clip(shape).background(c.onBg.copy(alpha = 0.12f))
            .then(if (look.neo) Modifier.border(2.dp, c.border, shape) else Modifier)
            .drawBehind {
                val brush = Brush.horizontalGradient(listOf(c.accent, c.accent2))
                val r = CornerRadius(size.height / 2)
                if (fraction != null) {
                    drawRoundRect(brush, size = Size(size.width * anim, size.height), cornerRadius = r)
                } else {
                    val w = size.width * 0.3f
                    drawRoundRect(brush, Offset((size.width + w) * sweep - w, 0f), Size(w, size.height), r)
                }
            }
    )
}

@Composable
private fun StatBox(label: String, value: Int, tint: Color, modifier: Modifier) {
    val c = Nova.c
    Column(modifier.panel(radius = 14.dp, flat = true).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", color = tint, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, color = c.muted, fontSize = 10.5.sp, maxLines = 1)
    }
}

@Composable
private fun Stats(added: Int, dup: Int, nf: Int, failed: Int) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatBox("Ditambahkan", added, Green, Modifier.weight(1f))
        StatBox("Duplikat", dup, c.accent, Modifier.weight(1f))
        StatBox("Tak ketemu", nf, Amber, Modifier.weight(1f))
        StatBox("Gagal", failed, Heart, Modifier.weight(1f))
    }
}

// ================================================================ IMPORT SPOTIFY -> ALBUM LOKAL

@Composable
fun AlbumImportScreen(vm: MusicViewModel, onBack: () -> Unit, onOpenAlbum: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val progress by vm.albumImport.collectAsState()
    val history by vm.importHistory.collectAsState()
    val hasKey by vm.ytKeyPresent.collectAsState()
    val album by vm.localAlbum.collectAsState()
    val relink by vm.albumImportLink.collectAsState()

    var mode by remember { mutableIntStateOf(0) }
    var link by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var textName by remember { mutableStateOf("") }
    var keyInput by remember { mutableStateOf("") }
    var editKey by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.startAlbumImportFromCsv(uri)
    }
    LaunchedEffect(relink) {
        relink?.let { mode = 0; link = it; vm.albumImportLink.value = null }
    }
    val running = progress.running

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
                ScreenTitle("Spotify → Album Lokal", "Cari tiap lagu di YouTube, simpan yang cocok")
            }
        }

        // ---- kunci API
        item {
            Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.VpnKey, null, tint = c.accent)
                    Spacer(Modifier.width(8.dp))
                    Text("Kunci API YouTube Data", color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                if (hasKey && !editKey) {
                    Text("Tersimpan (berakhiran ${vm.ytKeyTail()}). Disimpan hanya di perangkat ini dan tidak ikut cadangan.", color = c.muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NovaButton("Ganti", { editKey = true; keyInput = "" }, icon = Icons.Rounded.Edit, kind = BtnKind.Secondary)
                        NovaButton("Hapus", { vm.clearYtKey() }, icon = Icons.Rounded.Delete, kind = BtnKind.Secondary)
                    }
                } else {
                    Text(
                        "Buat kunci di Google Cloud Console: aktifkan YouTube Data API v3, lalu buat API key " +
                            "(jangan dibatasi ke aplikasi Android/IP tertentu). Tempel di bawah.",
                        color = c.muted, fontSize = 12.sp
                    )
                    NovaField(keyInput, { keyInput = it }, "Tempel kunci API", Modifier.fillMaxWidth(), Icons.Rounded.VpnKey)
                    NovaButton(
                        if (checking) "Memeriksa..." else "Simpan kunci",
                        {
                            checking = true
                            vm.saveYtKey(keyInput) { ok, msg ->
                                checking = false
                                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                                if (ok) { editKey = false; keyInput = "" }
                            }
                        },
                        Modifier.fillMaxWidth(), Icons.Rounded.Check, enabled = keyInput.isNotBlank() && !checking
                    )
                }
                Text(
                    "Kuota: tiap pencarian memakai ±101 dari 10.000 poin gratis per hari, jadi sekitar 99 lagu per hari. " +
                        "Bila habis, impor berhenti dan bisa dilanjutkan besok tanpa mengulang lagu yang sudah masuk.",
                    color = c.muted, fontSize = 11.sp
                )
            }
        }

        // ---- sumber
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Tautan", "Tempel teks", "File CSV").withIndex().toList()) { (i, t) ->
                    NovaChip(t, mode == i, { mode = i })
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (mode) {
                    0 -> {
                        Text("Tempel tautan playlist Spotify yang bersifat publik, lalu tekan Import.", color = c.muted, fontSize = 13.sp)
                        NovaField(link, { link = it }, "https://open.spotify.com/playlist/...", Modifier.fillMaxWidth(), Icons.Rounded.Link, keyboard = KeyboardType.Uri)
                        NovaButton(
                            "Import", { vm.startAlbumImportFromLink(link) }, Modifier.fillMaxWidth(), Icons.Rounded.Download,
                            enabled = link.isNotBlank() && !running && hasKey
                        )
                        Text(
                            "Daftar lagu dibaca dari halaman embed publik Spotify tanpa login, biasanya hanya ±50-100 lagu pertama. " +
                                "Untuk playlist lebih panjang pakai File CSV (Exportify).",
                            color = c.muted, fontSize = 11.sp
                        )
                    }
                    1 -> {
                        Text("Satu lagu per baris, misalnya \"Artis - Judul\".", color = c.muted, fontSize = 13.sp)
                        NovaField(textName, { textName = it }, "Nama daftar (opsional)", Modifier.fillMaxWidth())
                        NovaField(text, { text = it }, "Tulis atau tempel daftar lagu...", Modifier.fillMaxWidth(), singleLine = false, minHeight = 140.dp)
                        NovaButton(
                            "Import", { vm.startAlbumImportFromText(textName, text) }, Modifier.fillMaxWidth(), Icons.Rounded.Download,
                            enabled = text.isNotBlank() && !running && hasKey
                        )
                    }
                    else -> {
                        Text("Pilih file CSV hasil ekspor Exportify. Semua baris dibaca, bukan hanya 50 pertama.", color = c.muted, fontSize = 13.sp)
                        NovaButton(
                            "Pilih CSV dan import", { csvPicker.launch(arrayOf("text/*", "application/*", "*/*")) },
                            Modifier.fillMaxWidth(), Icons.Rounded.FolderOpen, enabled = !running && hasKey
                        )
                    }
                }
                if (!hasKey) Text("Simpan kunci API YouTube dulu agar tombol Import aktif.", color = Amber, fontSize = 12.sp)
            }
        }

        // ---- progres / hasil
        if (progress.phase != ImportPhase.IDLE) item {
            val p = progress
            Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (p.phase) {
                    ImportPhase.READING -> {
                        Text("Membaca daftar lagu...", color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        ProgressBar(null)
                        NovaButton("Batal", { vm.cancelAlbumImport() }, Modifier.fillMaxWidth(), Icons.Rounded.Stop, BtnKind.Secondary)
                    }
                    ImportPhase.SEARCHING -> {
                        Text(p.name, color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        ProgressBar(p.fraction)
                        Text("${p.done} dari ${p.total} lagu diproses", color = c.onBg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (p.current.isNotBlank()) Text("Mencari: ${p.current}", color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Stats(p.added, p.duplicates, p.notFound, p.failed)
                        NovaButton("Batal", { vm.cancelAlbumImport() }, Modifier.fillMaxWidth(), Icons.Rounded.Stop, BtnKind.Secondary)
                    }
                    else -> {
                        val st = p.status
                        val ok = st == ImportStatus.COMPLETED
                        val tint = if (st == null) Heart else statusColor(st)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, tint = tint)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (ok) "Impor selesai" else (st?.label ?: "Impor tidak dimulai"),
                                color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp
                            )
                        }
                        if (p.name.isNotBlank()) Text(p.name, color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        p.message?.let { Text(it, color = c.onBg, fontSize = 12.sp) }
                        if (p.total > 0) {
                            Text("${p.done} dari ${p.total} lagu diproses", color = c.muted, fontSize = 12.sp)
                            Stats(p.added, p.duplicates, p.notFound, p.failed)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (p.added > 0 || album.isNotEmpty()) NovaButton("Buka Album Lokal", onOpenAlbum, icon = Icons.Rounded.LibraryMusic)
                            NovaButton("Tutup", { vm.dismissAlbumImport() }, kind = BtnKind.Secondary)
                        }
                    }
                }
            }
        }

        // ---- riwayat
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.History, null, tint = c.onBg)
                Spacer(Modifier.width(8.dp))
                SectionTitle("Riwayat impor", Modifier.weight(1f))
                if (history.isNotEmpty()) IconButton(onClick = { confirmClear = true }) { Icon(Icons.Rounded.DeleteSweep, "Hapus riwayat", tint = c.muted) }
            }
        }
        if (history.isEmpty()) item { EmptyNote("Belum ada impor. Hasilnya akan tercatat di sini.") }
        items(history, key = { it.id }) { r ->
            HistoryRow(
                r, running,
                onRetry = {
                    vm.albumImportLink.value = r.url
                    Toast.makeText(ctx, "Tautan diisi. Tekan Import untuk melanjutkan.", Toast.LENGTH_SHORT).show()
                },
                onShareMissing = { share(ctx, "Lagu yang tidak ditemukan", r.notFoundList.joinToString("\n")) },
                onDelete = { vm.deleteImportRecord(r.id) }
            )
        }
        item { Spacer(Modifier.height(8.dp)) }
    }

    if (confirmClear) NovaDialog(
        "Hapus riwayat impor?", { confirmClear = false }, "Hapus",
        { vm.clearImportHistory(); confirmClear = false }
    ) { Text("Hanya catatan riwayat yang dihapus. Lagu di Album Lokal tetap ada.", color = c.muted, fontSize = 13.sp) }
}

@Composable
private fun HistoryRow(r: ImportRecord, busy: Boolean, onRetry: () -> Unit, onShareMissing: () -> Unit, onDelete: () -> Unit) {
    val c = Nova.c
    val resumable = r.status != ImportStatus.COMPLETED && r.status != ImportStatus.RUNNING
    Column(Modifier.fillMaxWidth().panel(radius = 16.dp).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.name, color = c.onBg, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(dateFmt.format(Date(r.startedAt)), color = c.muted, fontSize = 11.sp)
            }
            Text(r.status.label, color = statusColor(r.status), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "${r.total} lagu • ${r.added} baru • ${r.duplicates} duplikat • ${r.notFound} tak ketemu • ${r.failed} gagal",
            color = c.muted, fontSize = 12.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (r.url.isNotBlank()) {
                NovaButton(if (resumable) "Lanjutkan" else "Impor ulang", onRetry, icon = Icons.Rounded.Replay, kind = BtnKind.Secondary, enabled = !busy)
            }
            if (r.notFoundList.isNotEmpty()) IconButton(onClick = onShareMissing) { Icon(Icons.Rounded.Share, "Bagikan yang tak ketemu", tint = c.muted) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Hapus catatan", tint = c.muted) }
        }
    }
}

// ================================================================ ALBUM LOKAL

@Composable
fun LocalAlbumScreen(vm: MusicViewModel, onBack: () -> Unit, onImport: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val album by vm.localAlbum.collectAsState()
    var query by remember { mutableStateOf("") }
    var source by remember { mutableStateOf<String?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<LocalAlbumTrack?>(null) }

    val sources = remember(album) { album.map { it.sourceName }.distinct() }
    // sumber yang sudah kosong (semua lagunya dihapus) kembali ke "Semua"
    val activeSource = source?.takeIf { it in sources }
    val shown = remember(album, query, activeSource) {
        album.asReversed().filter { t ->
            (activeSource == null || t.sourceName == activeSource) &&
                (query.isBlank() || t.title.contains(query, true) || t.artist.contains(query, true) || t.channel.contains(query, true))
        }
    }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
                ScreenTitle("Album Lokal", "${album.size} lagu dari YouTube • tersimpan di perangkat")
            }
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { NovaButton("Import Spotify", onImport, icon = Icons.Rounded.Download) }
                if (album.isNotEmpty()) {
                    item {
                        NovaButton("Bagikan daftar", {
                            share(ctx, "Album Lokal", shown.joinToString("\n") { "${it.artist} - ${it.title}  ${it.watchUrl}".trim() })
                        }, icon = Icons.Rounded.Share, kind = BtnKind.Secondary)
                    }
                    item { NovaButton("Kosongkan", { confirmClear = true }, icon = Icons.Rounded.DeleteSweep, kind = BtnKind.Secondary) }
                }
            }
        }
        if (album.isNotEmpty()) {
            item { NovaField(query, { query = it }, "Cari judul, artis, atau channel", Modifier.fillMaxWidth(), Icons.Rounded.Search) }
            if (sources.size > 1) item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { NovaChip("Semua", activeSource == null, { source = null }) }
                    items(sources) { s -> NovaChip(s, activeSource == s, { source = s }) }
                }
            }
        }
        if (album.isEmpty()) item {
            Column(Modifier.fillMaxWidth().panel().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Album Lokal masih kosong", color = c.onBg, fontWeight = FontWeight.Bold)
                Text(
                    "Import playlist Spotify, dan lagu yang cocok di YouTube akan disimpan di sini. " +
                        "Ketuk lagu untuk membukanya di YouTube.",
                    color = c.muted, fontSize = 13.sp
                )
            }
        } else if (shown.isEmpty()) item { EmptyNote("Tidak ada lagu yang cocok dengan pencarian.") }

        items(shown, key = { it.id }) { t ->
            Row(
                Modifier.fillMaxWidth().panel(radius = 16.dp, flat = true, onClick = { openYoutube(ctx, t.videoId) })
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Thumb(t.thumbUrl, Modifier.size(52.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        listOf(t.artist, t.channel).filter { it.isNotBlank() }.joinToString(" • ") +
                            if (t.durationMs > 0) " • ${fmt(t.durationMs)}" else "",
                        color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { openYoutube(ctx, t.videoId) }) { Icon(Icons.Rounded.PlayArrow, "Buka di YouTube", tint = c.accent) }
                IconButton(onClick = { toDelete = t }) { Icon(Icons.Rounded.Delete, "Hapus", tint = c.muted) }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }

    toDelete?.let { t ->
        NovaDialog("Hapus dari Album Lokal?", { toDelete = null }, "Hapus", { vm.removeAlbumTrack(t.id); toDelete = null }) {
            Text("${t.title} • ${t.artist}", color = c.muted, fontSize = 13.sp)
        }
    }
    if (confirmClear) NovaDialog(
        "Kosongkan Album Lokal?", { confirmClear = false }, "Kosongkan",
        { vm.clearLocalAlbum(); confirmClear = false }
    ) { Text("Semua ${album.size} lagu di Album Lokal akan dihapus. Lagu di perangkat tidak terpengaruh.", color = c.muted, fontSize = 13.sp) }
}
