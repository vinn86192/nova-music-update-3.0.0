package com.base.musicapp.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class TimedLyric(val timeMs: Long, val text: String)
data class LyricsResult(val lines: List<TimedLyric>, val synced: Boolean)

/**
 * Lirik otomatis dari LRCLIB (https://lrclib.net) + cache offline berbasis file (bukan SharedPreferences,
 * supaya RAM tidak membengkak). Terjemahan memakai endpoint web Google Translate (tidak resmi) dan juga di-cache.
 */
object LyricsRepository {
    private val tag = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private const val UA = "NovaMusic/3.0 (Android music player)"
    private const val RETRY_MISS_MS = 24L * 60 * 60 * 1000

    private fun dir(ctx: Context) = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(20)

    fun keyOf(title: String, artist: String, durationMs: Long) = hash("${title.lowercase()}|${artist.lowercase()}|${durationMs / 2000}")

    // ------------------------------------------------------------ LRC
    fun parseLrc(text: String): LyricsResult {
        val synced = ArrayList<TimedLyric>()
        var offset = 0L
        val plain = ArrayList<TimedLyric>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.startsWith("[offset:")) { offset = line.substringAfter(':').trimEnd(']').trim().toLongOrNull() ?: 0L; continue }
            val stamps = tag.findAll(line).toList()
            if (stamps.isEmpty()) {
                if (line.isNotEmpty() && !Regex("""^\[[a-zA-Z]+:.*]$""").matches(line)) plain += TimedLyric(-1L, line)
                continue
            }
            val body = line.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val f = m.groupValues[3]
                val ms = when (f.length) { 1 -> f.toLong() * 100; 2 -> f.toLong() * 10; 3 -> f.toLong(); else -> 0L }
                synced += TimedLyric(m.groupValues[1].toLong() * 60_000L + m.groupValues[2].toLong() * 1000L + ms - offset, body)
            }
        }
        if (synced.isNotEmpty()) return LyricsResult(synced.sortedBy { it.timeMs }, true)
        return LyricsResult(plain, false)
    }

    private fun decodeApi(o: JSONObject): LyricsResult? {
        val s = o.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
        if (s != null) parseLrc(s).takeIf { it.lines.isNotEmpty() }?.let { return it }
        val p = o.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" } ?: return null
        val lines = p.lines().map { TimedLyric(-1L, it.trim()) }.dropWhile { it.text.isEmpty() }
        return if (lines.isEmpty()) null else LyricsResult(lines, false)
    }

    // ------------------------------------------------------------ cache
    private fun write(file: File, r: LyricsResult) {
        val a = JSONArray()
        r.lines.forEach { a.put(JSONObject().put("t", it.timeMs).put("x", it.text)) }
        file.writeText(JSONObject().put("s", r.synced).put("l", a).toString())
    }

    private fun read(file: File): LyricsResult? = runCatching {
        val o = JSONObject(file.readText())
        val a = o.getJSONArray("l")
        LyricsResult(List(a.length()) { TimedLyric(a.getJSONObject(it).optLong("t", -1L), a.getJSONObject(it).optString("x")) }, o.optBoolean("s"))
    }.getOrNull()

    /** Lirik dari cache offline saja (tanpa internet). */
    fun cached(ctx: Context, title: String, artist: String, durationMs: Long): LyricsResult? =
        File(dir(ctx), keyOf(title, artist, durationMs) + ".json").takeIf { it.exists() }?.let { read(it) }

    /** Cache dulu; jika belum ada baru ke jaringan. Null = tidak ditemukan / offline. */
    fun get(ctx: Context, title: String, artist: String, album: String, durationMs: Long): LyricsResult? {
        cached(ctx, title, artist, durationMs)?.let { return it }
        val key = keyOf(title, artist, durationMs)
        val miss = File(dir(ctx), "$key.miss")
        if (miss.exists() && System.currentTimeMillis() - miss.lastModified() < RETRY_MISS_MS) return null

        val cleanTitle = title.replace(Regex("""\s*[(\[].*?[)\]]"""), "").trim().ifEmpty { title }
        val cleanArtist = if (artist.startsWith("Artis tidak")) "" else artist.substringBefore(",").trim()
        var networkOk = true
        var found: LyricsResult? = null
        try {
            found = exact(title, cleanArtist, album, durationMs)
                ?: (if (cleanTitle != title) exact(cleanTitle, cleanArtist, album, durationMs) else null)
                ?: search("$cleanTitle $cleanArtist".trim(), durationMs)
        } catch (e: IOException) {
            networkOk = false
        }
        if (found != null) {
            write(File(dir(ctx), "$key.json"), found)
        } else if (networkOk) {
            runCatching { miss.writeText(System.currentTimeMillis().toString()) }
        }
        return found
    }

    fun forgetMiss(ctx: Context, title: String, artist: String, durationMs: Long) {
        File(dir(ctx), keyOf(title, artist, durationMs) + ".miss").delete()
    }

    private fun http(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000; c.readTimeout = 12_000
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode != 200) return null
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun exact(title: String, artist: String, album: String, durationMs: Long): LyricsResult? {
        val q = buildString {
            append("track_name=").append(Uri.encode(title))
            if (artist.isNotBlank()) append("&artist_name=").append(Uri.encode(artist))
            if (album.isNotBlank() && !album.startsWith("Album tidak")) append("&album_name=").append(Uri.encode(album))
            val sec = (durationMs / 1000).toInt()
            if (sec in 1..3600) append("&duration=").append(sec)
        }
        val body = http("https://lrclib.net/api/get?$q") ?: return null
        return decodeApi(JSONObject(body))
    }

    private fun search(query: String, durationMs: Long): LyricsResult? {
        val body = http("https://lrclib.net/api/search?q=${Uri.encode(query)}") ?: return null
        val arr = JSONArray(body)
        var best: JSONObject? = null
        var bestScore = Double.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val hasSynced = o.optString("syncedLyrics").let { it.isNotBlank() && it != "null" }
            val diff = kotlin.math.abs(o.optDouble("duration", 0.0) * 1000 - durationMs)
            if (durationMs > 0 && diff > 8000) continue
            val score = diff - (if (hasSynced) 5000 else 0)
            if (score < bestScore) { bestScore = score; best = o }
        }
        return best?.let { decodeApi(it) }
    }

    // ------------------------------------------------------------ terjemahan
    fun cachedTranslation(ctx: Context, key: String, lang: String, size: Int): List<String>? =
        File(dir(ctx), "$key.$lang.tr").takeIf { it.exists() }?.let { f ->
            runCatching {
                val a = JSONArray(f.readText())
                List(a.length()) { a.getString(it) }
            }.getOrNull()?.takeIf { it.size == size }
        }

    /** Menerjemahkan semua baris; null jika gagal (offline / ditolak). Hasil disimpan offline. */
    fun translate(ctx: Context, key: String, lang: String, lines: List<String>): List<String>? {
        cachedTranslation(ctx, key, lang, lines.size)?.let { return it }
        return try {
            val out = ArrayList<String>()
            var i = 0
            while (i < lines.size) {
                val chunk = ArrayList<String>()
                var len = 0
                while (i < lines.size && (chunk.isEmpty() || len + lines[i].length < 3000)) { chunk += lines[i]; len += lines[i].length + 1; i++ }
                out += translateChunk(chunk, lang) ?: return null
            }
            File(dir(ctx), "$key.$lang.tr").writeText(JSONArray(out).toString())
            out
        } catch (e: Exception) { null }
    }

    private fun translateChunk(chunk: List<String>, lang: String): List<String>? {
        val joined = chunk.joinToString("\n")
        val text = post(joined, lang) ?: return null
        val parts = text.split("\n")
        if (parts.size == chunk.size) return parts.map { it.trim() }
        // jumlah baris tidak cocok: terjemahkan baris per baris (lebih lambat tapi akurat)
        return chunk.map { line -> if (line.isBlank()) "" else (post(line, lang) ?: return null).trim() }
    }

    private fun post(q: String, lang: String): String? {
        val c = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$lang&dt=t")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 10_000; c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            c.outputStream.use { it.write(("q=" + Uri.encode(q)).toByteArray()) }
            if (c.responseCode != 200) return null
            val root = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
            val segs = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) sb.append(segs.getJSONArray(i).optString(0))
            return sb.toString().trimEnd('\n')
        } finally { c.disconnect() }
    }

    // ------------------------------------------------------------ kelola cache
    fun cacheInfo(ctx: Context): Pair<Int, Long> {
        val f = dir(ctx).listFiles { x -> x.name.endsWith(".json") }.orEmpty()
        return f.size to dir(ctx).listFiles().orEmpty().sumOf { it.length() }
    }

    fun clearCache(ctx: Context) { dir(ctx).listFiles()?.forEach { it.delete() } }
}
