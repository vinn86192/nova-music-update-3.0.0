package com.base.musicapp.ui

import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.base.musicapp.data.NowEffect
import com.base.musicapp.data.PlayerLayout
import com.base.musicapp.data.Song
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.player.fmt
import com.base.musicapp.ui.theme.*
import kotlin.math.abs
import kotlin.math.sin

private enum class Sheet { NONE, QUEUE, SLEEP, SPEED, EQ, LYRICS_EDIT }

@Composable
fun NowPlayingScreen(vm: MusicViewModel, onClose: () -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val cfg by vm.cfg.state.collectAsState()
    val song by vm.current.collectAsState()
    val playing by vm.isPlaying.collectAsState()
    val pos by vm.position.collectAsState()
    val dur by vm.duration.collectAsState()
    val shuffle by vm.shuffle.collectAsState()
    val repeat by vm.repeat.collectAsState()
    val favs by vm.favorites.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val sleepEnd by vm.sleepAtEnd.collectAsState()
    val headphone by vm.headphone.collectAsState()
    val art by vm.artBig.collectAsState()
    val lines by vm.lyricLines.collectAsState()
    val synced by vm.lyricsSynced.collectAsState()
    val lyricIdx by vm.activeLyricIndex.collectAsState()
    val lyricStatus by vm.lyricsStatus.collectAsState()
    val lyricLoading by vm.lyricsLoading.collectAsState()
    val translation by vm.translation.collectAsState()
    val translating by vm.translating.collectAsState()
    var sheet by remember { mutableStateOf(Sheet.NONE) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var showLyrics by remember { mutableStateOf(false) }
    val s = song ?: return
    val layout = cfg.playerLayout
    val effect = cfg.nowEffect

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))) {
        val bmp = art
        if (!look.neo && look.blurNow && bmp != null) {
            val shown = remember(bmp) { android.graphics.Bitmap.createScaledBitmap(bmp, 48, 48, true).asImageBitmap() }
            androidx.compose.foundation.Image(
                shown, null, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize().then(if (Build.VERSION.SDK_INT >= 31) Modifier.blur(24.dp) else Modifier)
            )
            Box(Modifier.fillMaxSize().background(c.bgBottom.copy(alpha = if (c.dark) 0.72f else 0.55f)))
        }
        if (effect == NowEffect.STARS) StarField(playing)

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ---- header
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose, modifier = if (look.neo) Modifier else Modifier.clip(CircleShape).background(c.onBg.copy(alpha = 0.08f))) { Icon(Icons.Rounded.KeyboardArrowDown, "Tutup", tint = c.onBg, modifier = Modifier.size(32.dp)) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SEDANG DIPUTAR", color = c.muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
                    if (headphone != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Headphones, null, tint = c.accent, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(headphone!!, color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                IconButton(onClick = { sheet = Sheet.QUEUE }, modifier = if (look.neo) Modifier else Modifier.clip(CircleShape).background(c.onBg.copy(alpha = 0.08f))) { Icon(Icons.Rounded.QueueMusic, "Antrean", tint = c.onBg) }
            }

            // ---- area tengah: cover / vinyl / lirik
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when {
                    showLyrics || layout == PlayerLayout.COMPACT -> Column(Modifier.fillMaxSize()) {
                        if (layout == PlayerLayout.COMPACT && !showLyrics) {
                            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Artwork(s, Modifier.size(84.dp), RoundedCornerShape(look.radius), big = true)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(s.title, color = c.onBg, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(s.artist, color = c.muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        } else {
                            LyricsActions(vm, cfg.lyricsTranslate, translating, lyricStatus, onEdit = { sheet = Sheet.LYRICS_EDIT })
                        }
                        LyricsView(lines, synced, lyricIdx, translation, lyricStatus, lyricLoading, Modifier.weight(1f).fillMaxWidth()) { vm.seek(it) }
                    }
                    layout == PlayerLayout.MINIMAL -> MinimalCenter(vm, s.title, s.artist, lines, synced, lyricIdx) { showLyrics = true }
                    else -> Column(
                        Modifier.fillMaxSize()
                            .pointerInput(cfg.gestures, s.id) {
                                if (!cfg.gestures) return@pointerInput
                                detectTapGestures(onDoubleTap = { vm.toggle() })
                            }
                            .pointerInput(cfg.gestures, s.id) {
                                if (!cfg.gestures) return@pointerInput
                                var dx = 0f; var dy = 0f
                                detectDragGestures(
                                    onDragStart = { dx = 0f; dy = 0f },
                                    onDragEnd = {
                                        when {
                                            abs(dx) > abs(dy) && dx > 140 -> vm.prev()
                                            abs(dx) > abs(dy) && dx < -140 -> vm.next()
                                            dy > 220 -> onClose()
                                            dy < -220 -> { sheet = Sheet.QUEUE }
                                            else -> Unit
                                        }
                                    }
                                ) { change, d -> change.consume(); dx += d.x; dy += d.y }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                    ) {
                        CoverArt(s, layout, playing, effect, Modifier.weight(1f, fill = false))
                        Spacer(Modifier.height(14.dp))
                        CompactLyric(lines, synced, lyricIdx, lyricStatus, lyricLoading) { showLyrics = true }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            // ---- judul
            val showTitleRow = layout != PlayerLayout.MINIMAL && (layout != PlayerLayout.COMPACT || showLyrics)
            if (showTitleRow) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = c.onBg, fontSize = 24.sp, letterSpacing = (-0.5).sp, fontWeight = if (look.neo) FontWeight.Black else FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, color = c.muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    FavButton(s.id in favs) { vm.toggleFavorite(s) }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { FavButton(s.id in favs) { vm.toggleFavorite(s) } }
            }

            // ---- seek
            Slider(
                value = drag ?: if (dur > 0) pos.toFloat() / dur else 0f,
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { vm.seek((it * dur).toLong()) }; drag = null },
                colors = SliderDefaults.colors(thumbColor = if (look.neo) c.onBg else c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.onBg.copy(alpha = 0.2f))
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(((drag ?: (if (dur > 0) pos.toFloat() / dur else 0f)) * dur).toLong()), color = c.muted, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(fmt(dur), color = c.muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(6.dp))

            // ---- kontrol
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.toggleShuffle() }) { Icon(Icons.Rounded.Shuffle, "Acak", tint = if (shuffle) c.accent else c.muted) }
                IconButton(onClick = { vm.prev() }, modifier = Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipPrevious, "Sebelumnya", tint = c.onBg, modifier = Modifier.size(36.dp)) }
                Box(
                    Modifier.size(76.dp).then(if (look.neo) Modifier else Modifier.shadow(22.dp, CircleShape, ambientColor = c.accent.copy(alpha = 0.30f), spotColor = c.accent.copy(alpha = 0.60f))).panel(
                        radius = if (look.neo) look.radius + 6.dp else 60.dp,
                        fill = if (look.neo) c.accent else null,
                        brush = if (look.neo) null else Brush.linearGradient(listOf(c.accent, c.accent2)),
                        onClick = { vm.toggle() }
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Jeda" else "Putar",
                        tint = if (look.neo) c.onAccent else bestOn(lerp(c.accent, c.accent2, 0.5f)), modifier = Modifier.size(42.dp)
                    )
                }
                IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipNext, "Berikutnya", tint = c.onBg, modifier = Modifier.size(36.dp)) }
                IconButton(onClick = { vm.cycleRepeat() }) {
                    Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Ulangi", tint = if (repeat != Player.REPEAT_MODE_OFF) c.accent else c.muted)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().panel(radius = if (look.neo) look.radius else 24.dp).padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                ToolButton(Icons.Rounded.Speed, "Kecepatan") { sheet = Sheet.SPEED }
                ToolButton(Icons.Rounded.Bedtime, if (sleepLeft > 0) fmt(sleepLeft) else if (sleepEnd) "Akhir lagu" else "Timer") { sheet = Sheet.SLEEP }
                ToolButton(Icons.Rounded.GraphicEq, "Equalizer") { sheet = Sheet.EQ }
                ToolButton(Icons.Rounded.Notes, if (showLyrics) "Cover" else "Lirik", showLyrics) { showLyrics = !showLyrics }
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    when (sheet) {
        Sheet.QUEUE -> QueueSheet(vm, s) { sheet = Sheet.NONE }
        Sheet.SLEEP -> SleepSheet(vm) { sheet = Sheet.NONE }
        Sheet.SPEED -> SpeedSheet(vm) { sheet = Sheet.NONE }
        Sheet.EQ -> EqualizerSheet(vm) { sheet = Sheet.NONE }
        Sheet.LYRICS_EDIT -> LyricsEditSheet(vm, s) { sheet = Sheet.NONE }
        Sheet.NONE -> {}
    }
}

@Composable
private fun FavButton(fav: Boolean, onClick: () -> Unit) {
    val c = Nova.c
    IconButton(onClick = onClick) {
        Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorit", tint = if (fav) Heart else c.onBg)
    }
}

// ================================================================ cover, vinyl, efek
@Composable
private fun CoverArt(s: Song, layout: PlayerLayout, playing: Boolean, effect: NowEffect, modifier: Modifier) {
    val c = Nova.c
    val look = Nova.look
    val base by animateFloatAsState(if (playing || !look.animations) 1f else 0.88f, spring(dampingRatio = 0.6f), label = "art")
    val t = rememberInfiniteTransition(label = "fx")
    val breathe by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val pulse = if (effect == NowEffect.PULSE && playing && look.animations) 1f + 0.035f * sin(breathe * Math.PI.toFloat()) else 1f
    val glow = if (effect == NowEffect.GLOW) 0.25f + 0.35f * (if (playing) breathe else 0.3f) else 0f

    Box(
        modifier.fillMaxWidth().aspectRatio(1f).scale(base * pulse)
            .then(
                if (glow > 0f) Modifier.drawBehind {
                    val r = size.minDimension * 0.75f
                    drawCircle(Brush.radialGradient(listOf(c.accent.copy(alpha = glow), Color.Transparent), center = center, radius = r), radius = r, center = center)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (layout == PlayerLayout.VINYL) {
            Vinyl(s, playing)
        } else {
            Box(Modifier.fillMaxSize().then(if (look.neo) Modifier else Modifier.shadow(28.dp, RoundedCornerShape(look.radius + 12.dp), ambientColor = c.accent.copy(alpha = 0.20f), spotColor = c.accent.copy(alpha = 0.45f))).panel(radius = look.radius + 12.dp, fill = if (look.neo) c.accent else c.surfaceSolid)) {
                Artwork(s, Modifier.fillMaxSize(), RectangleShape, big = true)
            }
        }
    }
}

@Composable
private fun Vinyl(s: Song, playing: Boolean) {
    val c = Nova.c
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 40f) % 360f
                last = now
            }
        }
    }
    Box(Modifier.fillMaxSize().rotate(angle), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0xFF0C0C10))
            val r = size.minDimension / 2
            var k = 0.45f
            while (k < 0.98f) { drawCircle(Color.White.copy(alpha = 0.05f), r * k, style = Stroke(1.2f)); k += 0.045f }
            drawCircle(c.accent.copy(alpha = 0.35f), r * 0.99f, style = Stroke(3f))
        }
        Artwork(s, Modifier.fillMaxSize(0.42f), CircleShape, big = true)
        Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF0C0C10)))
    }
}

@Composable
private fun StarField(playing: Boolean) {
    val c = Nova.c
    val t = rememberInfiniteTransition(label = "stars")
    val tw by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse), label = "tw")
    val stars = remember { val r = java.util.Random(7); List(70) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.6f + r.nextFloat() * 1.8f, r.nextFloat()) } }
    Canvas(Modifier.fillMaxSize()) {
        for (st in stars) {
            val a = (0.25f + 0.6f * abs(sin((tw + st[3]) * Math.PI.toFloat()))) * (if (playing) 1f else 0.5f)
            drawCircle(c.onBg.copy(alpha = a), st[2].dp.toPx(), Offset(st[0] * size.width, st[1] * size.height))
        }
    }
}

@Composable
private fun CompactLyric(lines: List<com.base.musicapp.data.TimedLyric>, synced: Boolean, idx: Int, status: String, loading: Boolean, onClick: () -> Unit) {
    val c = Nova.c
    Column(
        Modifier.fillMaxWidth().panel(radius = 18.dp, onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("LIRIK", color = c.accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        when {
            lines.isEmpty() -> Text(if (loading) "Mencari lirik…" else status, color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
            !synced -> Text(lines.first().text, color = c.onBg, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            else -> {
                Text(lines.getOrNull(idx)?.text?.ifBlank { "♪" } ?: "♪", color = c.onBg, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                lines.getOrNull(idx + 1)?.let { Text(it.text, color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }
        }
    }
}

@Composable
private fun MinimalCenter(vm: MusicViewModel, title: String, artist: String, lines: List<com.base.musicapp.data.TimedLyric>, synced: Boolean, idx: Int, onLyrics: () -> Unit) {
    val c = Nova.c
    Column(Modifier.fillMaxSize().clickable(onClick = onLyrics), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = c.onBg, fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Text(artist, color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(28.dp))
        val cur = if (synced) lines.getOrNull(idx)?.text else null
        Text(cur ?: "", color = c.muted, fontSize = 17.sp, textAlign = TextAlign.Center, maxLines = 2, modifier = Modifier.padding(horizontal = 12.dp))
    }
}

@Composable
private fun LyricsActions(vm: MusicViewModel, translateOn: Boolean, translating: Boolean, status: String, onEdit: () -> Unit) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(status, color = c.muted, fontSize = 11.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            if (translating) "Menerjemahkan…" else if (translateOn) "Terjemahan: nyala" else "Terjemahkan",
            color = if (translateOn) c.accent else c.onBg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { vm.setTranslate(!translateOn) }.padding(8.dp)
        )
        Icon(Icons.Rounded.Refresh, "Muat ulang", tint = c.onBg, modifier = Modifier.size(34.dp).clip(CircleShape).clickable { vm.retryLyrics() }.padding(7.dp))
        Icon(Icons.Rounded.Edit, "Edit lirik", tint = c.onBg, modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onEdit).padding(7.dp))
    }
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, active: Boolean = false, onClick: () -> Unit) {
    val c = Nova.c
    Column(
        Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (active) c.accent else c.onBg)
        Text(label, color = if (active) c.accent else c.muted, fontSize = 11.sp, maxLines = 1)
    }
}

// ================================================================ sheet
@Composable
private fun QueueSheet(vm: MusicViewModel, cur: Song, onDismiss: () -> Unit) {
    val c = Nova.c
    val queue by vm.queue.collectAsState()
    var note by remember { mutableStateOf("") }
    SheetHost("Antrean (${queue.size})", onDismiss) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            NovaButton("Tambah lagu mirip", { vm.addSimilar(cur, 10) { n -> note = if (n > 0) "$n lagu ditambahkan" else "Belum ada lagu yang mirip" } }, icon = Icons.Rounded.AutoAwesome, kind = BtnKind.Secondary)
            Text(note, color = c.muted, fontSize = 12.sp)
        }
        LazyColumn(Modifier.heightIn(max = 460.dp)) {
            itemsIndexed(queue) { i, s ->
                val isCur = s.id == cur.id
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.skipTo(i) }.padding(vertical = 4.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Artwork(s, Modifier.size(42.dp), RoundedCornerShape(10.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = if (isCur) c.accent else c.onBg, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(s.artist, color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { vm.moveQueue(i, i - 1) }, enabled = i > 0, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.KeyboardArrowUp, "Naikkan", tint = c.onBg) }
                    IconButton(onClick = { vm.moveQueue(i, i + 1) }, enabled = i < queue.lastIndex, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.KeyboardArrowDown, "Turunkan", tint = c.onBg) }
                    IconButton(onClick = { vm.removeFromQueue(i) }, enabled = queue.size > 1, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.Close, "Hapus", tint = c.muted) }
                }
            }
        }
    }
}

@Composable
private fun SleepSheet(vm: MusicViewModel, onDismiss: () -> Unit) {
    val c = Nova.c
    val left by vm.sleepLeft.collectAsState()
    val atEnd by vm.sleepAtEnd.collectAsState()
    SheetHost("Timer tidur", onDismiss) {
        if (left > 0) Text("Berhenti dalam ${fmt(left)} (volume meredup di 8 detik terakhir)", color = c.accent, fontSize = 13.sp)
        if (atEnd) Text("Berhenti setelah lagu ini selesai", color = c.accent, fontSize = 13.sp)
        val rows = listOf(0 to "Nonaktif", -1 to "Setelah lagu ini selesai", 15 to "15 menit", 30 to "30 menit", 45 to "45 menit", 60 to "1 jam", 90 to "1,5 jam")
        rows.forEach { (m, label) ->
            Text(
                label, color = c.onBg, fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .clickable { if (m == -1) vm.sleepAfterThisSong() else vm.setSleep(m); onDismiss() }
                    .padding(vertical = 12.dp, horizontal = 6.dp)
            )
        }
    }
}

@Composable
private fun SpeedSheet(vm: MusicViewModel, onDismiss: () -> Unit) {
    val speed by vm.speed.collectAsState()
    SheetHost("Kecepatan putar", onDismiss) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf(0.5f, 0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 1.75f, 2f)) { v ->
                NovaChip("${v}x", speed == v, { vm.setSpeed(v) })
            }
        }
    }
}

@Composable
private fun EqualizerSheet(vm: MusicViewModel, onDismiss: () -> Unit) {
    val c = Nova.c
    val eq = remember { vm.ensureEq() }
    SheetHost("Equalizer", onDismiss) {
        if (eq == null) {
            Text("Equalizer belum siap. Putar lagu dulu lalu buka lagi.", color = c.muted)
        } else {
            val range = eq.bandLevelRange
            val bands = eq.numberOfBands.toInt()
            var enabled by remember { mutableStateOf(eq.enabled) }
            val levels = remember { mutableStateListOf<Int>().apply { for (b in 0 until bands) add(eq.getBandLevel(b.toShort()).toInt()) } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Aktif", Modifier.weight(1f), color = c.onBg)
                NovaSwitch(enabled) { enabled = it; eq.enabled = it; vm.saveEq() }
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items((0 until eq.numberOfPresets.toInt()).toList()) { p ->
                    NovaChip(eq.getPresetName(p.toShort()), false, {
                        eq.usePreset(p.toShort())
                        for (b in 0 until bands) levels[b] = eq.getBandLevel(b.toShort()).toInt()
                        vm.saveEq()
                    })
                }
            }
            for (b in 0 until bands) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${eq.getCenterFreq(b.toShort()) / 1000} Hz", Modifier.width(76.dp), fontSize = 12.sp, color = c.onBg)
                    Slider(
                        value = levels[b].toFloat(),
                        onValueChange = { levels[b] = it.toInt(); eq.setBandLevel(b.toShort(), it.toInt().toShort()) },
                        onValueChangeFinished = { vm.saveEq() },
                        valueRange = range[0].toFloat()..range[1].toFloat(),
                        colors = SliderDefaults.colors(thumbColor = if (Nova.look.neo) c.onBg else c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.onBg.copy(alpha = 0.2f))
                    )
                }
            }
            Text("Pengaturan equalizer tersimpan otomatis.", color = c.muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun LyricsEditSheet(vm: MusicViewModel, s: Song, onDismiss: () -> Unit) {
    val c = Nova.c
    var text by remember(s.id) { mutableStateOf(vm.manualLyrics(s.id)) }
    SheetHost("Lirik buatanmu", onDismiss) {
        Text("${s.title} • ${s.artist}", color = c.muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        NovaField(text, { text = it }, "Tempel lirik biasa, atau format LRC ([00:12.50] teks) agar tersinkron", Modifier.fillMaxWidth().heightIn(max = 360.dp), singleLine = false, minHeight = 180.dp)
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
            NovaButton("Hapus", { vm.saveManualLyrics(s.id, ""); onDismiss() }, kind = BtnKind.Secondary)
            NovaButton("Simpan", { vm.saveManualLyrics(s.id, text); onDismiss() })
        }
        Text("Lirik buatanmu dipakai menggantikan lirik otomatis untuk lagu ini.", color = c.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
    }
}
