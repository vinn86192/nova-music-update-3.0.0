package com.base.musicapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.ui.AppBg
import com.base.musicapp.ui.BtnKind
import com.base.musicapp.ui.LoadingScreen
import com.base.musicapp.ui.LocalAppBg
import com.base.musicapp.ui.MainScreen
import com.base.musicapp.ui.NovaBackground
import com.base.musicapp.ui.NovaButton
import com.base.musicapp.ui.theme.MusicTheme
import com.base.musicapp.ui.theme.Nova

/**
 * Activity utama. Ikon peluncur disediakan activity-alias ".MainActivity" (nama lama dipertahankan
 * supaya pintasan layar utama dari versi sebelumnya tetap bekerja setelah update).
 */
class AppActivity : ComponentActivity() {
    private val sharedText = mutableStateOf<String?>(null)

    private fun extractShared(i: Intent?): String? =
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") i.getStringExtra(Intent.EXTRA_TEXT) else null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        sharedText.value = extractShared(intent)
        setContent {
            val vm: MusicViewModel = viewModel()
            val settings by vm.cfg.state.collectAsState()
            val themes by vm.customThemes.collectAsState()
            val dyn by vm.dynamicAccent.collectAsState()
            val art by vm.artBig.collectAsState()
            val bg = AppBg(
                settings.bgType, settings.bgPhotoPath, settings.bgVideoPath, settings.bgBlur, settings.bgDark,
                settings.bgVideoVolume, settings.bgParallax, settings.bgParallaxStrength, art
            )
            MusicTheme(settings, themes.firstOrNull { it.id == settings.themeId }, dyn) {
              CompositionLocalProvider(LocalAppBg provides bg) {
                val ctx = LocalContext.current
                val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
                var granted by remember {
                    mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED)
                }
                var asked by remember { mutableStateOf(granted) }
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
                    granted = r[audioPerm] == true
                    asked = true
                }
                LaunchedEffect(Unit) {
                    if (!granted) {
                        val req = mutableListOf(audioPerm)
                        if (Build.VERSION.SDK_INT >= 33) req += Manifest.permission.POST_NOTIFICATIONS
                        launcher.launch(req.toTypedArray())
                    }
                }
                LaunchedEffect(granted) { if (granted) vm.load() }
                LaunchedEffect(sharedText.value) {
                    sharedText.value?.let { vm.onSharedText(it); sharedText.value = null }
                }

                val libReady by vm.libraryReady.collectAsState()
                var splashDone by remember { mutableStateOf(false) }
                val ready = asked && (libReady || !granted)

                Box(Modifier.fillMaxSize()) {
                    if (granted) MainScreen(vm) else {
                        val c = Nova.c
                        NovaBackground {
                            Column(
                                Modifier.fillMaxSize().padding(32.dp),
                                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("NovaMusic", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = c.onBg)
                                Spacer(Modifier.height(12.dp))
                                Text("Izinkan akses ke file audio agar lagu di perangkat bisa dimuat.", color = c.muted, textAlign = TextAlign.Center)
                                Spacer(Modifier.height(20.dp))
                                NovaButton("Beri izin", { launcher.launch(arrayOf(audioPerm)) }, kind = BtnKind.Primary)
                            }
                        }
                    }
                    if (!splashDone) LoadingScreen(ready) { splashDone = true }
                }
              }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedText.value = extractShared(intent)
    }
}
