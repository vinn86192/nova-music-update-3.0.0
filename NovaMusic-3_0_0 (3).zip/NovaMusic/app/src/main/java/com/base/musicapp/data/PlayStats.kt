package com.base.musicapp.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.Calendar

/** Satu sesi mendengarkan. [counted] = dihitung sebagai 1 kali putar (>= 30 detik atau >= 50% lagu). */
data class PlayEvent(
    val ts: Long, val songId: Long, val ms: Long, val counted: Boolean,
    val title: String, val artist: String, val album: String
)

data class RankItem(val name: String, val sub: String, val plays: Int, val ms: Long)

data class StatsResult(
    val totalMs: Long,
    val plays: Int,
    val uniqueSongs: Int,
    val topTracks: List<RankItem>,
    val topArtists: List<RankItem>,
    val topAlbums: List<RankItem>,
    val dailyMs: List<Pair<Long, Long>>,   // (awal hari, ms) 30 hari terakhir, urut lama -> baru
    val history: List<PlayEvent>
)

class PlayStats(ctx: Context) {
    private val file = File(ctx.filesDir, "plays.jsonl")

    @Synchronized fun append(e: PlayEvent) {
        val o = JSONObject().put("t", e.ts).put("i", e.songId).put("m", e.ms).put("c", e.counted)
            .put("ti", e.title).put("a", e.artist).put("al", e.album)
        file.appendText(o.toString() + "\n")
    }

    @Synchronized fun readAll(): List<PlayEvent> {
        if (!file.exists()) return emptyList()
        val out = ArrayList<PlayEvent>()
        file.forEachLine { line ->
            runCatching {
                val o = JSONObject(line)
                out += PlayEvent(o.getLong("t"), o.getLong("i"), o.getLong("m"), o.optBoolean("c"), o.optString("ti"), o.optString("a"), o.optString("al"))
            }
        }
        return out
    }

    @Synchronized fun clear() { file.delete() }

    @Synchronized fun exportText(): String = if (file.exists()) file.readText() else ""
    @Synchronized fun importText(text: String) {
        if (text.isBlank()) return
        val have = readAll().map { it.ts to it.songId }.toSet()
        text.lineSequence().forEach { l ->
            runCatching {
                val o = JSONObject(l)
                if ((o.getLong("t") to o.getLong("i")) !in have) file.appendText(l + "\n")
            }
        }
    }

    /** playCounts per lagu (hanya yang counted) - dipakai playlist pintar. */
    fun playCounts(): Map<Long, Int> = readAll().filter { it.counted }.groupingBy { it.songId }.eachCount()

    companion object {
        fun dayStart(ts: Long): Long {
            val c = Calendar.getInstance().apply { timeInMillis = ts }
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

        /** [rangeDays] 0 = semua waktu. */
        fun compute(all: List<PlayEvent>, rangeDays: Int, now: Long = System.currentTimeMillis()): StatsResult {
            val from = if (rangeDays <= 0) 0L else dayStart(now) - (rangeDays - 1) * 86_400_000L
            val ev = all.filter { it.ts >= from }
            val counted = ev.filter { it.counted }

            fun rank(key: (PlayEvent) -> String, sub: (PlayEvent) -> String) = ev.groupBy(key).map { (k, l) ->
                RankItem(k, sub(l.first()), l.count { it.counted }, l.sumOf { it.ms })
            }.filter { it.plays > 0 || it.ms > 0 }.sortedWith(compareByDescending<RankItem> { it.plays }.thenByDescending { it.ms }).take(10)

            val days = ArrayList<Pair<Long, Long>>()
            val today = dayStart(now)
            for (i in 29 downTo 0) {
                val d = today - i * 86_400_000L
                days += d to all.filter { it.ts >= d && it.ts < d + 86_400_000L }.sumOf { it.ms }
            }
            return StatsResult(
                totalMs = ev.sumOf { it.ms },
                plays = counted.size,
                uniqueSongs = counted.map { it.songId }.distinct().size,
                topTracks = rank({ it.songId.toString() + "|" + it.title }, { it.artist }).map { it.copy(name = it.name.substringAfter('|')) },
                topArtists = rank({ it.artist }, { "" }),
                topAlbums = rank({ it.album + "|" + it.artist }, { it.artist }).map { it.copy(name = it.name.substringBefore('|')) },
                dailyMs = days,
                history = all.sortedByDescending { it.ts }.take(60)
            )
        }
    }
}
