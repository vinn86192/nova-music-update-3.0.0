package com.base.musicapp.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.base.musicapp.R
import kotlinx.coroutines.delay

/**
 * Layar pembuka Nova 3.0: logo bintang-orbit di atas latar hitam dengan glow oranye yang berdenyut halus.
 * Tampil minimal 2,2 detik, lalu memudar begitu aplikasi siap ([ready]).
 */
@Composable
fun LoadingScreen(ready: Boolean, onFinished: () -> Unit) {
    var minElapsed by remember { mutableStateOf(false) }
    var fade by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true; delay(2200); minElapsed = true }
    LaunchedEffect(ready, minElapsed) {
        if (ready && minElapsed) { fade = true; delay(750); onFinished() }
    }
    val fadeAlpha by animateFloatAsState(if (fade) 0f else 1f, tween(700), label = "splash")
    val appear by animateFloatAsState(if (shown) 1f else 0f, tween(900), label = "appear")
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "glow"
    )

    Box(
        Modifier.fillMaxSize().background(Color(0xFF050505))
            .graphicsLayer { alpha = fadeAlpha }
            .pointerInput(Unit) { detectTapGestures { } },   // sentuhan tidak tembus ke layar di bawahnya
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(320.dp)
                .graphicsLayer { scaleX = pulse; scaleY = pulse; alpha = appear * 0.9f }
                .background(Brush.radialGradient(listOf(Color(0x55FF7A00), Color.Transparent)), CircleShape)
        )
        Image(
            painterResource(R.drawable.nova_logo), null,
            modifier = Modifier.size(168.dp)
                .graphicsLayer { alpha = appear; scaleX = 0.88f + 0.12f * appear; scaleY = 0.88f + 0.12f * appear }
        )
    }
}
