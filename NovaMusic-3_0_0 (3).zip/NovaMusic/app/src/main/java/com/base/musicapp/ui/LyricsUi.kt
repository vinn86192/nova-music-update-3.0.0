package com.base.musicapp.ui

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.TimedLyric
import com.base.musicapp.ui.theme.Nova
import kotlin.math.abs

/**
 * Lirik: baris aktif disorot (warna + skala), baris lain memudar menurut jaraknya,
 * daftar otomatis menggulir halus agar baris aktif tetap di tengah. Sentuh baris untuk melompat ke waktunya.
 * Jika pengguna menggulir sendiri, auto-scroll berhenti sebentar (3,5 detik).
 */
@Composable
fun LyricsView(
    lines: List<TimedLyric>,
    synced: Boolean,
    activeIndex: Int,
    translation: List<String>?,
    status: String,
    loading: Boolean,
    modifier: Modifier = Modifier,
    big: Boolean = true,
    onSeek: (Long) -> Unit
) {
    val c = Nova.c
    if (lines.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text(if (loading) "Mencari lirik…" else status, color = c.muted, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
        }
        return
    }
    val state = rememberLazyListState()
    val dragged by state.interactionSource.collectIsDraggedAsState()
    var userUntil by remember { mutableLongStateOf(0L) }
    LaunchedEffect(dragged) { if (dragged) userUntil = SystemClock.elapsedRealtime() + 3500 }
    LaunchedEffect(activeIndex, lines) {
        if (synced && activeIndex >= 0 && SystemClock.elapsedRealtime() > userUntil) {
            val h = state.layoutInfo.viewportSize.height
            state.animateScrollToItem(activeIndex, -(h / 3))
        }
    }
    LazyColumn(modifier, state = state, contentPadding = PaddingValues(vertical = 140.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        itemsIndexed(lines) { i, line ->
            val active = synced && i == activeIndex
            val dist = if (synced && activeIndex >= 0) abs(i - activeIndex) else 0
            val targetAlpha = when {
                !synced -> 0.92f
                active -> 1f
                else -> (0.6f - 0.1f * minOf(dist, 3)).coerceAtLeast(0.25f)
            }
            val alpha by animateFloatAsState(targetAlpha, tween(380), label = "la")
            val scale by animateFloatAsState(if (active) 1.07f else 1f, tween(380), label = "ls")
            val color by animateColorAsState(if (active) c.accent else c.onBg, tween(380), label = "lc")
            Column(
                Modifier.fillMaxWidth()
                    .clickable(enabled = synced && line.timeMs >= 0) { onSeek(line.timeMs) }
                    .padding(horizontal = 14.dp, vertical = 7.dp)
                    .graphicsLayer { this.alpha = alpha; scaleX = scale; scaleY = scale },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    line.text.ifBlank { "♪" }, color = color, textAlign = TextAlign.Center,
                    fontSize = if (big) 22.sp else 16.sp, lineHeight = if (big) 29.sp else 22.sp,
                    fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold
                )
                val tr = translation?.getOrNull(i)
                if (!tr.isNullOrBlank() && tr != line.text) {
                    Text(tr, color = c.muted, textAlign = TextAlign.Center, fontSize = if (big) 15.sp else 12.sp, lineHeight = if (big) 20.sp else 16.sp)
                }
            }
        }
    }
}
