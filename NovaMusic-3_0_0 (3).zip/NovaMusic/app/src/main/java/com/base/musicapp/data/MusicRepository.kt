package com.base.musicapp.data

import android.content.Context
import android.os.Build
import android.provider.MediaStore
import java.io.File

object MusicRepository {
    /**
     * Membaca library dari MediaStore. Aman terhadap kolom null / perangkat tertentu:
     * jika query lengkap gagal, dicoba lagi dengan kolom minimal.
     */
    fun load(ctx: Context, minDurationSec: Int = 30, excludedFolders: Set<String> = emptySet()): List<Song> {
        val full = buildList {
            add(MediaStore.Audio.Media._ID); add(MediaStore.Audio.Media.TITLE); add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM); add(MediaStore.Audio.Media.ALBUM_ID); add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DATE_ADDED); add(MediaStore.Audio.Media.DATA); add(MediaStore.Audio.Media.YEAR)
            if (Build.VERSION.SDK_INT >= 30) add(MediaStore.Audio.Media.GENRE)
        }.toTypedArray()
        val minimal = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        return runCatching { query(ctx, full, minDurationSec, excludedFolders) }.getOrNull()
            ?: runCatching { query(ctx, minimal, minDurationSec, excludedFolders) }.getOrNull()
            ?: emptyList()
    }

    private fun query(ctx: Context, projection: Array<String>, minSec: Int, excluded: Set<String>): List<Song> {
        val out = ArrayList<Song>()
        val minMs = minSec.coerceAtLeast(0) * 1000L
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > $minMs"
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            fun idx(n: String) = c.getColumnIndex(n)
            val iId = idx(MediaStore.Audio.Media._ID); val iTitle = idx(MediaStore.Audio.Media.TITLE)
            val iArtist = idx(MediaStore.Audio.Media.ARTIST); val iAlbum = idx(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = idx(MediaStore.Audio.Media.ALBUM_ID); val iDur = idx(MediaStore.Audio.Media.DURATION)
            val iAdded = idx(MediaStore.Audio.Media.DATE_ADDED); val iData = idx(MediaStore.Audio.Media.DATA)
            val iYear = idx(MediaStore.Audio.Media.YEAR)
            val iGenre = if (Build.VERSION.SDK_INT >= 30) idx(MediaStore.Audio.Media.GENRE) else -1
            if (iId < 0) return emptyList()
            while (c.moveToNext()) {
                runCatching {
                    val id = c.getLong(iId)
                    val path = if (iData >= 0) c.getString(iData).orEmpty() else ""
                    val folder = if (path.isNotEmpty()) File(path).parent.orEmpty() else ""
                    if (folder.isNotEmpty() && folder in excluded) return@runCatching
                    val artist = if (iArtist >= 0) c.getString(iArtist) else null
                    out += Song(
                        id = id,
                        title = (if (iTitle >= 0) c.getString(iTitle) else null)?.takeIf { it.isNotBlank() } ?: "Tanpa judul",
                        artist = artist?.takeIf { it != "<unknown>" && it.isNotBlank() } ?: "Artis tidak diketahui",
                        album = (if (iAlbum >= 0) c.getString(iAlbum) else null)?.takeIf { it.isNotBlank() } ?: "Album tidak diketahui",
                        albumId = if (iAlbumId >= 0) c.getLong(iAlbumId) else 0L,
                        duration = if (iDur >= 0) c.getLong(iDur) else 0L,
                        dateAdded = if (iAdded >= 0) c.getLong(iAdded) else 0L,
                        uri = Song.uriFor(id),
                        folder = folder,
                        genre = if (iGenre >= 0) c.getString(iGenre).orEmpty() else "",
                        year = if (iYear >= 0) c.getInt(iYear) else 0
                    )
                }
            }
        }
        return out
    }
}
