package com.base.musicapp.data

import kotlin.math.abs

enum class Mood(val label: String, val hint: String) {
    CHILL("Santai", "akustik, lo-fi, jazz, lagu pelan"),
    ENERGETIC("Semangat", "rock, EDM, hip-hop, lagu cepat"),
    SAD("Galau", "lagu sendu dan patah hati"),
    FOCUS("Fokus", "instrumental, klasik, ambient"),
    PARTY("Pesta", "dance, remix, club"),
    ROMANTIC("Romantis", "lagu cinta dan ballad")
}

data class MetaSuggestion(val song: Song, val newTitle: String, val newArtist: String?, val reason: String)
data class GenResult(val title: String, val note: String, val songs: List<Song>)

/**
 * Logika "pintar" yang berjalan 100% di perangkat (tanpa AI online dan tanpa analisis audio).
 * Mood = perkiraan dari genre tag + kata kunci judul/artis/album + durasi. Hasilnya bukan analisis suara.
 */
object Smart {
    private val moodWords: Map<Mood, List<String>> = mapOf(
        Mood.CHILL to listOf("acoustic", "akustik", "lofi", "lo-fi", "chill", "jazz", "bossa", "unplugged", "relax", "santai", "easy", "folk", "soft", "calm", "sunset", "coffee", "kopi", "senja", "hujan", "rain"),
        Mood.ENERGETIC to listOf("rock", "metal", "punk", "edm", "hip hop", "hip-hop", "rap", "trap", "workout", "gym", "run", "power", "fire", "energy", "semangat", "bangkit", "fight", "champion", "go", "wild"),
        Mood.SAD to listOf("sad", "cry", "tears", "lonely", "alone", "broken", "goodbye", "miss", "hurt", "pain", "heartbreak", "galau", "sedih", "air mata", "rindu", "kehilangan", "pergi", "luka", "sakit", "patah", "tangis", "sepi"),
        Mood.FOCUS to listOf("instrumental", "classical", "klasik", "piano", "ambient", "study", "focus", "concerto", "symphony", "sonata", "meditation", "sleep", "ost", "score", "soundtrack"),
        Mood.PARTY to listOf("dance", "party", "club", "remix", "disco", "house", "dj", "bass", "dangdut", "koplo", "funky", "pesta", "night", "tonight", "bounce"),
        Mood.ROMANTIC to listOf("love", "cinta", "sayang", "kasih", "heart", "kiss", "romance", "romantic", "ballad", "valentine", "forever", "marry", "wedding", "hati", "rindu", "jatuh cinta", "darling", "baby")
    )

    fun moodScores(s: Song): Map<Mood, Int> {
        val text = " ${s.genre} ${s.title} ${s.artist} ${s.album} ".lowercase()
        val out = HashMap<Mood, Int>()
        for ((m, words) in moodWords) {
            var sc = 0
            for (w in words) if (text.contains(w)) sc += if (s.genre.lowercase().contains(w)) 3 else 1
            if (sc > 0) out[m] = sc
        }
        // instrumental/klasik biasanya panjang; EDM/pesta biasanya 3-4 menit
        if (s.duration > 6 * 60_000L) out[Mood.FOCUS] = (out[Mood.FOCUS] ?: 0) + 1
        return out
    }

    fun mood(s: Song): Mood? = moodScores(s).maxByOrNull { it.value }?.key

    fun byMood(songs: List<Song>): Map<Mood, List<Song>> {
        val m = LinkedHashMap<Mood, MutableList<Song>>()
        Mood.values().forEach { m[it] = ArrayList() }
        songs.forEach { s -> mood(s)?.let { m[it]!!.add(s) } }
        return m
    }

    // ------------------------------------------------------------ duplikat
    fun duplicates(songs: List<Song>): List<List<Song>> {
        val groups = songs.groupBy { SpotifyMatcher.norm(it.title) + "|" + SpotifyMatcher.norm(it.artist) }
            .filter { it.key.length > 3 && it.value.size > 1 }.values
        val out = ArrayList<List<Song>>()
        for (g in groups) {
            // pisahkan yang durasinya berbeda jauh (versi berbeda)
            val sorted = g.sortedBy { it.duration }
            var cur = arrayListOf(sorted.first())
            for (s in sorted.drop(1)) {
                if (abs(s.duration - cur.last().duration) <= 3000) cur.add(s) else { if (cur.size > 1) out += cur; cur = arrayListOf(s) }
            }
            if (cur.size > 1) out += cur
        }
        return out.sortedByDescending { it.size }
    }

    // ------------------------------------------------------------ perbaikan metadata
    private val junk = Regex(
        """\s*[(\[]\s*(official|lyric|lyrics|audio|video|music video|mv|hd|hq|4k|visualizer|full|clip|live|explicit|remaster(ed)?)[^)\]]*[)\]]|\s*-\s*(official|lyrics?|audio|video)\b.*$|\s*\b(www\.\S+|\S+\.(com|net|org|info|me))\b|\s*\b(320|128|192)\s?kbps\b|^\s*\d{1,3}\s*[-._)]\s+""",
        RegexOption.IGNORE_CASE
    )

    fun suggestions(songs: List<Song>, overrides: Map<Long, MetaOverride>): List<MetaSuggestion> {
        val out = ArrayList<MetaSuggestion>()
        for (s in songs) {
            if (overrides.containsKey(s.id)) continue
            var title = s.title.replace('_', ' ').trim()
            var artist: String? = null
            var reason = ""
            val cleaned = junk.replace(title, "").replace(Regex("\\s+"), " ").trim()
            if (cleaned != title && cleaned.isNotBlank()) { title = cleaned; reason = "Membersihkan tulisan tambahan di judul" }
            if (s.artist.startsWith("Artis tidak")) {
                val m = Regex("""^(.{2,}?)\s+[-–—]\s+(.{2,})$""").find(title)
                if (m != null) { artist = m.groupValues[1].trim(); title = m.groupValues[2].trim(); reason = "Memisahkan \"Artis - Judul\" dari judul" }
            }
            if (title != s.title || artist != null) out += MetaSuggestion(s, title, artist, reason.ifEmpty { "Merapikan judul" })
        }
        return out
    }

    // ------------------------------------------------------------ generator playlist
    /**
     * Membaca perintah teks bebas (mis. "lagu santai 45 menit", "semangat olahraga", "favorit artis Dewa")
     * dengan aturan kata kunci lokal. Bukan model AI online.
     */
    fun generate(
        prompt: String, songs: List<Song>, favs: Set<Long>, counts: Map<Long, Int>, recents: List<Long>
    ): GenResult {
        val p = prompt.lowercase().trim()
        if (songs.isEmpty()) return GenResult("Playlist", "Library masih kosong.", emptyList())

        var minutes = Regex("""(\d{1,3})\s*(menit|min)""").find(p)?.groupValues?.get(1)?.toIntOrNull()
        Regex("""(\d{1,2})\s*jam""").find(p)?.groupValues?.get(1)?.toIntOrNull()?.let { minutes = it * 60 }
        val count = Regex("""(\d{1,3})\s*lagu""").find(p)?.groupValues?.get(1)?.toIntOrNull()

        val notes = ArrayList<String>()
        var pool: List<Song> = songs
        val moods = Mood.values().filter { m -> p.contains(m.label.lowercase()) || m.name.lowercase().let { p.contains(it) } ||
            (m == Mood.ENERGETIC && listOf("olahraga", "gym", "lari", "workout", "energi").any { p.contains(it) }) ||
            (m == Mood.CHILL && listOf("tenang", "malam", "tidur", "relax", "kerja santai").any { p.contains(it) }) ||
            (m == Mood.SAD && listOf("sedih", "patah hati", "sendu").any { p.contains(it) }) ||
            (m == Mood.FOCUS && listOf("belajar", "kerja", "study", "konsentrasi").any { p.contains(it) }) }
        if (moods.isNotEmpty()) {
            val scored = songs.filter { s -> moods.any { m -> (moodScores(s)[m] ?: 0) > 0 } }
            if (scored.isNotEmpty()) { pool = scored; notes += "mood " + moods.joinToString("/") { it.label } }
        }
        val artists = songs.map { it.artist }.distinct().filter { a -> a.length >= 3 && !a.startsWith("Artis tidak") && p.contains(SpotifyMatcher.norm(a)) && SpotifyMatcher.norm(a).length >= 3 }
        if (artists.isNotEmpty()) { pool = pool.filter { it.artist in artists }.ifEmpty { songs.filter { it.artist in artists } }; notes += "artis " + artists.take(3).joinToString() }
        if (p.contains("favorit") && favs.isNotEmpty()) { pool = pool.filter { it.id in favs }.ifEmpty { songs.filter { it.id in favs } }; notes += "favorit" }
        var ordered: List<Song> = pool.shuffled()
        when {
            listOf("sering", "populer", "terbanyak", "top").any { p.contains(it) } -> { ordered = pool.sortedByDescending { counts[it.id] ?: 0 }; notes += "paling sering diputar" }
            listOf("jarang", "lupa", "temukan", "rediscover").any { p.contains(it) } -> { ordered = pool.sortedBy { counts[it.id] ?: 0 }.take(maxOf(pool.size / 2, 20)).shuffled(); notes += "jarang diputar" }
            listOf("baru", "terbaru").any { p.contains(it) } -> { ordered = pool.sortedByDescending { it.dateAdded }; notes += "terbaru ditambahkan" }
            listOf("lama", "jadul", "nostalgia").any { p.contains(it) } -> { ordered = pool.filter { it.year in 1..2012 }.ifEmpty { pool }.shuffled(); notes += "lagu lama" }
            listOf("kemarin", "terakhir").any { p.contains(it) } && recents.isNotEmpty() -> { ordered = recents.mapNotNull { id -> songs.firstOrNull { it.id == id } }; notes += "terakhir diputar" }
        }
        // kata kunci bebas (jika tidak ada aturan lain yang cocok)
        if (notes.isEmpty()) {
            val words = p.split(Regex("\\s+")).filter { it.length >= 3 && it !in setOf("lagu", "untuk", "yang", "dengan", "playlist", "buat", "buatkan", "menit", "jam") }
            if (words.isNotEmpty()) {
                val hit = songs.filter { s -> val t = "${s.title} ${s.artist} ${s.album} ${s.genre}".lowercase(); words.any { t.contains(it) } }
                if (hit.isNotEmpty()) { ordered = hit.shuffled(); notes += "kata kunci: " + words.joinToString(" ") }
            }
        }
        if (notes.isEmpty()) notes += "campuran acak dari library"

        val result = ArrayList<Song>()
        var total = 0L
        val limitMs = (minutes ?: 0) * 60_000L
        for (s in ordered) {
            if (count != null && result.size >= count) break
            if (limitMs > 0 && total >= limitMs) break
            if (count == null && limitMs == 0L && result.size >= 30) break
            result += s; total += s.duration
        }
        val title = prompt.trim().take(28).ifEmpty { "Playlist pintar" }.replaceFirstChar { it.uppercase() }
        return GenResult(title, "Dibuat dari: ${notes.joinToString(", ")} • ${result.size} lagu • ${total / 60000} menit", result)
    }

    // ------------------------------------------------------------ antrean pintar
    fun similar(cur: Song, all: List<Song>, exclude: Set<Long>, counts: Map<Long, Int>, n: Int): List<Song> {
        val curMood = moodScores(cur)
        return all.asSequence().filter { it.id !in exclude }.map { s ->
            var sc = 0.0
            if (s.artist == cur.artist && !s.artist.startsWith("Artis tidak")) sc += 3.0
            if (s.albumId == cur.albumId && s.albumId != 0L) sc += 2.0
            if (s.genre.isNotEmpty() && s.genre.equals(cur.genre, true)) sc += 1.5
            val sm = moodScores(s)
            sc += curMood.keys.count { it in sm.keys } * 1.2
            if (cur.year > 0 && s.year > 0 && abs(cur.year - s.year) <= 3) sc += 0.5
            sc += minOf(counts[s.id] ?: 0, 10) * 0.05 + Math.random() * 0.9
            s to sc
        }.filter { it.second >= 1.0 }.sortedByDescending { it.second }.take(n).map { it.first }.toList()
    }
}
