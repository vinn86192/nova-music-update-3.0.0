package com.base.musicapp.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.*
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.ui.theme.*

private class Confirm(val title: String, val text: String, val action: () -> Unit)

@Composable
fun SettingsScreen(vm: MusicViewModel, onOpen: (Page) -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val cfg by vm.cfg.state.collectAsState()
    val songs by vm.songs.collectAsState()
    val spotify by vm.spotifyLists.collectAsState()
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    fun up(block: AppSettings.() -> AppSettings) = vm.cfg.update { it.block() }
    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportBackup(uri) { ok -> toast(if (ok) "Cadangan tersimpan" else "Gagal menyimpan cadangan") }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setBackgroundPhoto(uri) { ok -> toast(if (ok) "Foto latar dipasang" else "Gagal memasang foto") }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { toast("Menyalin video…"); vm.setBackgroundVideo(uri) { ok -> toast(if (ok) "Video latar dipasang" else "Gagal memasang video") } }
    }
    var cacheInfo by remember { mutableStateOf(vm.lyricsCacheInfo()) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importBackup(uri) { ok -> toast(if (ok) "Cadangan dipulihkan (digabung)" else "File cadangan tidak valid") }
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenTitle("Pengaturan", "Atur tampilan dan perilaku NovaMusic") }

        // ------------------------------------------------------------ GAYA & TEMA
        item {
            Group("Gaya & tema", Icons.Rounded.Palette, startOpen = true) {
                Label("Gaya antarmuka")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    UiStyle.values().forEach { st ->
                        StyleCard(st, cfg, cfg.style == st, Modifier.weight(1f)) { up { copy(style = st) } }
                    }
                }
                Label("Mode tema")
                Chips(ThemeMode.values().toList(), cfg.themeMode, { it.label }) { up { copy(themeMode = it) } }
                Label("Warna aksen")
                PalettePicker(cfg.palette) { up { copy(palette = it) } }
                if (cfg.style == UiStyle.GLASS) {
                    SliderRow("Transparansi kaca", "${cfg.glassOpacity}%", cfg.glassOpacity, 4..30) { up { copy(glassOpacity = it) } }
                    SliderRow("Kelengkungan sudut", "${cfg.glassRadius} dp", cfg.glassRadius, 8..36) { up { copy(glassRadius = it) } }
                } else {
                    SliderRow("Ketebalan border", "${cfg.neoBorder} dp", cfg.neoBorder, 1..6) { up { copy(neoBorder = it) } }
                    SliderRow("Hard shadow", "${cfg.neoShadow} dp", cfg.neoShadow, 0..10) { up { copy(neoShadow = it) } }
                    SliderRow("Kelengkungan sudut", "${cfg.neoRadius} dp", cfg.neoRadius, 0..24) { up { copy(neoRadius = it) } }
                }
                SwitchRow("Animasi", "Latar bergerak (glass) dan efek lain", cfg.animations) { up { copy(animations = it) } }
            }
        }

        // ------------------------------------------------------------ LATAR & PERSONALISASI
        item {
            Group("Latar & personalisasi", Icons.Rounded.Wallpaper) {
                Label("Latar aplikasi")
                Chips(BgType.values().toList(), cfg.bgType, { it.label }) { t ->
                    val ok = when (t) {
                        BgType.PHOTO -> cfg.bgPhotoPath.isNotEmpty()
                        BgType.VIDEO -> cfg.bgVideoPath.isNotEmpty()
                        else -> true
                    }
                    if (ok) up { copy(bgType = t) } else toast(if (t == BgType.PHOTO) "Pilih foto dulu" else "Pilih video dulu")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NovaButton("Pilih foto", { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, Modifier.weight(1f), Icons.Rounded.Image, BtnKind.Secondary)
                    NovaButton("Pilih video", { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, Modifier.weight(1f), Icons.Rounded.Videocam, BtnKind.Secondary)
                }
                if (cfg.bgType != BgType.NONE) {
                    SliderRow("Blur latar", "${cfg.bgBlur}%", cfg.bgBlur, 0..100) { up { copy(bgBlur = it) } }
                    SliderRow("Kegelapan latar", "${cfg.bgDark}%", cfg.bgDark, 0..90) { up { copy(bgDark = it) } }
                    SwitchRow("Efek parallax", "Latar bergeser mengikuti kemiringan HP", cfg.bgParallax) { up { copy(bgParallax = it) } }
                    if (cfg.bgParallax) SliderRow("Kekuatan parallax", "${cfg.bgParallaxStrength}%", cfg.bgParallaxStrength, 10..100) { up { copy(bgParallaxStrength = it) } }
                }
                if (cfg.bgType == BgType.VIDEO) {
                    SliderRow("Volume video latar", if (cfg.bgVideoVolume == 0) "Senyap" else "${cfg.bgVideoVolume}%", cfg.bgVideoVolume, 0..100) { up { copy(bgVideoVolume = it) } }
                    Text("Video diputar berulang tanpa henti dan berhenti saat aplikasi di latar belakang.", color = c.muted, fontSize = 12.sp)
                }
                SwitchRow("Warna dinamis dari album", "Warna aksen mengikuti cover lagu yang diputar", cfg.dynamicColor) { up { copy(dynamicColor = it) } }
                NovaButton("Studio tema (warna kustom)", { onOpen(Page.THEMES) }, Modifier.fillMaxWidth(), Icons.Rounded.ColorLens, BtnKind.Secondary)
                Label("Desain pemutar")
                Chips(PlayerLayout.values().toList(), cfg.playerLayout, { it.label }) { up { copy(playerLayout = it) } }
                Label("Efek animasi Now Playing")
                Chips(NowEffect.values().toList(), cfg.nowEffect, { it.label }) { up { copy(nowEffect = it) } }
                SwitchRow("Kontrol gestur", "Geser kiri/kanan = lagu, ketuk 2x = putar/jeda, geser bawah = tutup, geser atas = antrean", cfg.gestures) { up { copy(gestures = it) } }
                Label("Ikon aplikasi")
                Chips(AppIcons.options.map { it.first }, cfg.appIcon, { k -> AppIcons.options.first { it.first == k }.second }) { up { copy(appIcon = it) } }
                Text("Pergantian ikon bisa butuh beberapa detik di peluncur layar utama.", color = c.muted, fontSize = 11.sp)
            }
        }

        // ------------------------------------------------------------ LIRIK
        item {
            Group("Lirik", Icons.Rounded.Notes) {
                SwitchRow("Lirik otomatis", "Cari lirik tersinkron dari LRCLIB saat lagu diputar", cfg.lyricsAuto) { up { copy(lyricsAuto = it) } }
                SwitchRow("Terjemahan lirik", "Tampilkan terjemahan di bawah tiap baris", cfg.lyricsTranslate) { vm.setTranslate(it) }
                Label("Bahasa terjemahan")
                Chips(listOf("id", "en", "ja", "ko", "es", "ar"), cfg.lyricsLang, { listOf("id" to "Indonesia", "en" to "Inggris", "ja" to "Jepang", "ko" to "Korea", "es" to "Spanyol", "ar" to "Arab").first { p -> p.first == it }.second }) { vm.setTranslateLang(it) }
                Text("Terjemahan memakai layanan web Google Translate (tidak resmi) dan butuh internet.", color = c.muted, fontSize = 11.sp)
                Text("Cache offline: ${cacheInfo.first} lagu • ${cacheInfo.second / 1024} KB. Lirik yang pernah dimuat tetap tampil tanpa internet.", color = c.muted, fontSize = 12.sp)
                NovaButton("Hapus cache lirik", { vm.clearLyricsCache(); cacheInfo = vm.lyricsCacheInfo(); toast("Cache lirik dihapus") }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, BtnKind.Secondary)
            }
        }

        // ------------------------------------------------------------ TAMPILAN DAFTAR
        item {
            Group("Teks & daftar lagu", Icons.Rounded.TextFields) {
                Label("Ukuran teks")
                Chips(listOf(85, 100, 115, 130), cfg.fontScale, { "$it%" }) { up { copy(fontScale = it) } }
                SwitchRow("Daftar rapat", "Baris lebih kecil, muat lebih banyak lagu", cfg.compactList) { up { copy(compactList = it) } }
                SwitchRow("Tampilkan cover di daftar", null, cfg.showArt) { up { copy(showArt = it) } }
                Label("Bentuk cover")
                Chips(ArtShape.values().toList(), cfg.artShape, { it.label }) { up { copy(artShape = it) } }
                if (cfg.style == UiStyle.GLASS) {
                    SwitchRow("Latar blur di Now Playing", "Cover diburamkan jadi latar (Android 12+)", cfg.blurNowPlaying) { up { copy(blurNowPlaying = it) } }
                }
            }
        }

        // ------------------------------------------------------------ BERANDA
        item {
            Group("Beranda", Icons.Rounded.Home) {
                Label("Nama panggilan")
                NovaField(cfg.userName, { up { copy(userName = it.take(24)) } }, "Muncul di sapaan", Modifier.fillMaxWidth())
                SwitchRow("Statistik library", "Jumlah lagu, album, artis", cfg.showStats) { up { copy(showStats = it) } }
                SwitchRow("Terakhir diputar", null, cfg.showRecents) { up { copy(showRecents = it) } }
                SwitchRow("Baru ditambahkan", null, cfg.showLatest) { up { copy(showLatest = it) } }
                SwitchRow("Favorit kamu", null, cfg.showFavs) { up { copy(showFavs = it) } }
                Label("Jumlah lagu di \"Semua lagu\"")
                Chips(listOf(20, 40, 80, 0), cfg.homeSongLimit, { if (it == 0) "Semua" else "$it" }) { up { copy(homeSongLimit = it) } }
            }
        }

        // ------------------------------------------------------------ PEMUTARAN
        item {
            Group("Pemutaran", Icons.Rounded.GraphicEq) {
                SwitchRow("Lanjutkan antrean terakhir", "Buka aplikasi di lagu terakhir, posisi tersimpan", cfg.resumeQueue) { up { copy(resumeQueue = it) } }
                SwitchRow("Lewati bagian hening", "Memotong jeda sunyi di dalam lagu", cfg.skipSilence) { up { copy(skipSilence = it) } }
                SwitchRow("Jeda saat headset dicabut", null, cfg.pauseOnNoisy) { up { copy(pauseOnNoisy = it) } }
                SwitchRow("Hormati aplikasi audio lain", "Jeda/kecilkan volume saat ada suara lain", cfg.audioFocus) { up { copy(audioFocus = it) } }
                SwitchRow("Putar otomatis saat headset tersambung", "Melanjutkan lagu ketika headset/Bluetooth tersambung", cfg.autoPlayHeadset) { up { copy(autoPlayHeadset = it) } }
                Label("Transisi antar lagu")
                Chips(listOf(0, 2, 4, 6, 8, 12), cfg.crossfadeSec, { if (it == 0) "Gapless" else "Crossfade ${it}s" }) { up { copy(crossfadeSec = it) } }
                Text(if (cfg.crossfadeSec == 0) "Gapless: lagu berikutnya menyambung tanpa jeda (untuk file yang mendukung)." else "Crossfade: akhir lagu memudar sambil lagu berikutnya naik. Berlaku untuk perpindahan otomatis.", color = c.muted, fontSize = 12.sp)
                SwitchRow("Fade saat putar/jeda", "Volume naik/turun halus", cfg.fadeOnPause) { up { copy(fadeOnPause = it) } }
                if (cfg.fadeOnPause) Chips(listOf(200, 400, 800, 1500), cfg.fadeMs, { "${it} ms" }) { up { copy(fadeMs = it) } }
                SwitchRow("Antrean pintar", "Otomatis menambah lagu mirip saat antrean hampir habis", cfg.smartQueue) { up { copy(smartQueue = it) } }
            }
        }

        // ------------------------------------------------------------ LIBRARY
        item {
            Group("Library", Icons.Rounded.LibraryMusic) {
                Label("Urutan lagu bawaan")
                Chips(SortMode.values().toList(), cfg.defaultSort, { it.label }) { up { copy(defaultSort = it) } }
                Label("Abaikan lagu lebih pendek dari")
                Chips(listOf(0, 15, 30, 60, 120), cfg.minDurationSec, { if (it == 0) "Semua" else "$it dtk" }) { up { copy(minDurationSec = it) } }
                Text("${songs.size} lagu terdeteksi", color = c.muted, fontSize = 12.sp)
                NovaButton("Pindai ulang library", { vm.load(true); toast("Memindai ulang...") }, Modifier.fillMaxWidth(), Icons.Rounded.Refresh, BtnKind.Secondary)
                NovaButton("Library pintar (mood, duplikat, metadata, folder)", { onOpen(Page.SMART) }, Modifier.fillMaxWidth(), Icons.Rounded.AutoAwesome)
            }
        }

        // ------------------------------------------------------------ SPOTIFY
        item {
            Group("Spotify", Icons.Rounded.CloudDownload) {
                Text(
                    "Impor playlist Spotify lalu cocokkan dengan lagu di perangkat. Audio Spotify sendiri tidak bisa diputar di sini; " +
                        "yang diputar adalah file lagu milikmu yang cocok.",
                    color = c.muted, fontSize = 12.sp
                )
                NovaButton("Import playlist Spotify", { onOpen(Page.SPOTIFY) }, Modifier.fillMaxWidth(), Icons.Rounded.Download)
                NovaButton("Perbarui semua playlist dari tautan", { vm.refreshAllSpotify { toast(it) } }, Modifier.fillMaxWidth(), Icons.Rounded.Refresh, BtnKind.Secondary)
                Text("Tips: di aplikasi Spotify pilih Bagikan, lalu NovaMusic, untuk langsung mengimpor playlist.", color = c.muted, fontSize = 11.sp)
                Label("Ketelitian pencocokan")
                Chips(listOf(0, 1, 2), cfg.matchLevel, { listOf("Longgar", "Sedang", "Ketat")[it] }) { up { copy(matchLevel = it) } }
                Text(
                    when (cfg.matchLevel) {
                        0 -> "Judul mirip sudah cukup. Lebih banyak cocok, kadang salah versi."
                        2 -> "Judul harus hampir sama persis dan artis/durasi sesuai."
                        else -> "Seimbang: judul, artis, dan durasi dipertimbangkan."
                    }, color = c.muted, fontSize = 12.sp
                )
                if (spotify.isNotEmpty()) {
                    NovaButton(
                        "Hapus ${spotify.size} playlist Spotify tersimpan",
                        { confirm = Confirm("Hapus playlist Spotify?", "Semua playlist hasil import akan dihapus. Lagu di perangkat tidak terpengaruh.") { vm.deleteAllSpotify() } },
                        Modifier.fillMaxWidth(), Icons.Rounded.Delete, BtnKind.Secondary
                    )
                }
            }
        }

        // ------------------------------------------------------------ STATISTIK & PENGINGAT
        item {
            Group("Statistik & pengingat", Icons.Rounded.Insights) {
                NovaButton("Buka statistik mendengarkan", { onOpen(Page.STATS) }, Modifier.fillMaxWidth(), Icons.Rounded.Insights)
                SwitchRow("Pengingat musik harian", "Notifikasi ajakan mendengarkan musik", cfg.reminderOn) { up { copy(reminderOn = it) } }
                if (cfg.reminderOn) {
                    NovaButton("Waktu pengingat: %02d:%02d".format(cfg.reminderHour, cfg.reminderMin), {
                        android.app.TimePickerDialog(ctx, { _, h, m -> up { copy(reminderHour = h, reminderMin = m) } }, cfg.reminderHour, cfg.reminderMin, true).show()
                    }, Modifier.fillMaxWidth(), Icons.Rounded.Schedule, BtnKind.Secondary)
                    Text("Waktu pengingat bisa bergeser beberapa menit (hemat baterai). Pastikan izin notifikasi aktif.", color = c.muted, fontSize = 11.sp)
                }
            }
        }

        // ------------------------------------------------------------ DATA
        item {
            Group("Data & cadangan", Icons.Rounded.Storage) {
                NovaButton("Ekspor cadangan", { exportLauncher.launch("novamusic-backup.json") }, Modifier.fillMaxWidth(), Icons.Rounded.Upload)
                NovaButton("Impor cadangan", { importLauncher.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), Icons.Rounded.Download, BtnKind.Secondary)
                Text("Cadangan berisi favorit, playlist, playlist Spotify, lirik, dan pengaturan. Saat dipulihkan, data digabung dengan yang sudah ada.", color = c.muted, fontSize = 12.sp)
                NovaButton("Hapus riwayat putar", { confirm = Confirm("Hapus riwayat?", "Daftar \"Terakhir diputar\" akan dikosongkan.") { vm.clearHistory() } }, Modifier.fillMaxWidth(), Icons.Rounded.History, BtnKind.Secondary)
                NovaButton("Hapus semua favorit", { confirm = Confirm("Hapus favorit?", "Semua lagu favorit akan dihapus dari daftar favorit.") { vm.clearFavorites() } }, Modifier.fillMaxWidth(), Icons.Rounded.FavoriteBorder, BtnKind.Secondary)
                NovaButton("Hapus semua lirik", { confirm = Confirm("Hapus lirik?", "Semua lirik yang kamu simpan akan dihapus.") { vm.clearSavedLyrics() } }, Modifier.fillMaxWidth(), Icons.Rounded.Description, BtnKind.Secondary)
                NovaButton("Reset pengaturan", { confirm = Confirm("Reset pengaturan?", "Semua pengaturan kembali ke bawaan. Playlist dan favorit tetap aman.") { vm.cfg.reset() } }, Modifier.fillMaxWidth(), Icons.Rounded.RestartAlt, BtnKind.Secondary)
            }
        }

        // ------------------------------------------------------------ TENTANG
        item {
            Group("Tentang", Icons.Rounded.Info) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NovaMark(size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("NovaMusic", color = c.onBg, fontWeight = FontWeight.Bold)
                        Text("Versi ${vm.appVersion()} • Galaxy Evolution", color = c.muted, fontSize = 12.sp)
                    }
                }
                NovaButton("Tentang NovaMusic", { onOpen(Page.ABOUT) }, Modifier.fillMaxWidth(), Icons.Rounded.Info, BtnKind.Secondary)
            }
        }
    }

    confirm?.let { cf ->
        NovaDialog(cf.title, { confirm = null }, "Ya, lanjut", { cf.action(); confirm = null }) {
            Text(cf.text, color = c.onBg, fontSize = 14.sp)
        }
    }
}

// ================================================================ KOMPONEN PENGATURAN

@Composable
private fun Group(title: String, icon: ImageVector, startOpen: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val c = Nova.c
    val neo = Nova.look.neo
    var open by remember { mutableStateOf(startOpen) }
    Column(Modifier.fillMaxWidth().panel()) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBadge(icon, 36.dp)
            Spacer(Modifier.width(14.dp))
            Text(title, color = c.onBg, fontWeight = if (neo) FontWeight.Black else FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = c.muted)
        }
        AnimatedVisibility(open) {
            Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                content()
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = Nova.c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = c.onBg, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) Text(subtitle, color = c.muted, fontSize = 12.sp)
        }
        NovaSwitch(checked, onChange)
    }
}

@Composable
private fun <T> Chips(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o -> NovaChip(label(o), o == selected, { onSelect(o) }) }
    }
}

@Composable
private fun SliderRow(title: String, valueLabel: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    val c = Nova.c
    Column {
        Row {
            Text(title, color = c.onBg, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(valueLabel, color = c.muted, fontSize = 13.sp)
        }
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(), steps = (range.last - range.first - 1).coerceAtLeast(0),
            colors = SliderDefaults.colors(thumbColor = if (Nova.look.neo) c.onBg else c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.onBg.copy(alpha = 0.18f))
        )
    }
}

@Composable
private fun PalettePicker(selected: Palette, onSelect: (Palette) -> Unit) {
    val c = Nova.c
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Palette.values().filter { it != Palette.CUSTOM }.forEach { p ->
            val sel = p == selected
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onSelect(p) }) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(p.accent, p.accent2)))
                        .border(if (sel) 3.dp else 1.dp, if (sel) c.onBg else c.onBg.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { if (sel) Icon(Icons.Rounded.Check, null, tint = bestOn(p.accent)) }
                Text(p.label, color = if (sel) c.onBg else c.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

/** Kartu pratinjau: digambar dengan gaya [style] walau gaya aktif berbeda. */
@Composable
private fun StyleCard(style: UiStyle, cfg: AppSettings, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val outer = Nova.c
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape)
            .border(if (selected) 3.dp else 1.dp, if (selected) outer.accent else outer.onBg.copy(alpha = 0.18f), shape)
            .clickable(onClick = onClick)
    ) {
        PreviewTheme(cfg.copy(style = style)) {
            val c = Nova.c
            val look = Nova.look
            Box(Modifier.fillMaxWidth().height(128.dp).background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom))).padding(10.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        Modifier.fillMaxWidth().panel(radius = if (look.radius > 14.dp) 14.dp else look.radius).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(Brush.linearGradient(listOf(c.accent, c.accent2))))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Box(Modifier.height(6.dp).width(58.dp).clip(CircleShape).background(c.onBg.copy(alpha = 0.85f)))
                            Spacer(Modifier.height(5.dp))
                            Box(Modifier.height(5.dp).width(36.dp).clip(CircleShape).background(c.muted))
                        }
                    }
                    Box(
                        Modifier.height(28.dp).width(86.dp).panel(radius = 10.dp, fill = c.accent),
                        contentAlignment = Alignment.Center
                    ) { Text("Putar", color = c.onAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(style.label, color = outer.onBg, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
            if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = outer.accent, modifier = Modifier.size(18.dp))
        }
    }
}
