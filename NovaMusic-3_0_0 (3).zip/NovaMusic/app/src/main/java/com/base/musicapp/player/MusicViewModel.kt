package com.base.musicapp.player

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.IntentSender
import android.database.ContentObserver
import android.graphics.Bitmap
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.base.musicapp.MusicApp
import com.base.musicapp.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    private val player = (app as MusicApp).player
    private val store = Store(app)
    private val stats = PlayStats(app)
    val cfg = SettingsStore(app)
    private var byId: Map<Long, Song> = emptyMap()
    private var allSongs: List<Song> = emptyList()

    // ---- library & pemutaran
    val songs = MutableStateFlow<List<Song>>(emptyList())
    val folders = MutableStateFlow<Map<String, Int>>(emptyMap())
    val excludedFolders = MutableStateFlow(store.excludedFolders())
    val loading = MutableStateFlow(false)
    val libraryReady = MutableStateFlow(false)
    val current = MutableStateFlow<Song?>(null)
    val isPlaying = MutableStateFlow(false)
    val position = MutableStateFlow(0L)
    val duration = MutableStateFlow(0L)
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val speed = MutableStateFlow(1f)
    val queue = MutableStateFlow<List<Song>>(emptyList())
    val favorites = MutableStateFlow(store.favorites())
    val favoriteArtists = MutableStateFlow(store.favoriteArtists())
    val hiddenIds = MutableStateFlow(store.hidden())
    val playlists = MutableStateFlow(store.playlists())
    val recents = MutableStateFlow<List<Song>>(emptyList())
    val sleepLeft = MutableStateFlow(0L)
    val sleepAtEnd = MutableStateFlow(false)
    val headphone = MutableStateFlow<String?>(null)

    // ---- tampilan dinamis
    val artBig = MutableStateFlow<Bitmap?>(null)
    val dynamicAccent = MutableStateFlow<Color?>(null)
    val customThemes = MutableStateFlow(store.customThemes())

    // ---- lirik
    val lyricLines = MutableStateFlow<List<TimedLyric>>(emptyList())
    val lyricsSynced = MutableStateFlow(false)
    val lyricsLoading = MutableStateFlow(false)
    val lyricsStatus = MutableStateFlow("Lirik otomatis akan dicari saat lagu diputar")
    val activeLyricIndex = MutableStateFlow(-1)
    val translation = MutableStateFlow<List<String>?>(null)
    val translating = MutableStateFlow(false)
    private var lyricsSongId: Long? = null

    // ---- Spotify
    val spotifyLists = MutableStateFlow(store.spotifyLists())
    val spotifyMatches = MutableStateFlow<Map<String, List<MatchResult>>>(emptyMap())
    val importState = MutableStateFlow<ImportState>(ImportState.Idle)
    val pendingSpotifyShare = MutableStateFlow<String?>(null)

    // ---- Album Lokal + importer Spotify -> YouTube
    val localAlbum = MutableStateFlow(store.localAlbum())
    val importHistory = MutableStateFlow(
        store.importHistory().map {
            // sisa dari sesi yang mati di tengah impor
            if (it.status == ImportStatus.RUNNING) it.copy(status = ImportStatus.INTERRUPTED) else it
        }
    )
    val albumImport = MutableStateFlow(ImportProgress())
    val ytKeyPresent = MutableStateFlow(store.ytKey().isNotBlank())
    val albumImportLink = MutableStateFlow<String?>(null)
    private var albumJob: Job? = null

    private var sleepJob: Job? = null
    private var fadeJob: Job? = null
    private var refreshJob: Job? = null
    private var lastQueueIds: List<Long> = emptyList()
    private var lastFocus: Boolean? = null
    private var counts: Map<Long, Int> = emptyMap()
    private var trackSong: Song? = null
    private var listenAccum = 0L
    private var xfActive = false
    private var xfPlayer: ExoPlayer? = null
    private var smartQueueBusy = false
    private var headphoneInit = false
    var equalizer: Equalizer? = null
        private set

    private val listener = object : Player.Listener {
        override fun onEvents(p: Player, events: Player.Events) {
            sync(events.contains(Player.EVENT_TIMELINE_CHANGED) || events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION))
        }
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!isPlaying) { persistPos(); if (xfActive) finishCrossfade() }
        }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM && sleepAtEnd.value) {
                sleepAtEnd.value = false
                player.setPauseAtEndOfMediaItems(false)
            }
        }
    }

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            refreshJob?.cancel()
            refreshJob = viewModelScope.launch {
                delay(3000)
                if (libraryReady.value) load(true)
            }
        }
    }

    private val audioCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) {
            updateHeadphone()
            val s = cfg.state.value
            if (headphoneInit && s.autoPlayHeadset && headphone.value != null && player.mediaItemCount > 0 && !player.isPlaying
                && added.any { isHeadphone(it) }
            ) toggle()
        }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) = updateHeadphone()
    }

    init {
        player.addListener(listener)
        runCatching {
            MediaController.Builder(ctx, SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))).buildAsync()
        }
        ctx.contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.registerAudioDeviceCallback(audioCb, Handler(Looper.getMainLooper()))
        updateHeadphone(); headphoneInit = true

        viewModelScope.launch { tickLoop() }
        viewModelScope.launch { cfg.state.collect { applyPlayerSettings(it) } }
        viewModelScope.launch { cfg.state.map { it.minDurationSec }.distinctUntilChanged().drop(1).collect { load(true) } }
        viewModelScope.launch { cfg.state.map { it.matchLevel }.distinctUntilChanged().drop(1).collect { rematchAll() } }
        viewModelScope.launch { cfg.state.map { it.dynamicColor }.distinctUntilChanged().drop(1).collect { refreshArt() } }
        viewModelScope.launch {
            cfg.state.map { Triple(it.reminderOn, it.reminderHour, it.reminderMin) }.distinctUntilChanged().collect { (on, h, m) ->
                if (on) Reminders.schedule(ctx, h, m) else Reminders.cancel(ctx)
            }
        }
        viewModelScope.launch { cfg.state.map { it.appIcon }.distinctUntilChanged().drop(1).collect { runCatching { AppIcons.apply(ctx, it) } } }
        viewModelScope.launch(Dispatchers.IO) { counts = stats.playCounts() }
        sync(true)
    }

    // ================================================================ loop utama
    private suspend fun tickLoop() {
        var last = SystemClock.elapsedRealtime()
        while (true) {
            val now = SystemClock.elapsedRealtime()
            val dt = now - last
            last = now
            val playing = player.isPlaying
            val pos = player.currentPosition
            position.value = pos
            if (playing) {
                listenAccum += dt
                val lines = lyricLines.value
                if (lyricsSynced.value && lines.isNotEmpty()) {
                    val i = lines.indexOfLast { it.timeMs <= pos + 120 }
                    if (activeLyricIndex.value != i) activeLyricIndex.value = i
                }
                checkCrossfade(pos)
            }
            delay(if (playing) (if (cfg.state.value.crossfadeSec > 0) 120L else 200L) else 500L)
        }
    }

    private fun applyPlayerSettings(s: AppSettings) {
        player.setSkipSilenceEnabled(s.skipSilence)
        player.setHandleAudioBecomingNoisy(s.pauseOnNoisy)
        if (lastFocus != s.audioFocus) {
            lastFocus = s.audioFocus
            player.setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                s.audioFocus
            )
        }
    }

    // ================================================================ library
    fun load(force: Boolean = false) {
        if (loading.value) return
        loading.value = true
        viewModelScope.launch {
            val min = cfg.state.value.minDurationSec
            val raw = withContext(Dispatchers.IO) { MusicRepository.load(ctx, min, emptySet()) }
            allSongs = raw
            folders.value = raw.filter { it.folder.isNotEmpty() }.groupingBy { it.folder }.eachCount()
            publishSongs()
            loading.value = false
            if (!force) restoreQueue()
            libraryReady.value = true
            sync(true)
            rematchAll()
        }
    }

    /** Menerapkan folder dikecualikan, lagu disembunyikan, dan koreksi metadata. */
    private fun publishSongs() {
        val ov = store.overrides()
        val excl = excludedFolders.value
        val hide = hiddenIds.value
        val list = allSongs.filter { it.folder !in excl && it.id !in hide }.map { s ->
            ov[s.id]?.let { s.copy(title = it.title ?: s.title, artist = it.artist ?: s.artist, album = it.album ?: s.album) } ?: s
        }
        byId = list.associateBy { it.id }
        songs.value = list
        recents.value = store.recents().mapNotNull { byId[it] }
    }

    private fun restoreQueue() {
        if (!cfg.state.value.resumeQueue || player.mediaItemCount > 0) return
        val list = store.queueIds().mapNotNull { byId[it] }
        if (list.isEmpty()) return
        val idx = store.queueIndex().coerceIn(0, list.lastIndex)
        lastQueueIds = list.map { it.id }
        player.setMediaItems(list.map { it.toItem() }, idx, store.queuePos())
        player.prepare()
    }

    private fun persistPos() {
        if (player.mediaItemCount > 0) store.saveQueuePos(player.currentMediaItemIndex, player.currentPosition)
    }

    private fun sync(rebuildQueue: Boolean) {
        isPlaying.value = player.isPlaying
        shuffle.value = player.shuffleModeEnabled
        repeat.value = player.repeatMode
        speed.value = player.playbackParameters.speed
        duration.value = player.duration.coerceAtLeast(0L)
        val song = player.currentMediaItem?.mediaId?.toLongOrNull()?.let { byId[it] }
        if (song?.id != current.value?.id) {
            flushListen()
            current.value = song
            trackSong = song
            listenAccum = 0L
            if (song != null) { pushRecent(song); persistPos(); loadLyrics(song); refreshArt(); maybeSmartQueue(song) }
            else { clearLyrics(); artBig.value = null; dynamicAccent.value = null }
        }
        if (rebuildQueue || queue.value.isEmpty()) {
            val q = (0 until player.mediaItemCount).mapNotNull {
                player.getMediaItemAt(it).mediaId.toLongOrNull()?.let { id -> byId[id] }
            }
            queue.value = q
            val ids = q.map { it.id }
            if (ids.isNotEmpty() && ids != lastQueueIds) { lastQueueIds = ids; store.saveQueueIds(ids) }
        }
    }

    private fun pushRecent(song: Song) {
        val l = (listOf(song.id) + store.recents().filter { it != song.id }).take(20)
        store.saveRecents(l)
        recents.value = l.mapNotNull { byId[it] }
    }

    private fun Song.toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build())
        .build()

    // ================================================================ statistik mendengarkan
    private fun flushListen() {
        val s = trackSong ?: return
        val ms = listenAccum
        if (ms < 5000) return
        val counted = ms >= minOf(30_000L, s.duration / 2)
        val e = PlayEvent(System.currentTimeMillis() - ms, s.id, ms, counted, s.title, s.artist, s.album)
        if (counted) counts = counts + (s.id to ((counts[s.id] ?: 0) + 1))
        viewModelScope.launch(Dispatchers.IO) { runCatching { stats.append(e) } }
        listenAccum = 0L
    }

    suspend fun computeStats(rangeDays: Int): StatsResult = withContext(Dispatchers.IO) {
        flushListen()
        PlayStats.compute(stats.readAll(), rangeDays)
    }

    fun clearStats() { stats.clear(); counts = emptyMap() }

    // ================================================================ kontrol pemutaran
    fun playSongs(list: List<Song>, index: Int) {
        if (list.isEmpty()) return
        player.volume = 1f
        player.setMediaItems(list.map { it.toItem() }, index.coerceIn(0, list.lastIndex), 0L)
        player.prepare()
        player.play()
    }

    fun shuffleAll(list: List<Song>) {
        if (list.isEmpty()) return
        player.shuffleModeEnabled = true
        playSongs(list.shuffled(), 0)
    }

    fun playNext(song: Song) {
        if (player.mediaItemCount == 0) playSongs(listOf(song), 0)
        else player.addMediaItem(player.currentMediaItemIndex + 1, song.toItem())
    }

    fun addToQueue(song: Song) {
        if (player.mediaItemCount == 0) playSongs(listOf(song), 0) else player.addMediaItem(song.toItem())
    }

    fun skipTo(i: Int) { player.volume = 1f; player.seekTo(i, 0L); player.play() }

    fun toggle() {
        fadeJob?.cancel()
        val s = cfg.state.value
        val fade = s.fadeOnPause && s.fadeMs > 0 && !xfActive
        if (player.isPlaying) {
            if (fade) {
                fadeJob = viewModelScope.launch { ramp(1f, 0f, s.fadeMs); player.pause(); player.volume = 1f }
            } else player.pause()
        } else {
            if (fade) {
                player.volume = 0f
                player.play()
                fadeJob = viewModelScope.launch { ramp(0f, 1f, s.fadeMs) }
            } else { player.volume = 1f; player.play() }
        }
    }

    private suspend fun ramp(from: Float, to: Float, ms: Int) {
        val steps = (ms / 30).coerceAtLeast(1)
        for (i in 1..steps) {
            player.volume = from + (to - from) * i / steps
            delay(30)
        }
        player.volume = to
    }

    fun next() { player.volume = 1f; player.seekToNextMediaItem() }
    fun prev() {
        player.volume = 1f
        if (player.currentPosition > 3000) player.seekTo(0L) else player.seekToPreviousMediaItem()
    }
    fun seek(ms: Long) = player.seekTo(ms)
    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }
    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun setSpeed(s: Float) {
        player.playbackParameters = PlaybackParameters(s)
        xfPlayer?.playbackParameters = PlaybackParameters(s)
    }

    // ---- antrean: urutkan ulang & hapus
    fun moveQueue(from: Int, to: Int) {
        if (from == to || from !in 0 until player.mediaItemCount || to !in 0 until player.mediaItemCount) return
        player.moveMediaItem(from, to)
    }

    fun removeFromQueue(index: Int) {
        if (index in 0 until player.mediaItemCount && player.mediaItemCount > 1) player.removeMediaItem(index)
    }

    /** Antrean pintar: menambahkan lagu mirip (artis/album/genre/mood) ke akhir antrean. */
    private fun maybeSmartQueue(song: Song) {
        if (!cfg.state.value.smartQueue || smartQueueBusy) return
        if (player.mediaItemCount - player.currentMediaItemIndex > 2) return
        addSimilar(song, 8)
    }

    fun addSimilar(song: Song, n: Int = 10, onDone: ((Int) -> Unit)? = null) {
        smartQueueBusy = true
        val inQueue = queue.value.map { it.id }.toSet()
        val all = songs.value
        val cnt = counts
        viewModelScope.launch {
            val picks = withContext(Dispatchers.Default) { Smart.similar(song, all, inQueue, cnt, n) }
            if (picks.isNotEmpty() && player.mediaItemCount > 0) player.addMediaItems(picks.map { it.toItem() })
            smartQueueBusy = false
            onDone?.invoke(picks.size)
        }
    }

    // ================================================================ crossfade (tumpang tindih sungguhan)
    private fun helper(): ExoPlayer = xfPlayer ?: ExoPlayer.Builder(ctx)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false)
        .build().also { xfPlayer = it }

    private fun checkCrossfade(pos: Long) {
        val cf = cfg.state.value.crossfadeSec * 1000L
        if (cf <= 0 || xfActive) return
        val dur = player.duration
        if (dur <= 0 || dur < cf * 3 || dur - pos > cf) return
        if (!player.hasNextMediaItem() || player.repeatMode == Player.REPEAT_MODE_ONE) return
        val item = player.currentMediaItem ?: return
        xfActive = true
        fadeJob?.cancel()
        val h = helper()
        h.playbackParameters = player.playbackParameters
        h.setMediaItem(item)
        h.seekTo(pos)
        h.volume = 1f
        h.prepare()
        h.play()
        player.volume = 0f
        player.seekToNextMediaItem()          // lagu berikutnya mulai dari awal, sementara "ekor" lagu lama diputar helper
        viewModelScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            while (xfActive) {
                val f = ((SystemClock.elapsedRealtime() - t0).toFloat() / cf).coerceIn(0f, 1f)
                h.volume = 1f - f
                player.volume = f
                if (f >= 1f) break
                delay(40)
            }
            finishCrossfade()
        }
    }

    private fun finishCrossfade() {
        xfActive = false
        xfPlayer?.let { it.stop(); it.clearMediaItems() }
        player.volume = 1f
    }

    // ================================================================ sleep timer
    fun setSleep(minutes: Int) {
        sleepJob?.cancel()
        sleepAtEnd.value = false
        player.setPauseAtEndOfMediaItems(false)
        if (minutes <= 0) { sleepLeft.value = 0; player.volume = 1f; return }
        sleepLeft.value = minutes * 60_000L
        sleepJob = viewModelScope.launch {
            while (sleepLeft.value > 0) {
                delay(1000)
                sleepLeft.value = (sleepLeft.value - 1000).coerceAtLeast(0)
                if (sleepLeft.value in 1..8000 && !xfActive) player.volume = sleepLeft.value / 8000f   // meredup sebelum berhenti
            }
            player.pause()
            player.volume = 1f
        }
    }

    /** Berhenti otomatis setelah lagu yang sedang diputar selesai. */
    fun sleepAfterThisSong() {
        sleepJob?.cancel()
        sleepLeft.value = 0
        sleepAtEnd.value = true
        player.setPauseAtEndOfMediaItems(true)
    }

    // ================================================================ favorit, playlist, artis favorit
    fun toggleFavorite(song: Song) {
        val s = favorites.value.toMutableSet()
        if (!s.add(song.id)) s.remove(song.id)
        favorites.value = s
        store.saveFavorites(s)
    }

    fun toggleFavoriteArtist(name: String) {
        val s = favoriteArtists.value.toMutableSet()
        if (!s.add(name)) s.remove(name)
        favoriteArtists.value = s
        store.saveFavoriteArtists(s)
    }

    fun createPlaylist(name: String) {
        val n = name.trim()
        if (n.isEmpty() || playlists.value.containsKey(n)) return
        val m = LinkedHashMap(playlists.value); m[n] = emptyList()
        playlists.value = m; store.savePlaylists(m)
    }

    fun createPlaylistWith(name: String, list: List<Song>): String {
        val base = name.trim().ifEmpty { "Playlist baru" }
        var n = base
        var k = 2
        while (playlists.value.containsKey(n)) { n = "$base ($k)"; k++ }
        val m = LinkedHashMap(playlists.value); m[n] = list.map { it.id }.distinct()
        playlists.value = m; store.savePlaylists(m)
        return n
    }

    fun deletePlaylist(name: String) {
        val m = LinkedHashMap(playlists.value); m.remove(name)
        playlists.value = m; store.savePlaylists(m)
    }

    fun addToPlaylist(name: String, song: Song) {
        val m = LinkedHashMap(playlists.value)
        val l = m[name].orEmpty()
        if (song.id !in l) m[name] = l + song.id
        playlists.value = m; store.savePlaylists(m)
    }

    fun removeFromPlaylist(name: String, song: Song) {
        val m = LinkedHashMap(playlists.value)
        m[name] = m[name].orEmpty().filter { it != song.id }
        playlists.value = m; store.savePlaylists(m)
    }

    fun playlistSongs(name: String): List<Song> = playlists.value[name].orEmpty().mapNotNull { byId[it] }

    // ================================================================ equalizer (tersimpan)
    private val eqPrefs get() = ctx.getSharedPreferences("nova_eq", Context.MODE_PRIVATE)

    fun ensureEq(): Equalizer? {
        if (equalizer == null && player.audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
            equalizer = runCatching {
                Equalizer(0, player.audioSessionId).apply {
                    enabled = eqPrefs.getBoolean("on", true)
                    val saved = (eqPrefs.getString("levels", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
                    if (saved.size == numberOfBands.toInt()) saved.forEachIndexed { b, l -> setBandLevel(b.toShort(), l.toShort()) }
                }
            }.getOrNull()
        }
        return equalizer
    }

    fun saveEq() {
        val eq = equalizer ?: return
        runCatching {
            eqPrefs.edit().putBoolean("on", eq.enabled)
                .putString("levels", (0 until eq.numberOfBands.toInt()).joinToString(",") { eq.getBandLevel(it.toShort()).toString() }).apply()
        }
    }

    // ================================================================ headset
    private fun isHeadphone(d: AudioDeviceInfo): Boolean = d.isSink && d.type in setOf(
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE
    ) || (Build.VERSION.SDK_INT >= 31 && d.isSink && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)

    private fun updateHeadphone() {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { isHeadphone(it) }
        headphone.value = d?.let {
            val n = it.productName?.toString().orEmpty()
            when (it.type) {
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Headset kabel"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> n.ifBlank { "Bluetooth" }.let { x -> "Bluetooth: $x" }
                else -> n.ifBlank { "Headset USB" }
            }
        }
    }

    // ================================================================ cover, warna dinamis
    private fun refreshArt() {
        val song = current.value ?: return
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { ArtLoader.load(ctx, song, true) }
            if (current.value?.id != song.id) return@launch
            artBig.value = bmp
            dynamicAccent.value = if (cfg.state.value.dynamicColor && bmp != null)
                withContext(Dispatchers.Default) { ArtLoader.dominantColor(bmp) } else null
        }
    }

    // ================================================================ lirik
    private val manualPrefs get() = ctx.getSharedPreferences("nova_lyrics", Context.MODE_PRIVATE)

    fun manualLyrics(songId: Long): String = manualPrefs.getString(songId.toString(), "") ?: ""

    fun saveManualLyrics(songId: Long, text: String) {
        manualPrefs.edit().putString(songId.toString(), text).apply()
        if (current.value?.id == songId) { lyricsSongId = null; current.value?.let { loadLyrics(it) } }
    }

    private fun clearLyrics() {
        lyricsSongId = null
        lyricLines.value = emptyList(); lyricsSynced.value = false
        activeLyricIndex.value = -1; translation.value = null
        lyricsStatus.value = "Tidak ada lagu yang diputar"
    }

    private fun loadLyrics(song: Song) {
        if (lyricsSongId == song.id) return
        lyricsSongId = song.id
        lyricLines.value = emptyList(); lyricsSynced.value = false
        activeLyricIndex.value = -1; translation.value = null
        val manual = manualLyrics(song.id)
        val auto = cfg.state.value.lyricsAuto
        if (manual.isBlank() && !auto) {
            lyricsLoading.value = false
            lyricsStatus.value = "Lirik otomatis dimatikan di Pengaturan"
            return
        }
        lyricsLoading.value = manual.isBlank()
        lyricsStatus.value = if (manual.isBlank()) "Mencari lirik ${song.title}…" else "Lirik buatanmu"
        viewModelScope.launch {
            val result: LyricsResult? = if (manual.isNotBlank()) LyricsRepository.parseLrc(manual)
            else withContext(Dispatchers.IO) { runCatching { LyricsRepository.get(ctx, song.title, song.artist, song.album, song.duration) }.getOrNull() }
            if (lyricsSongId != song.id) return@launch
            lyricsLoading.value = false
            if (result != null && result.lines.isNotEmpty()) {
                lyricLines.value = result.lines
                lyricsSynced.value = result.synced
                activeLyricIndex.value = if (result.synced) result.lines.indexOfLast { it.timeMs <= player.currentPosition } else -1
                lyricsStatus.value = if (result.synced) "Lirik tersinkron otomatis" else "Lirik tersedia, tanpa sinkronisasi waktu"
                if (cfg.state.value.lyricsTranslate) translateLyrics()
            } else {
                lyricsStatus.value = "Lirik belum ditemukan (atau perangkat offline)"
            }
        }
    }

    fun retryLyrics() {
        val s = current.value ?: return
        LyricsRepository.forgetMiss(ctx, s.title, s.artist, s.duration)
        lyricsSongId = null
        loadLyrics(s)
    }

    fun setTranslate(on: Boolean) {
        cfg.update { it.copy(lyricsTranslate = on) }
        if (on) translateLyrics() else translation.value = null
    }

    fun translateLyrics() {
        val song = current.value ?: return
        val lines = lyricLines.value
        if (lines.isEmpty() || translating.value) return
        val key = LyricsRepository.keyOf(song.title, song.artist, song.duration)
        val lang = cfg.state.value.lyricsLang
        translating.value = true
        viewModelScope.launch {
            val tr = withContext(Dispatchers.IO) { runCatching { LyricsRepository.translate(ctx, key, lang, lines.map { it.text }) }.getOrNull() }
            translating.value = false
            if (current.value?.id != song.id) return@launch
            if (tr != null) translation.value = tr else lyricsStatus.value = "Terjemahan gagal (periksa koneksi internet)"
        }
    }

    fun setTranslateLang(lang: String) {
        cfg.update { it.copy(lyricsLang = lang) }
        translation.value = null
        if (cfg.state.value.lyricsTranslate) translateLyrics()
    }

    fun lyricsCacheInfo(): Pair<Int, Long> = LyricsRepository.cacheInfo(ctx)
    fun clearLyricsCache() = LyricsRepository.clearCache(ctx)

    // ================================================================ latar & foto profil
    private fun copyTo(uri: Uri, dest: File): Boolean = runCatching {
        ctx.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        true
    }.getOrDefault(false)

    fun setBackgroundPhoto(uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val dest = File(ctx.filesDir, "bg_photo_${System.currentTimeMillis()}.img")
            val ok = withContext(Dispatchers.IO) { copyTo(uri, dest) }
            if (ok) {
                File(cfg.state.value.bgPhotoPath).takeIf { it.isFile }?.delete()
                cfg.update { it.copy(bgPhotoPath = dest.absolutePath, bgType = BgType.PHOTO) }
            }
            onDone(ok)
        }
    }

    fun setBackgroundVideo(uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val dest = File(ctx.filesDir, "bg_video_${System.currentTimeMillis()}.vid")
            val ok = withContext(Dispatchers.IO) { copyTo(uri, dest) }
            if (ok) {
                File(cfg.state.value.bgVideoPath).takeIf { it.isFile }?.delete()
                cfg.update { it.copy(bgVideoPath = dest.absolutePath, bgType = BgType.VIDEO) }
            }
            onDone(ok)
        }
    }

    val profileVersion = MutableStateFlow(0)
    fun profileFile() = File(ctx.filesDir, "profile_photo.img")

    fun setProfilePhoto(uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { copyTo(uri, profileFile()) }
            if (ok) profileVersion.value++
            onDone(ok)
        }
    }

    // ================================================================ tema kustom
    fun saveTheme(t: CustomTheme) {
        val l = customThemes.value.filter { it.id != t.id } + t
        customThemes.value = l
        store.saveCustomThemes(l)
    }

    fun deleteTheme(id: String) {
        val l = customThemes.value.filter { it.id != id }
        customThemes.value = l
        store.saveCustomThemes(l)
        if (cfg.state.value.themeId == id) cfg.update { it.copy(palette = Palette.NOVA, themeId = "") }
    }

    fun applyTheme(id: String) = cfg.update { it.copy(palette = Palette.CUSTOM, themeId = id) }

    // ================================================================ library pintar
    fun editMeta(song: Song, title: String, artist: String, album: String) {
        val m = HashMap(store.overrides())
        m[song.id] = MetaOverride(title.trim().ifEmpty { null }, artist.trim().ifEmpty { null }, album.trim().ifEmpty { null })
        store.saveOverrides(m)
        publishSongs()
    }

    fun applySuggestions(list: List<MetaSuggestion>) {
        val m = HashMap(store.overrides())
        list.forEach { m[it.song.id] = MetaOverride(it.newTitle, it.newArtist, null) }
        store.saveOverrides(m)
        publishSongs()
    }

    fun resetMeta() { store.saveOverrides(emptyMap()); publishSongs() }

    fun hideSongs(ids: Collection<Long>) {
        val s = hiddenIds.value + ids
        hiddenIds.value = s; store.saveHidden(s); publishSongs()
    }

    fun unhideAll() { hiddenIds.value = emptySet(); store.saveHidden(emptySet()); publishSongs() }

    /** Hapus file lagu (Android 11+ lewat dialog konfirmasi sistem). */
    fun deleteRequest(ids: List<Long>): IntentSender? =
        if (Build.VERSION.SDK_INT >= 30)
            runCatching { MediaStore.createDeleteRequest(ctx.contentResolver, ids.map { Song.uriFor(it) }).intentSender }.getOrNull()
        else null

    fun toggleFolder(path: String) {
        val s = excludedFolders.value.toMutableSet()
        if (!s.add(path)) s.remove(path)
        excludedFolders.value = s; store.saveExcludedFolders(s)
        publishSongs()
    }

    suspend fun playCountsNow(): Map<Long, Int> = withContext(Dispatchers.IO) { stats.playCounts().also { counts = it } }

    // ================================================================ Spotify (Import 2.0)
    private fun linkKey(t: SpotifyTrack) = SpotifyMatcher.norm(t.title) + "|" + SpotifyMatcher.norm(t.artist)

    private fun matchWithLinks(tracks: List<SpotifyTrack>, songsNow: List<Song>, level: Int): List<MatchResult> {
        val links = store.spotifyLinks()
        val ids = songsNow.associateBy { it.id }
        return SpotifyMatcher.match(tracks, songsNow, level).map { m ->
            val forced = links[linkKey(m.track)]?.let { ids[it] }
            if (forced != null) m.copy(song = forced) else m
        }
    }

    fun rematchAll() {
        val songsNow = songs.value
        val lists = spotifyLists.value
        val level = cfg.state.value.matchLevel
        viewModelScope.launch {
            spotifyMatches.value = withContext(Dispatchers.Default) {
                lists.associate { it.id to matchWithLinks(it.tracks, songsNow, level) }
            }
        }
    }

    fun linkTrack(t: SpotifyTrack, song: Song?) {
        val m = HashMap(store.spotifyLinks())
        if (song == null) m.remove(linkKey(t)) else m[linkKey(t)] = song.id
        store.saveSpotifyLinks(m)
        rematchAll()
    }

    fun onSharedText(text: String) {
        if (SpotifyImporter.parseLink(text) != null) pendingSpotifyShare.value = text
    }

    fun resetImport() { importState.value = ImportState.Idle }

    fun fetchSpotify(input: String) {
        val link = SpotifyImporter.parseLink(input)
        if (link == null) {
            importState.value = ImportState.Error("Tautan tidak dikenali. Tempel tautan seperti https://open.spotify.com/playlist/...")
            return
        }
        importState.value = ImportState.Loading
        viewModelScope.launch {
            try {
                val pl = withContext(Dispatchers.IO) { SpotifyImporter.fetch(link) }
                val note = if (pl.tracks.size >= 50)
                    "Lewat tautan, Spotify biasanya hanya membagikan sebagian lagu (sekitar 50-100). " +
                        "Untuk playlist yang lebih panjang, gunakan File CSV (Exportify) agar semua lagu terbaca."
                else null
                showPreview(pl, note)
            } catch (e: SpotifyException) {
                importState.value = ImportState.Error(e.message ?: "Gagal mengambil playlist.")
            } catch (e: Exception) {
                importState.value = ImportState.Error("Terjadi kesalahan: ${e.message}")
            }
        }
    }

    fun previewText(name: String, text: String) {
        val tracks = SpotifyImporter.parseText(text)
        if (tracks.isEmpty()) {
            importState.value = ImportState.Error("Tidak ada baris lagu. Tulis satu lagu per baris, misalnya: Artis - Judul")
            return
        }
        importState.value = ImportState.Loading
        viewModelScope.launch { showPreview(newList(name.ifBlank { "Daftar lagu tempel" }, tracks), null) }
    }

    fun previewCsv(uri: Uri) {
        importState.value = ImportState.Loading
        viewModelScope.launch {
            try {
                val (name, tracks) = withContext(Dispatchers.IO) {
                    val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val fileName = runCatching {
                        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (c.moveToFirst() && i >= 0) c.getString(i) else null
                        }
                    }.getOrNull()
                    (fileName?.substringBeforeLast('.') ?: "Playlist CSV") to SpotifyImporter.parseCsv(text)
                }
                if (tracks.isEmpty()) throw SpotifyException("Tidak ada lagu di file CSV.")
                showPreview(newList(name, tracks), null)
            } catch (e: SpotifyException) {
                importState.value = ImportState.Error(e.message ?: "CSV tidak valid.")
            } catch (e: Exception) {
                importState.value = ImportState.Error("Gagal membaca file: ${e.message}")
            }
        }
    }

    private fun newList(name: String, tracks: List<SpotifyTrack>) = SpotifyPlaylist(
        id = "imp_" + System.currentTimeMillis(), name = name, url = "",
        tracks = tracks, importedAt = System.currentTimeMillis(), fromLink = false
    )

    private suspend fun showPreview(pl: SpotifyPlaylist, note: String?) {
        val songsNow = songs.value
        val level = cfg.state.value.matchLevel
        val matches = withContext(Dispatchers.Default) { matchWithLinks(pl.tracks, songsNow, level) }
        importState.value = ImportState.Preview(pl, matches, note)
    }

    fun saveSpotifyList(pl: SpotifyPlaylist, name: String) {
        val saved = pl.copy(name = name.ifBlank { pl.name })
        val l = spotifyLists.value.filter { it.id != saved.id } + saved
        spotifyLists.value = l
        store.saveSpotifyLists(l)
        rematchAll()
    }

    fun saveLocalPlaylist(name: String, matches: List<MatchResult>): Int {
        val list = matches.mapNotNull { it.song }
        createPlaylistWith(name.ifBlank { "Playlist Spotify" }, list)
        return list.map { it.id }.distinct().size
    }

    fun deleteSpotifyList(id: String) {
        val l = spotifyLists.value.filter { it.id != id }
        spotifyLists.value = l
        store.saveSpotifyLists(l)
        spotifyMatches.value = spotifyMatches.value - id
    }

    fun deleteAllSpotify() {
        spotifyLists.value = emptyList()
        store.saveSpotifyLists(emptyList())
        spotifyMatches.value = emptyMap()
    }

    fun refreshSpotify(id: String, onDone: (String) -> Unit) {
        val old = spotifyLists.value.firstOrNull { it.id == id } ?: return
        val link = SpotifyImporter.parseLink(old.url)
        if (link == null) { onDone("Playlist ini tidak berasal dari tautan."); return }
        viewModelScope.launch {
            try {
                val fresh = withContext(Dispatchers.IO) { SpotifyImporter.fetch(link) }
                val l = spotifyLists.value.map {
                    if (it.id == id) it.copy(tracks = fresh.tracks, importedAt = System.currentTimeMillis()) else it
                }
                spotifyLists.value = l
                store.saveSpotifyLists(l)
                rematchAll()
                onDone("Diperbarui: ${fresh.tracks.size} lagu")
            } catch (e: Exception) {
                onDone(e.message ?: "Gagal memperbarui")
            }
        }
    }

    fun refreshAllSpotify(onDone: (String) -> Unit) {
        val linked = spotifyLists.value.filter { it.fromLink }
        if (linked.isEmpty()) { onDone("Tidak ada playlist dari tautan."); return }
        viewModelScope.launch {
            var ok = 0
            for (pl in linked) {
                val link = SpotifyImporter.parseLink(pl.url) ?: continue
                runCatching { withContext(Dispatchers.IO) { SpotifyImporter.fetch(link) } }.getOrNull()?.let { fresh ->
                    spotifyLists.value = spotifyLists.value.map { if (it.id == pl.id) it.copy(tracks = fresh.tracks, importedAt = System.currentTimeMillis()) else it }
                    ok++
                }
            }
            store.saveSpotifyLists(spotifyLists.value)
            rematchAll()
            onDone("$ok dari ${linked.size} playlist diperbarui")
        }
    }

    // ================================================================ Album Lokal (Spotify -> YouTube)
    fun ytKeyTail(): String = store.ytKey().takeLast(4)

    /** Memeriksa kunci ke YouTube (1 poin kuota) dan menyimpannya hanya bila valid. */
    fun saveYtKey(key: String, onDone: (Boolean, String) -> Unit) {
        val k = key.trim()
        if (k.length < 20 || k.any { it.isWhitespace() }) { onDone(false, "Format kunci tidak valid."); return }
        viewModelScope.launch {
            val err = YouTubeApi(k).validate()
            // hanya kunci yang ditolak yang dianggap gagal; jaringan putus tidak membuktikan kunci salah
            if (err != null && err.kind != YtException.Kind.NETWORK) { onDone(false, err.message ?: "Kunci ditolak."); return@launch }
            store.saveYtKey(k)
            ytKeyPresent.value = true
            onDone(true, if (err == null) "Kunci tersimpan dan valid." else "Kunci tersimpan (belum bisa diperiksa: ${err.message})")
        }
    }

    fun clearYtKey() { store.saveYtKey(""); ytKeyPresent.value = false }

    fun startAlbumImportFromLink(input: String) {
        val link = SpotifyImporter.parseLink(input)
        if (link == null) {
            albumImport.value = ImportProgress(
                phase = ImportPhase.FINISHED, status = null,
                message = "Tautan tidak dikenali. Tempel tautan seperti https://open.spotify.com/playlist/..."
            )
            return
        }
        val url = "https://open.spotify.com/${link.kind}/${link.id}"
        launchAlbumImport("Playlist Spotify", url, link.id) {
            val pl = SpotifyImporter.fetch(link)
            pl.name to pl.tracks
        }
    }

    fun startAlbumImportFromText(name: String, text: String) {
        val tracks = SpotifyImporter.parseText(text)
        val n = name.trim().ifBlank { "Daftar lagu tempel" }
        if (tracks.isEmpty()) {
            albumImport.value = ImportProgress(
                phase = ImportPhase.FINISHED, name = n, status = null,
                message = "Tidak ada baris lagu. Tulis satu lagu per baris, misalnya: Artis - Judul"
            )
            return
        }
        launchAlbumImport(n, "", "txt_" + SpotifyMatcher.norm(n).hashCode()) { n to tracks }
    }

    fun startAlbumImportFromCsv(uri: Uri) {
        launchAlbumImport("Playlist CSV", "", "csv_" + uri.toString().hashCode()) {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw SpotifyException("File CSV tidak bisa dibuka.")
            val fileName = runCatching {
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) c.getString(i) else null
                }
            }.getOrNull()
            val tracks = SpotifyImporter.parseCsv(text)
            if (tracks.isEmpty()) throw SpotifyException("Tidak ada lagu di file CSV.")
            (fileName?.substringBeforeLast('.') ?: "Playlist CSV") to tracks
        }
    }

    private fun launchAlbumImport(
        initialName: String, url: String, sourceId: String,
        load: suspend () -> Pair<String, List<SpotifyTrack>>
    ) {
        if (albumImport.value.running) return
        val key = store.ytKey()
        if (key.isBlank()) {
            albumImport.value = ImportProgress(
                phase = ImportPhase.FINISHED, name = initialName, status = ImportStatus.KEY_ERROR,
                message = "Simpan kunci API YouTube dulu."
            )
            return
        }
        val startedAt = System.currentTimeMillis()
        val recId = "imp_$startedAt"
        albumJob = viewModelScope.launch {
            var name = initialName
            var engine: ImportEngine? = null
            var total = 0
            var failStatus = ImportStatus.INTERRUPTED
            var failMsg: String? = null
            var sinceSave = 0
            albumImport.value = ImportProgress(phase = ImportPhase.READING, name = name)
            try {
                val (n, tracks) = withContext(Dispatchers.IO) { load() }
                name = n
                total = tracks.size
                if (tracks.isEmpty()) throw SpotifyException("Daftar lagu kosong.")
                putRecord(ImportRecord(recId, name, url, startedAt, 0L, total, 0, 0, 0, 0, ImportStatus.RUNNING))
                val e = ImportEngine(
                    tracks = tracks, existing = localAlbum.value, searcher = YouTubeApi(key),
                    sourceName = name, sourceId = sourceId,
                    onProgress = { albumImport.value = it },
                    onAdd = { t ->
                        localAlbum.value = localAlbum.value + t
                        if (++sinceSave >= 20) { sinceSave = 0; store.saveLocalAlbum(localAlbum.value) }
                    }
                )
                engine = e
                e.run()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: SpotifyException) {
                failMsg = e.message
            } catch (e: java.io.IOException) {
                failStatus = ImportStatus.NETWORK_ERROR
                failMsg = "Tidak bisa terhubung ke Spotify. Periksa koneksi internet."
            } catch (e: Exception) {
                failMsg = "Terjadi kesalahan: ${e.message}"
            } finally {
                // berjalan juga saat dibatalkan: hanya pekerjaan non-suspend
                store.saveLocalAlbum(localAlbum.value)
                val en = engine
                val status = en?.status?.takeIf { it != ImportStatus.RUNNING } ?: failStatus
                val msg = en?.message ?: failMsg
                val rec = ImportRecord(
                    recId, name, url, startedAt, System.currentTimeMillis(), total,
                    en?.added ?: 0, en?.duplicates ?: 0, en?.notFound ?: 0, en?.failed ?: 0,
                    status, en?.notFoundList?.toList() ?: emptyList()
                )
                putRecord(rec)
                albumImport.value = ImportProgress(
                    phase = ImportPhase.FINISHED, name = name, total = total, done = en?.done ?: 0,
                    added = rec.added, duplicates = rec.duplicates, notFound = rec.notFound, failed = rec.failed,
                    status = status, message = msg
                )
            }
        }
    }

    private fun putRecord(r: ImportRecord) {
        val l = (listOf(r) + importHistory.value.filter { it.id != r.id }).take(50)
        importHistory.value = l
        store.saveImportHistory(l)
    }

    fun cancelAlbumImport() { albumJob?.cancel() }
    fun dismissAlbumImport() { if (!albumImport.value.running) albumImport.value = ImportProgress() }

    fun removeAlbumTrack(id: String) {
        val l = localAlbum.value.filter { it.id != id }
        localAlbum.value = l; store.saveLocalAlbum(l)
    }

    fun clearLocalAlbum() { localAlbum.value = emptyList(); store.saveLocalAlbum(emptyList()) }

    fun deleteImportRecord(id: String) {
        val l = importHistory.value.filter { it.id != id }
        importHistory.value = l; store.saveImportHistory(l)
    }

    fun clearImportHistory() { importHistory.value = emptyList(); store.saveImportHistory(emptyList()) }

    // ================================================================ data & cadangan
    fun clearHistory() { store.clearRecents(); recents.value = emptyList() }
    fun clearFavorites() { store.clearFavorites(); favorites.value = emptySet() }
    fun clearSavedLyrics() = store.clearLyrics()

    fun exportBackup(uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val root = JSONObject(store.exportAll(cfg.exportJson()))
                    root.put("plays", stats.exportText())
                    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(root.toString().toByteArray()) }
                }.isSuccess
            }
            onDone(ok)
        }
    }

    fun importBackup(uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val root = JSONObject(text)
                    require(root.optString("app") == "NovaMusic")
                    store.importAll(root)
                    stats.importText(root.optString("plays"))
                    root.optJSONObject("settings")?.let { cfg.importJson(it) }
                }.isSuccess
            }
            if (ok) {
                favorites.value = store.favorites()
                favoriteArtists.value = store.favoriteArtists()
                hiddenIds.value = store.hidden()
                excludedFolders.value = store.excludedFolders()
                customThemes.value = store.customThemes()
                playlists.value = store.playlists()
                spotifyLists.value = store.spotifyLists()
                localAlbum.value = store.localAlbum()
                importHistory.value = store.importHistory()
                publishSongs()
                rematchAll()
                counts = withContext(Dispatchers.IO) { stats.playCounts() }
            }
            onDone(ok)
        }
    }

    fun appVersion(): String = runCatching {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    }.getOrDefault("")

    override fun onCleared() {
        flushListen()
        persistPos()
        player.removeListener(listener)
        runCatching { ctx.contentResolver.unregisterContentObserver(observer) }
        runCatching { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(audioCb) }
        xfPlayer?.release()
        equalizer?.release()
        super.onCleared()
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

fun fmtHours(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60} j ${m % 60} m" else "$m m"
}
