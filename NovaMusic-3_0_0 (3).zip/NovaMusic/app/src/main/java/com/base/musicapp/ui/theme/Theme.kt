package com.base.musicapp.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.base.musicapp.data.AppSettings
import com.base.musicapp.data.ArtShape
import com.base.musicapp.data.CustomTheme
import com.base.musicapp.data.Palette
import com.base.musicapp.data.ThemeMode
import com.base.musicapp.data.UiStyle

val Heart = Color(0xFFFF5FA2)

/** Tipografi Nova 3.0: sans-serif bersih, judul rapat, label sedikit renggang. */
private val NovaTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = (-0.1).sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, letterSpacing = 0.1.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, letterSpacing = 0.1.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 0.2.sp)
)

@Immutable
class NovaColors(
    val dark: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val onBg: Color,
    val muted: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val onAccent2: Color,
    val surfaceSolid: Color,
    val border: Color,
    val shadow: Color
) {
    fun withBg(top: Color, bottom: Color) = NovaColors(
        dark, top, bottom, onBg, muted, accent, accent2, onAccent, onAccent2, surfaceSolid, border, shadow
    )
}

@Immutable
class NovaLook(
    val style: UiStyle,
    val radius: Dp,
    val border: Dp,
    val shadow: Dp,
    val glassAlpha: Float,
    val animations: Boolean,
    val compact: Boolean,
    val showArt: Boolean,
    val artShape: ArtShape,
    val blurNow: Boolean
) {
    val neo: Boolean get() = style == UiStyle.NEO
}

private fun contrast(a: Color, b: Color): Float {
    val l1 = a.luminance(); val l2 = b.luminance()
    return (maxOf(l1, l2) + 0.05f) / (minOf(l1, l2) + 0.05f)
}

/** Warna teks (gelap/terang) dengan kontras terbaik di atas [bg]. */
fun bestOn(bg: Color): Color {
    val dark = Color(0xFF0B0B12)
    return if (contrast(dark, bg) >= contrast(Color.White, bg)) dark else Color.White
}

private fun shiftHue(c: Color, deg: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    hsv[0] = (hsv[0] + deg) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}

fun buildColors(s: AppSettings, systemDark: Boolean, custom: CustomTheme? = null, dynamic: Color? = null): NovaColors {
    val useCustom = s.palette == Palette.CUSTOM && custom != null
    val dark = when {
        useCustom -> custom!!.dark
        s.themeMode == ThemeMode.DARK -> true
        s.themeMode == ThemeMode.LIGHT -> false
        else -> systemDark
    }
    val mono = s.palette == Palette.MONO && !useCustom
    val accent = when {
        dynamic != null -> dynamic
        useCustom -> Color(custom!!.accent)
        mono && !dark -> Color(0xFF18181B)
        else -> s.palette.accent
    }
    val accent2 = when {
        dynamic != null -> shiftHue(dynamic, 40f)
        useCustom -> Color(custom!!.accent2)
        mono && !dark -> Color(0xFF52525B)
        else -> s.palette.accent2
    }
    val onA = bestOn(accent)
    val onA2 = bestOn(accent2)
    val base = buildBase(s, dark, mono, accent, accent2, onA, onA2)
    return if (useCustom) base.withBg(Color(custom!!.bgTop), if (s.style == UiStyle.NEO) Color(custom.bgTop) else Color(custom.bgBottom)) else base
}

private fun buildBase(s: AppSettings, dark: Boolean, mono: Boolean, accent: Color, accent2: Color, onA: Color, onA2: Color): NovaColors {

    if (s.style == UiStyle.NEO) {
        return if (dark) {
            val bg = lerp(Color(0xFF121212), accent, 0.05f)
            val ink = Color(0xFFF5F5F5)
            NovaColors(true, bg, bg, ink, ink.copy(alpha = 0.7f), accent, accent2, onA, onA2, Color(0xFF1F1F1F), ink, accent)
        } else {
            val bg = lerp(Color(0xFFFFFBF0), accent, 0.16f)
            val ink = Color(0xFF111111)
            NovaColors(false, bg, bg, ink, ink.copy(alpha = 0.66f), accent, accent2, onA, onA2, Color.White, ink, ink)
        }
    }
    return if (dark) {
        val base = if (mono) Color.Black else Color(0xFF050505)
        val top = lerp(base, accent, if (mono) 0.08f else 0.13f)
        NovaColors(
            true, top, base, Color(0xFFF5F5F7), Color(0xFF9A9AA2), accent, accent2, onA, onA2,
            lerp(Color(0xFF0E0E10), accent, 0.05f), Color.White.copy(alpha = 0.10f), Color.Transparent
        )
    } else {
        val ink = Color(0xFF16132B)
        NovaColors(
            false, lerp(Color.White, accent, 0.22f), lerp(Color.White, accent, 0.05f), ink, ink.copy(alpha = 0.62f),
            accent, accent2, onA, onA2, lerp(Color.White, accent, 0.04f), Color.White.copy(alpha = 0.8f), Color.Transparent
        )
    }
}

fun buildLook(s: AppSettings): NovaLook {
    val neo = s.style == UiStyle.NEO
    return NovaLook(
        style = s.style,
        radius = (if (neo) s.neoRadius else s.glassRadius).dp,
        border = (if (neo) s.neoBorder else 1).dp,
        shadow = (if (neo) s.neoShadow else 0).dp,
        glassAlpha = s.glassOpacity / 100f,
        animations = s.animations,
        compact = s.compactList,
        showArt = s.showArt,
        artShape = s.artShape,
        blurNow = s.blurNowPlaying
    )
}

val LocalNova = staticCompositionLocalOf { buildColors(AppSettings(), true) }
val LocalLook = staticCompositionLocalOf { buildLook(AppSettings()) }

object Nova {
    val c: NovaColors @Composable @ReadOnlyComposable get() = LocalNova.current
    val look: NovaLook @Composable @ReadOnlyComposable get() = LocalLook.current
}

@Composable
fun MusicTheme(settings: AppSettings, custom: CustomTheme?, dynamicAccent: Color?, content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val dyn = if (settings.dynamicColor && dynamicAccent != null)
        androidx.compose.animation.animateColorAsState(dynamicAccent, androidx.compose.animation.core.tween(700), label = "dyn").value
    else null
    val colors = remember(settings, sysDark, custom, dyn) { buildColors(settings, sysDark, custom, dyn) }
    val look = remember(settings) { buildLook(settings) }
    val base = LocalDensity.current
    val density = remember(base, settings.fontScale) { Density(base.density, base.fontScale * settings.fontScale / 100f) }
    val scheme = remember(colors) {
        val surface = colors.surfaceSolid
        val variant = lerp(surface, colors.onBg, 0.10f)
        if (colors.dark) darkColorScheme(
            primary = colors.accent, onPrimary = colors.onAccent, secondary = colors.accent2, onSecondary = colors.onAccent2,
            background = colors.bgBottom, onBackground = colors.onBg, surface = surface, onSurface = colors.onBg,
            surfaceVariant = variant, onSurfaceVariant = colors.muted, outline = colors.border,
            surfaceContainer = surface, surfaceContainerHigh = surface
        ) else lightColorScheme(
            primary = colors.accent, onPrimary = colors.onAccent, secondary = colors.accent2, onSecondary = colors.onAccent2,
            background = colors.bgBottom, onBackground = colors.onBg, surface = surface, onSurface = colors.onBg,
            surfaceVariant = variant, onSurfaceVariant = colors.muted, outline = colors.border,
            surfaceContainer = surface, surfaceContainerHigh = surface
        )
    }
    val r = look.radius
    val shapes = remember(r) {
        Shapes(
            extraSmall = RoundedCornerShape(r.coerceAtMost(12.dp)), small = RoundedCornerShape(r.coerceAtMost(16.dp)),
            medium = RoundedCornerShape(r), large = RoundedCornerShape(r), extraLarge = RoundedCornerShape(r)
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val ctl = WindowCompat.getInsetsController(window, view)
                ctl.isAppearanceLightStatusBars = !colors.dark
                ctl.isAppearanceLightNavigationBars = !colors.dark
            }
        }
    }

    CompositionLocalProvider(LocalNova provides colors, LocalLook provides look, LocalDensity provides density) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, typography = NovaTypography, content = content)
    }
}

/** Menimpa token gaya saja (dipakai untuk pratinjau gaya di Pengaturan). */
@Composable
fun PreviewTheme(settings: AppSettings, custom: CustomTheme? = null, content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val colors = remember(settings, sysDark, custom) { buildColors(settings, sysDark, custom) }
    val look = remember(settings) { buildLook(settings) }
    CompositionLocalProvider(LocalNova provides colors, LocalLook provides look) { content() }
}
