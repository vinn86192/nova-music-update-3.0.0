package com.base.musicapp.data

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.base.musicapp.R
import java.util.Calendar

/** Pengingat harian "waktunya dengerin musik" (alarm tidak presisi, tidak perlu izin alarm eksak). */
object Reminders {
    const val ACTION = "com.base.musicapp.REMINDER"
    private const val CHANNEL = "nova_reminder"

    private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 77, Intent(ctx, ReminderReceiver::class.java).setAction(ACTION),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context, hour: Int, minute: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pending(ctx))
    }

    fun cancel(ctx: Context) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx))
    }

    fun notifyNow(ctx: Context, text: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Pengingat musik", NotificationManager.IMPORTANCE_DEFAULT))
        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        val open = PendingIntent.getActivity(ctx, 78, launch ?: Intent(), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_note)
            .setContentTitle("NovaMusic")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(4242, n) }   // SecurityException jika izin notifikasi ditolak
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val s = SettingsStore(ctx).state.value
        if (!s.reminderOn) return
        if (intent.action == Reminders.ACTION) {
            val tips = listOf(
                "Waktunya dengerin musik. Putar playlist favoritmu?",
                "Ada lagu yang lama tidak kamu putar. Buka NovaMusic dan temukan lagi.",
                "Istirahat sebentar, nyalakan lagu kesukaanmu."
            )
            Reminders.notifyNow(ctx, tips[(System.currentTimeMillis() / 86_400_000L % tips.size).toInt()])
        }
        // jadwalkan ulang untuk besok (juga setelah perangkat restart)
        Reminders.schedule(ctx, s.reminderHour, s.reminderMin)
    }
}

/** Ikon aplikasi alternatif lewat activity-alias. */
object AppIcons {
    val options = listOf(
        "galaxy" to "Galaxy", "ocean" to "Ocean", "sunset" to "Sunset",
        "emerald" to "Emerald", "rose" to "Rose", "mono" to "Mono"
    )

    private fun alias(ctx: Context, key: String) = ComponentName(
        ctx.packageName, if (key == "galaxy") "com.base.musicapp.MainActivity" else "com.base.musicapp.Icon_$key"
    )

    fun apply(ctx: Context, key: String) {
        val pm = ctx.packageManager
        // aktifkan yang baru dulu, baru matikan yang lain, agar selalu ada satu ikon peluncur
        pm.setComponentEnabledSetting(alias(ctx, key), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
        options.map { it.first }.filter { it != key }.forEach {
            pm.setComponentEnabledSetting(alias(ctx, it), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        }
    }
}
