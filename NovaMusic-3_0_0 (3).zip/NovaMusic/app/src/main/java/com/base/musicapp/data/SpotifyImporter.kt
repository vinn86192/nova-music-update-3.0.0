package com.base.musicapp.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/**
 * Import playlist Spotify TANPA login.
 *
 * Web API resmi Spotify (mode Development, sejak Feb 2026) hanya mengizinkan membaca playlist milik
 * sendiri dan butuh akun Premium, jadi tidak cocok untuk playlist publik milik orang lain.
 * Karena itu tautan dibaca dari halaman embed publik Spotify. Ini jalur tidak resmi: format
 * bisa berubah, dan biasanya hanya memuat sebagian lagu (sekitar 50-100). Jalur cadangan:
 * tempel teks atau file CSV (Exportify).
 */
object SpotifyImporter {
    data class Link(val kind: String, val id: String)

    private val linkRegex = Regex("""(playlist|album)[/:]([A-Za-z0-9]{22})""")
    private val rawId = Regex("^[A-Za-z0-9]{22}$")

    fun parseLink(input: String): Link? {
        val t = input.trim()
        linkRegex.find(t)?.let { return Link(it.groupValues[1], it.groupValues[2]) }
        if (rawId.matches(t)) return Link("playlist", t)
        return null
    }

    // ------------------------------------------------------------ tautan
    fun fetch(link: Link): SpotifyPlaylist {
        val html = try {
            httpGet("https://open.spotify.com/embed/${link.kind}/${link.id}")
        } catch (e: SpotifyException) {
            throw e
        } catch (e: IOException) {
            throw SpotifyException("Tidak bisa terhubung ke Spotify. Periksa koneksi internet.")
        }
        val parsed = parseNextData(html) ?: parseResource(html)
            ?: throw SpotifyException(
                "Data playlist tidak bisa dibaca (format Spotify mungkin berubah). " +
                    "Coba tab Tempel teks atau File CSV."
            )
        if (parsed.second.isEmpty()) {
            throw SpotifyException("Playlist kosong atau bersifat privat. Coba tab Tempel teks atau File CSV.")
        }
        return SpotifyPlaylist(
            id = link.id,
            name = parsed.first ?: "Playlist Spotify",
            url = "https://open.spotify.com/${link.kind}/${link.id}",
            tracks = parsed.second,
            importedAt = System.currentTimeMillis(),
            fromLink = true
        )
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 20_000
        c.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
        )
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        try {
            val code = c.responseCode
            if (code == 404) throw SpotifyException("Playlist tidak ditemukan. Pastikan tautannya benar dan playlist bersifat publik.")
            if (code !in 200..299) throw SpotifyException("Spotify menjawab dengan kode $code. Coba lagi nanti.")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun clean(s: String) = s.replace('\u00a0', ' ').trim()

    private fun parseNextData(html: String): Pair<String?, List<SpotifyTrack>>? {
        val m = Regex("""<script id="__NEXT_DATA__"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
            .find(html) ?: return null
        return try {
            val root = JSONObject(m.groupValues[1])
            val entity = root.optJSONObject("props")?.optJSONObject("pageProps")
                ?.optJSONObject("state")?.optJSONObject("data")?.optJSONObject("entity")
            val arr = entity?.optJSONArray("trackList") ?: findArray(root, "trackList") ?: return null
            val name = entity?.optString("name")?.takeIf { it.isNotBlank() }
                ?: entity?.optString("title")?.takeIf { it.isNotBlank() }
            val tracks = (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val title = clean(o.optString("title"))
                if (title.isBlank()) null
                else SpotifyTrack(title, clean(o.optString("subtitle")), o.optLong("duration", 0L), o.optString("uri", ""))
            }
            name to tracks
        } catch (e: Exception) {
            null
        }
    }

    /** Format embed lama: JSON (kadang URL-encoded) di <script id="resource">. */
    private fun parseResource(html: String): Pair<String?, List<SpotifyTrack>>? {
        val m = Regex("""<script id="resource"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
            .find(html) ?: return null
        return try {
            val raw = m.groupValues[1].trim()
            val root = JSONObject(if (raw.startsWith("{")) raw else URLDecoder.decode(raw, "UTF-8"))
            val items = root.optJSONObject("tracks")?.optJSONArray("items") ?: return null
            val tracks = (0 until items.length()).mapNotNull { i ->
                val t = items.optJSONObject(i)?.optJSONObject("track") ?: return@mapNotNull null
                val title = clean(t.optString("name"))
                if (title.isBlank()) return@mapNotNull null
                val artists = t.optJSONArray("artists")
                val artist = if (artists == null) "" else
                    (0 until artists.length()).joinToString(", ") { artists.optJSONObject(it)?.optString("name").orEmpty() }
                SpotifyTrack(title, clean(artist), t.optLong("duration_ms", 0L), t.optString("uri", ""))
            }
            root.optString("name").takeIf { it.isNotBlank() } to tracks
        } catch (e: Exception) {
            null
        }
    }

    private fun findArray(node: Any?, key: String): JSONArray? {
        when (node) {
            is JSONObject -> {
                node.optJSONArray(key)?.let { return it }
                val ks = node.keys()
                while (ks.hasNext()) findArray(node.opt(ks.next()), key)?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) findArray(node.opt(i), key)?.let { return it }
        }
        return null
    }

    // ------------------------------------------------------------ teks
    /** Satu lagu per baris: "Artis - Judul" (urutan dicoba dua arah) atau hanya "Judul". */
    fun parseText(text: String): List<SpotifyTrack> {
        val num = Regex("""^\s*\d+\s*[.)]\s+""")
        val sep = Regex("""\s[-–—|]\s""")
        return text.lineSequence().mapNotNull { raw ->
            val line = num.replace(raw.trim(), "").trim()
            if (line.isBlank()) return@mapNotNull null
            val m = sep.find(line)
            if (m != null) {
                SpotifyTrack(
                    title = line.substring(m.range.last + 1).trim(),
                    artist = line.substring(0, m.range.first).trim(),
                    swappable = true
                )
            } else SpotifyTrack(title = line, artist = "")
        }.toList()
    }

    // ------------------------------------------------------------ CSV (Exportify)
    fun parseCsv(text: String): List<SpotifyTrack> {
        val rows = csvRows(text.removePrefix("\uFEFF"))
        if (rows.size < 2) throw SpotifyException("File CSV kosong.")
        val head = rows[0].map { it.trim().lowercase() }
        val titleKeys = setOf("track name", "track", "title", "song", "name", "track_name", "track title")
        val iTitle = head.indexOfFirst { it in titleKeys }
        val iArtist = head.indexOfFirst { it.contains("artist") && !it.startsWith("album") }
        val iDur = head.indexOfFirst { it.startsWith("duration") }
        val iUri = head.indexOfFirst { it == "track uri" || it == "uri" || it == "spotify uri" }
        if (iTitle < 0) throw SpotifyException("Kolom judul tidak ditemukan. Gunakan CSV hasil ekspor Exportify.")
        return rows.drop(1).mapNotNull { r ->
            val title = clean(r.getOrNull(iTitle).orEmpty())
            if (title.isBlank()) return@mapNotNull null
            SpotifyTrack(
                title = title,
                artist = if (iArtist >= 0) clean(r.getOrNull(iArtist).orEmpty().replace(";", ", ")) else "",
                durationMs = if (iDur >= 0) r.getOrNull(iDur)?.trim()?.toLongOrNull() ?: 0L else 0L,
                uri = if (iUri >= 0) r.getOrNull(iUri).orEmpty().trim() else ""
            )
        }
    }

    private fun csvRows(s: String): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (quoted) {
                if (ch == '"') {
                    if (i + 1 < s.length && s[i + 1] == '"') { sb.append('"'); i++ } else quoted = false
                } else sb.append(ch)
            } else {
                when (ch) {
                    '"' -> quoted = true
                    ',' -> { row.add(sb.toString()); sb.setLength(0) }
                    '\n' -> { row.add(sb.toString()); sb.setLength(0); rows.add(row); row = ArrayList() }
                    '\r' -> {}
                    else -> sb.append(ch)
                }
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString()); rows.add(row) }
        return rows
    }
}
