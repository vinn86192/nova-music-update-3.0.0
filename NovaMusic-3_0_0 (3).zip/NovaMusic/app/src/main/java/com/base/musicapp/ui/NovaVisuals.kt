package com.base.musicapp.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.IconButton
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import com.base.musicapp.data.Song
import com.base.musicapp.ui.theme.bestOn
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.R
import com.base.musicapp.ui.theme.Nova

// Elemen visual bersama Nova 3.0 (hanya tampilan, tanpa logic).

/** Logo bintang-orbit Nova. */
@Composable
fun NovaMark(modifier: Modifier = Modifier, size: Dp = 28.dp) {
    Image(painterResource(R.drawable.nova_logo), null, modifier = modifier.size(size))
}

/** Lencana ikon: kaca tipis bertinta aksen (neo: blok solid). Dipakai sebagai "logo fitur". */
@Composable
fun IconBadge(icon: ImageVector, size: Dp = 40.dp, modifier: Modifier = Modifier) {
    val c = Nova.c
    val look = Nova.look
    val shape = RoundedCornerShape(size * 0.32f)
    Box(
        modifier.size(size).clip(shape)
            .background(
                if (look.neo) SolidColor(c.accent)
                else Brush.linearGradient(listOf(c.accent.copy(alpha = 0.26f), c.accent2.copy(alpha = 0.10f)))
            )
            .border(1.dp, if (look.neo) c.border else c.accent.copy(alpha = 0.35f), shape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = if (look.neo) c.onAccent else c.accent, modifier = Modifier.size(size * 0.52f))
    }
}

/** Kepala Beranda: logo + wordmark, lalu sapaan. */
@Composable
fun HomeHeader(title: String, subtitle: String) {
    val c = Nova.c
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NovaMark(size = 26.dp)
            Spacer(Modifier.width(8.dp))
            Text("NOVA", color = c.onBg, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        }
        Spacer(Modifier.height(18.dp))
        ScreenTitle(title, subtitle)
    }
}

/** Satu kartu kaca berisi beberapa angka, dipisah garis tipis. Pasangan = (label, nilai). */
@Composable
fun StatStrip(items: List<Pair<String, String>>, modifier: Modifier = Modifier) {
    val c = Nova.c
    val look = Nova.look
    Row(
        modifier.fillMaxWidth().panel(radius = if (look.neo) look.radius else 22.dp).padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { i, item ->
            if (i > 0) Box(Modifier.width(1.dp).height(28.dp).background(c.onBg.copy(alpha = 0.12f)))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(item.second, color = c.onBg, fontSize = 22.sp, fontWeight = if (look.neo) FontWeight.Black else FontWeight.Bold, letterSpacing = (-0.5).sp)
                Text(item.first.uppercase(), color = c.muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            }
        }
    }
}

/** Ubin pintasan fitur: lencana ikon + label. */
@Composable
fun FeatureTile(label: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Nova.c
    val look = Nova.look
    Row(
        modifier.panel(radius = if (look.neo) look.radius else 20.dp, onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon, 36.dp)
        Spacer(Modifier.width(10.dp))
        Text(label, color = c.onBg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** Kontrol segmen kaca (pengganti deretan chip tab). */
@Composable
fun NovaSegmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val c = Nova.c
    val look = Nova.look
    val outer = if (look.neo) look.radius else 18.dp
    val inner = if (look.neo) look.radius else 14.dp
    Row(modifier.fillMaxWidth().panel(radius = outer).padding(4.dp)) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(inner))
                    .background(
                        if (sel) {
                            if (look.neo) SolidColor(c.accent) else Brush.linearGradient(listOf(c.accent, c.accent2))
                        } else SolidColor(Color.Transparent)
                    )
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (sel) c.onAccent else c.muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** Kartu album: cover di dalam panel kaca. */
@Composable
fun AlbumCard(song: Song, subtitle: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Nova.c
    val look = Nova.look
    Column(modifier.panel(radius = if (look.neo) look.radius else 22.dp, onClick = onClick).padding(10.dp)) {
        Artwork(song, Modifier.fillMaxWidth().aspectRatio(1f), artShape(16.dp))
        Spacer(Modifier.height(8.dp))
        Text(song.album, color = c.onBg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Baris artis: avatar bercincin gradien + bintang favorit. */
@Composable
fun ArtistRow(song: Song, name: String, count: Int, favorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    val c = Nova.c
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).border(1.5.dp, Brush.linearGradient(listOf(c.accent, c.accent2)), CircleShape).padding(3.dp),
            contentAlignment = Alignment.Center
        ) { Artwork(song, Modifier.fillMaxSize(), CircleShape) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = c.onBg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$count lagu", color = c.muted, fontSize = 12.sp)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Favorit", tint = if (favorite) c.accent else c.muted)
        }
    }
}

/** Ilustrasi keadaan kosong: logo Nova di dalam halo aksen. */
@Composable
fun EmptyState(title: String, subtitle: String, modifier: Modifier = Modifier) {
    val c = Nova.c
    Column(modifier.fillMaxWidth().padding(vertical = 48.dp, horizontal = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            Box(Modifier.size(160.dp).background(Brush.radialGradient(listOf(c.accent.copy(alpha = 0.25f), Color.Transparent)), CircleShape))
            NovaMark(size = 72.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text(title, color = c.onBg, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = c.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

/** Kartu playlist: lencana gradien, judul, subjudul, dan panah. */
@Composable
fun PlaylistTile(title: String, sub: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val neo = look.neo
    val badge = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().panel(radius = if (neo) look.radius else 22.dp, onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(52.dp).clip(badge)
                .background(if (neo) SolidColor(tint) else Brush.linearGradient(listOf(tint.copy(alpha = 0.34f), tint.copy(alpha = 0.10f))))
                .border(1.dp, if (neo) c.border else tint.copy(alpha = 0.35f), badge),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = if (neo) bestOn(tint) else tint) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = c.onBg, fontWeight = if (neo) FontWeight.Black else FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = c.muted)
    }
}

/** Kepala halaman detail (album, artis, playlist): cover besar, judul, dan tombol kembali di atas gradien aksen. */
@Composable
fun DetailHero(first: Song?, title: String, subtitle: String, onBack: () -> Unit) {
    val c = Nova.c
    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(c.accent.copy(alpha = 0.16f), Color.Transparent)))) {
        IconButton(onClick = onBack, modifier = Modifier.padding(8.dp)) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (first != null) {
                Artwork(first, Modifier.size(104.dp), artShape(24.dp))
                Spacer(Modifier.width(16.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, color = c.onBg, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, color = c.muted, fontSize = 13.sp)
            }
        }
    }
}
