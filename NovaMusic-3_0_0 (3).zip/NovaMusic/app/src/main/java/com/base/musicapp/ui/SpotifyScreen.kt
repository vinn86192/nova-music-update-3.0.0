package com.base.musicapp.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.ImportState
import com.base.musicapp.data.Song
import com.base.musicapp.data.SpotifyImporter
import com.base.musicapp.data.MatchResult
import com.base.musicapp.data.SpotifyTrack
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.ui.theme.*

private val SpotifyGreen = Color(0xFF1ED760)

private fun open(ctx: Context, primary: String, fallback: String? = null) {
    fun go(u: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    try { go(primary) } catch (e: Exception) {
        try { if (fallback != null) go(fallback) else throw e } catch (e2: Exception) {
            Toast.makeText(ctx, "Tidak bisa membuka tautan.", Toast.LENGTH_SHORT).show()
        }
    }
}

private fun openTrack(ctx: Context, t: SpotifyTrack) {
    val id = t.uri.substringAfter("spotify:track:", "")
    val web = if (id.isNotEmpty()) "https://open.spotify.com/track/$id"
    else "https://open.spotify.com/search/" + Uri.encode("${t.artist} ${t.title}".trim())
    open(ctx, if (t.uri.startsWith("spotify:")) t.uri else web, web)
}

// ================================================================ IMPORT
@Composable
fun SpotifyImportScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val state by vm.importState.collectAsState()
    var mode by remember { mutableIntStateOf(0) }
    var link by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var textName by remember { mutableStateOf("") }
    var saveName by remember { mutableStateOf("") }
    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.previewCsv(uri)
    }
    val shared by vm.pendingSpotifyShare.collectAsState()
    LaunchedEffect(shared) {
        shared?.let { t ->
            mode = 0
            link = SpotifyImporter.parseLink(t)?.let { "https://open.spotify.com/${it.kind}/${it.id}" } ?: t
            vm.pendingSpotifyShare.value = null
            vm.fetchSpotify(link)
        }
    }
    DisposableEffect(Unit) { onDispose { vm.resetImport() } }
    LaunchedEffect(state) { (state as? ImportState.Preview)?.let { saveName = it.playlist.name } }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
                ScreenTitle("Import Spotify", "Playlist Spotify → lagu di perangkatmu")
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Tautan", "Tempel teks", "File CSV").withIndex().toList()) { (i, t) ->
                    NovaChip(t, mode == i, { mode = i; vm.resetImport() })
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (mode) {
                    0 -> {
                        Text("Tempel tautan playlist (atau album) Spotify yang bersifat publik.", color = c.muted, fontSize = 13.sp)
                        NovaField(link, { link = it }, "https://open.spotify.com/playlist/...", Modifier.fillMaxWidth(), Icons.Rounded.Link, keyboard = KeyboardType.Uri)
                        NovaButton("Ambil playlist", { vm.fetchSpotify(link) }, Modifier.fillMaxWidth(), Icons.Rounded.CloudDownload, enabled = link.isNotBlank() && state != ImportState.Loading)
                        Text(
                            "Dibaca dari halaman embed publik Spotify tanpa login. Hanya sebagian lagu (sekitar 50-100) yang biasanya tersedia.",
                            color = c.muted, fontSize = 11.sp
                        )
                    }
                    1 -> {
                        Text("Satu lagu per baris, misalnya \"Artis - Judul\". Urutan dicoba dua arah.", color = c.muted, fontSize = 13.sp)
                        NovaField(textName, { textName = it }, "Nama playlist (opsional)", Modifier.fillMaxWidth())
                        NovaField(text, { text = it }, "Tulis atau tempel daftar lagu...", Modifier.fillMaxWidth(), singleLine = false, minHeight = 160.dp)
                        NovaButton("Cocokkan lagu", { vm.previewText(textName, text) }, Modifier.fillMaxWidth(), Icons.Rounded.Search, enabled = text.isNotBlank() && state != ImportState.Loading)
                    }
                    else -> {
                        Text("IMPORT LENGKAP: untuk memasukkan seluruh lagu playlist (termasuk playlist panjang), ekspor playlist ke CSV lewat Exportify, lalu pilih file CSV di sini. NovaMusic membaca semua baris lagu di file, bukan hanya 50 lagu pertama.", color = c.muted, fontSize = 13.sp)
                        NovaButton("Pilih CSV playlist lengkap", { csvPicker.launch(arrayOf("text/*", "application/*", "*/*")) }, Modifier.fillMaxWidth(), Icons.Rounded.FolderOpen, enabled = state != ImportState.Loading)
                    }
                }
            }
        }

        when (val st = state) {
            ImportState.Idle -> {}
            ImportState.Loading -> item { Text("Memproses...", color = c.muted) }
            is ImportState.Error -> item {
                Row(Modifier.fillMaxWidth().panel(fill = if (Nova.look.neo) Heart else Heart.copy(alpha = 0.18f)).padding(14.dp)) {
                    Icon(Icons.Rounded.ErrorOutline, null, tint = if (Nova.look.neo) bestOn(Heart) else Heart)
                    Spacer(Modifier.width(10.dp))
                    Text(st.message, color = if (Nova.look.neo) bestOn(Heart) else c.onBg, fontSize = 13.sp)
                }
            }
            is ImportState.Preview -> {
                val ok = st.matches.count { it.song != null }
                item {
                    Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "${st.matches.size} lagu berhasil dibaca • $ok cocok dengan file musik di perangkat",
                            color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp
                        )
                        if (st.note != null) Text(st.note, color = c.muted, fontSize = 12.sp)
                        Text("Semua lagu dari daftar akan tersimpan sebagai metadata playlist. Hanya lagu yang file audionya tersedia di perangkat yang bisa diputar langsung di NovaMusic.", color = c.muted, fontSize = 12.sp)
                        NovaField(saveName, { saveName = it }, "Nama playlist", Modifier.fillMaxWidth())
                        NovaButton(
                            "Simpan di Playlist Spotify", {
                                vm.saveSpotifyList(st.playlist, saveName)
                                Toast.makeText(ctx, "Tersimpan. Pencocokan diperbarui otomatis saat ada lagu baru.", Toast.LENGTH_LONG).show()
                                onBack()
                            }, Modifier.fillMaxWidth(), Icons.Rounded.CloudDownload
                        )
                        NovaButton(
                            "Buat playlist dari yang cocok", {
                                val n = vm.saveLocalPlaylist(saveName, st.matches)
                                Toast.makeText(ctx, "Playlist dibuat: $n lagu", Toast.LENGTH_SHORT).show()
                                onBack()
                            }, Modifier.fillMaxWidth(), Icons.Rounded.PlaylistAdd, BtnKind.Secondary, enabled = ok > 0
                        )
                    }
                }
                items(st.matches) { MatchRow(vm, it) }
            }
        }
    }
}

@Composable
private fun MatchRow(vm: MusicViewModel, m: MatchResult, onPick: (() -> Unit)? = null) {
    val c = Nova.c
    val ctx = LocalContext.current
    val found = m.song != null
    Row(
        Modifier.fillMaxWidth().panel(radius = 14.dp, flat = true).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (found) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null, tint = if (found) SpotifyGreen else c.muted, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(m.track.title, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(
                if (found) "Cocok: ${m.song!!.title} • ${m.song.artist}" else m.track.artist.ifBlank { "Artis tidak diketahui" },
                color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (!found && onPick != null) IconButton(onClick = onPick) { Icon(Icons.Rounded.Link, "Cocokkan manual", tint = c.accent) }
        if (!found) IconButton(onClick = { openTrack(ctx, m.track) }) { Icon(Icons.Rounded.OpenInNew, "Buka di Spotify", tint = c.muted) }
    }
}

// ================================================================ DETAIL PLAYLIST SPOTIFY
@Composable
fun SpotifyDetailScreen(vm: MusicViewModel, id: String, onBack: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val lists by vm.spotifyLists.collectAsState()
    val matches by vm.spotifyMatches.collectAsState()
    val pl = lists.firstOrNull { it.id == id }
    if (pl == null) { onBack(); return }
    val m = matches[id].orEmpty()
    val playable = remember(m) { m.mapNotNull { it.song } }
    var busy by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf<SpotifyTrack?>(null) }

    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
                Column(Modifier.weight(1f)) {
                    Text(pl.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = c.onBg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${playable.size} dari ${pl.tracks.size} lagu ada di perangkat", color = c.muted, fontSize = 12.sp)
                }
            }
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { NovaButton("Putar", { vm.playSongs(playable, 0) }, icon = Icons.Rounded.PlayArrow, enabled = playable.isNotEmpty()) }
                item { NovaButton("Acak", { vm.shuffleAll(playable) }, icon = Icons.Rounded.Shuffle, kind = BtnKind.Secondary, enabled = playable.isNotEmpty()) }
                if (pl.fromLink) item {
                    NovaButton(if (busy) "Memperbarui..." else "Perbarui", {
                        busy = true
                        vm.refreshSpotify(pl.id) { msg -> busy = false; Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
                    }, icon = Icons.Rounded.Refresh, kind = BtnKind.Secondary, enabled = !busy)
                }
                if (m.any { it.song == null }) item {
                    NovaButton("Bagikan yang belum ada", {
                        val text = m.filter { it.song == null }.joinToString("\n") { "${it.track.artist} - ${it.track.title}" }
                        ctx.startActivity(
                            Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Daftar lagu yang belum ada")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }, icon = Icons.Rounded.Share, kind = BtnKind.Secondary)
                }
                if (pl.url.isNotBlank()) item {
                    NovaButton("Buka Spotify", { open(ctx, pl.url) }, icon = Icons.Rounded.OpenInNew, kind = BtnKind.Secondary)
                }
            }
        }
        items(m) { r ->
            val s = r.song
            if (s != null) SongRow(vm, s) { vm.playSongs(playable, playable.indexOf(s)) }
            else MatchRow(vm, r) { picking = r.track }
        }
    }
    picking?.let { t ->
        SongPickerDialog(vm, t, { picking = null }) { song -> vm.linkTrack(t, song); picking = null }
    }
}

@Composable
private fun SongPickerDialog(vm: MusicViewModel, track: SpotifyTrack, onDismiss: () -> Unit, onPick: (Song) -> Unit) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    var q by remember { mutableStateOf(track.title) }
    val results = remember(q, songs) {
        if (q.isBlank()) emptyList() else songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) }.take(25)
    }
    NovaDialog("Cocokkan manual", onDismiss, dismissText = "Tutup") {
        Text("${track.title} • ${track.artist}", color = c.muted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        NovaField(q, { q = it }, "Cari lagu di perangkat", Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.heightIn(max = 280.dp)) {
            items(results, key = { it.id }) { s ->
                Column(Modifier.fillMaxWidth().clickable { onPick(s) }.padding(vertical = 8.dp, horizontal = 4.dp)) {
                    Text(s.title, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(s.artist, color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
