package com.base.musicapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.Detail
import com.base.musicapp.data.Song
import com.base.musicapp.data.SortMode
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.ui.theme.*
import java.util.Calendar

// ---------------------------------------------------------------- HOME
@Composable
fun HomeScreen(vm: MusicViewModel, onDetail: (Detail) -> Unit, onOpen: (Page) -> Unit) {
    val c = Nova.c
    val cfg by vm.cfg.state.collectAsState()
    val songs by vm.songs.collectAsState()
    val recents by vm.recents.collectAsState()
    val favs by vm.favorites.collectAsState()
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when (hour) {
        in 4..10 -> "Selamat pagi"
        in 11..14 -> "Selamat siang"
        in 15..17 -> "Selamat sore"
        else -> "Selamat malam"
    }
    val favArtists by vm.favoriteArtists.collectAsState()
    val favSongs = remember(songs, favs) { songs.filter { it.id in favs } }
    val latest = remember(songs) { songs.sortedByDescending { it.dateAdded }.take(15) }
    val albums = remember(songs) { songs.map { it.albumId }.distinct().size }
    val artists = remember(songs) { songs.map { it.artist }.distinct().size }
    val shown = remember(songs, cfg.homeSongLimit) { if (cfg.homeSongLimit > 0) songs.take(cfg.homeSongLimit) else songs }

    LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            val name = cfg.userName.trim()
            HomeHeader(if (name.isEmpty()) greeting else "$greeting, $name", "${songs.size} lagu siap diputar")
        }
        if (cfg.showStats && songs.isNotEmpty()) {
            item {
                StatStrip(listOf("Lagu" to songs.size.toString(), "Album" to albums.toString(), "Artis" to artists.toString()))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NovaButton("Acak semua", { vm.shuffleAll(songs) }, Modifier.weight(1f), Icons.Rounded.Shuffle)
                NovaButton("Putar semua", { vm.playSongs(songs, 0) }, Modifier.weight(1f), Icons.Rounded.PlayArrow, BtnKind.Secondary)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureTile("Statistik", Icons.Rounded.BarChart, { onOpen(Page.STATS) }, Modifier.weight(1f))
                    FeatureTile("Library pintar", Icons.Rounded.AutoAwesome, { onOpen(Page.SMART) }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureTile("Generator playlist", Icons.Rounded.PlaylistAdd, { onOpen(Page.GENERATOR) }, Modifier.weight(1f))
                    FeatureTile("Baru ditambahkan", Icons.Rounded.Schedule, { onOpen(Page.TIMELINE) }, Modifier.weight(1f))
                }
            }
        }
        if (favArtists.isNotEmpty()) {
            item { SectionTitle("Artis favorit") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(favArtists.toList().sorted()) { a ->
                        NovaChip(a, false, {
                            val l = songs.filter { it.artist == a }
                            onDetail(Detail(a, "${l.size} lagu", l))
                        })
                    }
                }
            }
        }
        if (cfg.showRecents && recents.isNotEmpty()) {
            item { SectionTitle("Terakhir diputar") }
            item { CardRow(vm, recents) }
        }
        if (cfg.showLatest && latest.isNotEmpty()) {
            item { SectionTitle("Baru ditambahkan") }
            item { CardRow(vm, latest) }
        }
        if (cfg.showFavs && favSongs.isNotEmpty()) {
            item { SectionTitle("Favorit kamu") }
            item { CardRow(vm, favSongs) }
        }
        item { SectionTitle("Semua lagu") }
        items(shown, key = { it.id }) { s ->
            SongRow(vm, s) { vm.playSongs(songs, songs.indexOf(s)) }
        }
        if (songs.isEmpty()) item { EmptyNote("Belum ada lagu ditemukan di perangkat.") }
    }
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier) {
    val c = Nova.c
    Column(modifier.panel(radius = if (Nova.look.neo) Nova.look.radius else 16.dp).padding(12.dp)) {
        Text(value, color = c.onBg, fontSize = 22.sp, fontWeight = if (Nova.look.neo) FontWeight.Black else FontWeight.ExtraBold)
        Text(label, color = c.muted, fontSize = 12.sp)
    }
}

@Composable
private fun CardRow(vm: MusicViewModel, list: List<Song>) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list, key = { it.id }) { s -> SongCard(s) { vm.playSongs(list, list.indexOf(s)) } }
    }
}

// ---------------------------------------------------------------- LIBRARY
@Composable
fun LibraryScreen(vm: MusicViewModel, onDetail: (Detail) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val songs by vm.songs.collectAsState()
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Library", "${songs.size} lagu di perangkat", modifier = Modifier.padding(20.dp, 16.dp, 20.dp, 12.dp))
        NovaSegmented(listOf("Lagu", "Album", "Artis"), tab, { tab = it }, Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        when (tab) {
            0 -> SongsTab(vm, songs)
            1 -> AlbumsTab(songs, onDetail)
            else -> ArtistsTab(vm, songs, onDetail)
        }
    }
}

@Composable
private fun SongsTab(vm: MusicViewModel, songs: List<Song>) {
    val cfg by vm.cfg.state.collectAsState()
    var sort by remember(cfg.defaultSort) { mutableStateOf(cfg.defaultSort) }
    val sorted = remember(songs, sort) {
        when (sort) {
            SortMode.TITLE -> songs.sortedBy { it.title.lowercase() }
            SortMode.ARTIST -> songs.sortedBy { it.artist.lowercase() }
            SortMode.RECENT -> songs.sortedByDescending { it.dateAdded }
            SortMode.DURATION -> songs.sortedByDescending { it.duration }
        }
    }
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)) {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                items(SortMode.values().toList()) { m -> NovaChip(m.label, sort == m, { sort = m }) }
            }
        }
        items(sorted, key = { it.id }) { s -> SongRow(vm, s) { vm.playSongs(sorted, sorted.indexOf(s)) } }
    }
}

@Composable
private fun AlbumsTab(songs: List<Song>, onDetail: (Detail) -> Unit) {
    val c = Nova.c
    val albums = remember(songs) { songs.groupBy { it.albumId }.values.sortedBy { it.first().album.lowercase() } }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2), contentPadding = PaddingValues(20.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(albums) { list ->
            val first = list.first()
            AlbumCard(first, "${first.artist} • ${list.size} lagu", { onDetail(Detail(first.album, first.artist, list)) })
        }
    }
}

@Composable
private fun ArtistsTab(vm: MusicViewModel, songs: List<Song>, onDetail: (Detail) -> Unit) {
    val c = Nova.c
    val favArtists by vm.favoriteArtists.collectAsState()
    val artists = remember(songs, favArtists) {
        songs.groupBy { it.artist }.toList().sortedWith(compareByDescending<Pair<String, List<Song>>> { it.first in favArtists }.thenBy { it.first.lowercase() })
    }
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)) {
        items(artists) { (name, list) ->
            ArtistRow(list.first(), name, list.size, name in favArtists, { onDetail(Detail(name, "${list.size} lagu", list)) }, { vm.toggleFavoriteArtist(name) })
        }
    }
}

// ---------------------------------------------------------------- SEARCH
@Composable
fun SearchScreen(vm: MusicViewModel) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    var q by remember { mutableStateOf("") }
    val results = remember(songs, q) {
        if (q.isBlank()) emptyList() else songs.filter {
            it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        ScreenTitle("Cari", "Temukan lagu, artis, atau album")
        Spacer(Modifier.height(14.dp))
        NovaField(q, { q = it }, "Judul, artis, atau album", Modifier.fillMaxWidth(), Icons.Rounded.Search)
        Spacer(Modifier.height(8.dp))
        if (q.isBlank()) EmptyState("Mau dengar apa hari ini?", "Ketik judul, nama artis, atau album untuk mulai mencari.")
        else if (results.isEmpty()) EmptyState("Tidak ada hasil", "Coba kata kunci lain.")
        LazyColumn {
            items(results, key = { it.id }) { s -> SongRow(vm, s) { vm.playSongs(results, results.indexOf(s)) } }
        }
    }
}

// ---------------------------------------------------------------- PLAYLISTS
@Composable
fun PlaylistsScreen(
    vm: MusicViewModel,
    onDetail: (Detail) -> Unit,
    onSpotifyImport: () -> Unit,
    onSpotifyOpen: (String) -> Unit,
    onAlbumImport: () -> Unit = {},
    onAlbum: () -> Unit = {}
) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    val favs by vm.favorites.collectAsState()
    val pls by vm.playlists.collectAsState()
    val albumCount by vm.localAlbum.collectAsState()
    val spotify by vm.spotifyLists.collectAsState()
    val matches by vm.spotifyMatches.collectAsState()
    var dlg by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("Playlist", "${pls.size + 1} koleksi", modifier = Modifier.weight(1f))
                IconBadge(Icons.Rounded.Add, 44.dp, Modifier.clickable { dlg = true })
            }
        }
        item {
            NovaButton("Import dari Spotify", onSpotifyImport, Modifier.fillMaxWidth(), Icons.Rounded.Download)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NovaButton("Spotify → Album Lokal", onAlbumImport, Modifier.weight(1f), Icons.Rounded.CloudDownload, BtnKind.Secondary)
                NovaButton("Album Lokal (${albumCount.size})", onAlbum, Modifier.weight(1f), Icons.Rounded.LibraryMusic, BtnKind.Secondary)
            }
        }
        item {
            val fav = songs.filter { it.id in favs }
            PlaylistCard("Favorit", "${fav.size} lagu", Icons.Rounded.Favorite, Heart) { onDetail(Detail("Favorit", "${fav.size} lagu", fav)) }
        }
        items(pls.keys.toList()) { n ->
            val list = vm.playlistSongs(n)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    PlaylistCard(n, "${list.size} lagu", Icons.Rounded.QueueMusic, c.accent) { onDetail(Detail(n, "${list.size} lagu", list)) }
                }
                IconButton(onClick = { vm.deletePlaylist(n) }) { Icon(Icons.Rounded.Delete, "Hapus", tint = c.muted) }
            }
        }
        if (spotify.isNotEmpty()) {
            item { SectionTitle("Dari Spotify") }
            items(spotify, key = { it.id }) { pl ->
                val m = matches[pl.id].orEmpty()
                val ok = m.count { it.song != null }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        PlaylistCard(pl.name, "$ok dari ${pl.tracks.size} lagu ada di perangkat", Icons.Rounded.CloudDownload, Color(0xFF1ED760)) { onSpotifyOpen(pl.id) }
                    }
                    IconButton(onClick = { vm.deleteSpotifyList(pl.id) }) { Icon(Icons.Rounded.Delete, "Hapus", tint = c.muted) }
                }
            }
        }
    }
    if (dlg) NovaDialog(
        "Playlist baru", { dlg = false }, "Buat",
        { vm.createPlaylist(name); name = ""; dlg = false }
    ) {
        NovaField(name, { name = it }, "Nama playlist", Modifier.fillMaxWidth())
    }
}

@Composable
private fun PlaylistCard(title: String, sub: String, icon: ImageVector, tint: Color, onClick: () -> Unit) {
    PlaylistTile(title, sub, icon, tint, onClick)
}

// ---------------------------------------------------------------- DETAIL
@Composable
fun DetailScreen(vm: MusicViewModel, detail: Detail, onBack: () -> Unit) {
    val c = Nova.c
    Column(Modifier.fillMaxSize()) {
        DetailHero(detail.songs.firstOrNull(), detail.title, detail.subtitle, onBack)
        Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NovaButton("Putar", { vm.playSongs(detail.songs, 0) }, icon = Icons.Rounded.PlayArrow)
            NovaButton("Acak", { vm.shuffleAll(detail.songs) }, icon = Icons.Rounded.Shuffle, kind = BtnKind.Secondary)
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)) {
            items(detail.songs, key = { it.id }) { s -> SongRow(vm, s) { vm.playSongs(detail.songs, detail.songs.indexOf(s)) } }
        }
    }
}
