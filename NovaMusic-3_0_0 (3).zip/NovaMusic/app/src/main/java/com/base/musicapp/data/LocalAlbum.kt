package com.base.musicapp.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

/*
 * Album Lokal + importer Spotify -> YouTube.
 * File ini sengaja Kotlin murni (tanpa API Android) supaya logika pencocokan, deteksi duplikat dan
 * alur impor bisa diuji di JVM.
 */

// ================================================================ model

/** Satu lagu di Album Lokal: metadata Spotify + video YouTube yang cocok. */
data class LocalAlbumTrack(
    val id: String,
    val title: String,
    val artist: String,
    val videoId: String,
    val videoTitle: String,
    val channel: String,
    val thumbUrl: String,
    val durationMs: Long,
    val sourceName: String,
    val sourceId: String,
    val key: String,
    val addedAt: Long
) {
    val watchUrl: String get() = "https://www.youtube.com/watch?v=$videoId"
}

enum class ImportStatus(val label: String) {
    RUNNING("Berjalan"),
    COMPLETED("Selesai"),
    CANCELED("Dibatalkan"),
    QUOTA("Kuota API habis"),
    KEY_ERROR("Kunci API bermasalah"),
    NETWORK_ERROR("Jaringan bermasalah"),
    INTERRUPTED("Terhenti")
}

/** Satu baris riwayat impor. */
data class ImportRecord(
    val id: String,
    val name: String,
    val url: String,
    val startedAt: Long,
    val finishedAt: Long,
    val total: Int,
    val added: Int,
    val duplicates: Int,
    val notFound: Int,
    val failed: Int,
    val status: ImportStatus,
    val notFoundList: List<String> = emptyList()
)

enum class ImportPhase { IDLE, READING, SEARCHING, FINISHED }

data class ImportProgress(
    val phase: ImportPhase = ImportPhase.IDLE,
    val name: String = "",
    val total: Int = 0,
    val done: Int = 0,
    val added: Int = 0,
    val duplicates: Int = 0,
    val notFound: Int = 0,
    val failed: Int = 0,
    val current: String = "",
    val status: ImportStatus? = null,
    val message: String? = null
) {
    val running: Boolean get() = phase == ImportPhase.READING || phase == ImportPhase.SEARCHING
    val fraction: Float get() = if (total <= 0) 0f else (done.toFloat() / total).coerceIn(0f, 1f)
}

data class YtCandidate(
    val videoId: String,
    val title: String,
    val channel: String,
    val thumbUrl: String,
    val durationMs: Long
)

class YtException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { QUOTA, KEY, NETWORK, OTHER }
}

interface YtSearcher {
    /** Mencari kandidat video untuk satu lagu. Melempar [YtException] bila gagal. */
    suspend fun search(track: SpotifyTrack): List<YtCandidate>
}

// ================================================================ kunci duplikat

object DupeKeys {
    /**
     * Kunci duplikat dari judul + artis (sudah dinormalkan: huruf kecil, tanpa aksen/tanda baca/feat).
     * Hasil tempel teks bisa terbalik ("Artis - Judul" vs "Judul - Artis"), jadi kedua urutan
     * dicek. Elemen pertama adalah kunci yang disimpan.
     */
    fun candidates(t: SpotifyTrack): List<String> {
        val a = SpotifyMatcher.norm(t.title)
        val b = SpotifyMatcher.norm(t.artist)
        val first = "$a|$b"
        return if (t.swappable && b.isNotEmpty()) listOf(first, "$b|$a") else listOf(first)
    }
}

// ================================================================ pencocok hasil YouTube

object YtMatcher {
    private val noise = setOf(
        "official", "video", "audio", "music", "lyrics", "lyric", "hd", "hq", "mv", "topic", "vevo",
        "full", "version", "visualizer", "clip", "remastered", "remaster", "song", "the", "new"
    )
    private val badWords = setOf(
        "cover", "karaoke", "remix", "live", "reaction", "instrumental", "nightcore", "slowed",
        "reverb", "8d", "tutorial", "lesson", "mashup", "bootleg"
    )
    private val badPhrases = listOf("sped up", "speed up")
    private val wordSplit = Regex("[^\\p{L}\\p{N}]+")

    private fun tokens(s: String): Set<String> = s.split(' ').filter { it.isNotEmpty() }.toSet()
    private fun words(s: String): Set<String> = s.lowercase().split(wordSplit).filter { it.isNotEmpty() }.toSet()

    /** Judul lagu tanpa keterangan setelah " - " (mis. "Lose Yourself - From 8 Mile"). */
    private fun coreTitle(t: String): String {
        val i = t.indexOf(" - ")
        return if (i > 0) t.substring(0, i) else t
    }

    /** Skor 0..1. Di bawah ~0.5 dianggap bukan lagu yang sama. */
    fun score(track: SpotifyTrack, c: YtCandidate): Float {
        val tTok = tokens(SpotifyMatcher.norm(coreTitle(track.title)))
        if (tTok.isEmpty()) return 0f
        val vNorm = SpotifyMatcher.norm(c.title)
        val vTok = tokens(vNorm)
        val chNorm = SpotifyMatcher.norm(c.channel)
        val chTok = tokens(chNorm)
        val chCompact = chNorm.replace(" ", "")

        val cover = tTok.count { it in vTok }.toFloat() / tTok.size
        if (cover < 0.5f) return cover * 0.5f

        val aTok = tokens(SpotifyMatcher.norm(track.artist))
        val artist = if (aTok.isEmpty()) 0.5f
        else aTok.count { it in vTok || it in chTok || (it.length >= 3 && chCompact.contains(it)) }.toFloat() / aTok.size

        val known = tTok + aTok + noise + chTok
        val extra = vTok.count { it !in known }
        val extraPenalty = (extra * 0.04f).coerceAtMost(0.2f)

        val durKnown = track.durationMs > 0 && c.durationMs > 0
        val diff = if (durKnown) kotlin.math.abs(track.durationMs - c.durationMs) else 0L
        val dur = when {
            !durKnown -> 0f
            diff <= 4_000 -> 1f
            diff <= 10_000 -> 0.7f
            diff <= 25_000 -> 0.35f
            diff <= 60_000 -> 0.1f
            else -> 0f
        }

        var s = if (durKnown) 0.50f * cover + 0.28f * artist + 0.22f * dur else 0.62f * cover + 0.38f * artist
        s -= extraPenalty
        if (durKnown && diff > 90_000) s -= 0.2f

        // lagu versi lain (cover, live, remix...) ditolak, kecuali memang itu yang ada di judul Spotify
        val vw = words(c.title)
        val tw = words(track.title)
        val lowerTitle = c.title.lowercase()
        val lowerTrack = track.title.lowercase()
        var bad = 0f
        for (w in badWords) if (w in vw && w !in tw) bad += 0.35f
        for (p in badPhrases) if (lowerTitle.contains(p) && !lowerTrack.contains(p)) bad += 0.35f
        s -= bad.coerceAtMost(0.5f)

        if (chNorm.endsWith("topic")) s += 0.06f
        if (lowerTitle.contains("official audio") || lowerTitle.contains("official video") || lowerTitle.contains("official music video")) s += 0.03f
        if (chCompact.contains("vevo")) s += 0.03f
        return s.coerceIn(0f, 1f)
    }

    fun best(track: SpotifyTrack, candidates: List<YtCandidate>, minScore: Float = 0.5f): YtCandidate? {
        var best: YtCandidate? = null
        var bestScore = 0f
        candidates.forEachIndexed { i, c ->
            val s = score(track, c) - i * 0.01f
            if (s > bestScore) { bestScore = s; best = c }
        }
        return if (bestScore >= minScore) best else null
    }
}

// ================================================================ util

/** "PT1H2M3S" -> milidetik. Format tak dikenal -> 0. */
fun parseIsoDuration(s: String): Long {
    val m = Regex("^PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?$").find(s.trim()) ?: return 0L
    val h = m.groupValues[1].toLongOrNull() ?: 0L
    val min = m.groupValues[2].toLongOrNull() ?: 0L
    val sec = m.groupValues[3].toLongOrNull() ?: 0L
    return ((h * 60 + min) * 60 + sec) * 1000L
}

/** Judul dari YouTube Data API datang dengan entitas HTML (&amp; &#39; ...). */
fun decodeHtmlEntities(s: String): String {
    var r = s.replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        .replace("&lt;", "<").replace("&gt;", ">")
    r = Regex("&#(\\d+);").replace(r) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: m.value }
    return r.replace("&amp;", "&")
}

/** Memetakan error YouTube Data API ke [YtException] dengan pesan yang bisa dipahami pengguna. */
fun classifyYtError(code: Int, reason: String, message: String): YtException {
    val r = reason.lowercase()
    val m = message.lowercase()
    return when {
        r == "quotaexceeded" || r == "dailylimitexceeded" -> YtException(
            YtException.Kind.QUOTA,
            "Kuota harian YouTube Data API habis. Setiap pencarian memakai 100 poin dari jatah 10.000/hari. " +
                "Coba lagi besok: lagu yang sudah masuk akan dilewati tanpa memakai kuota."
        )
        r == "ratelimitexceeded" || r == "userratelimitexceeded" ->
            YtException(YtException.Kind.NETWORK, "Terlalu banyak permintaan, mencoba lagi.")
        r == "keyinvalid" || r == "accessnotconfigured" || r == "ipreferrerblocked" || r == "forbidden" ||
            code == 401 || m.contains("api key") || m.contains("has not been used") || m.contains("is disabled") ->
            YtException(
                YtException.Kind.KEY,
                "Kunci API YouTube ditolak. Pastikan YouTube Data API v3 sudah diaktifkan di Google Cloud dan " +
                    "kunci tidak dibatasi ke aplikasi/IP lain."
            )
        code >= 500 -> YtException(YtException.Kind.NETWORK, "Server YouTube sedang bermasalah.")
        else -> YtException(YtException.Kind.OTHER, "YouTube menjawab dengan kode $code.")
    }
}

// ================================================================ mesin impor

/**
 * Menjalankan impor: setiap lagu dicek duplikat -> dicari di YouTube -> dipilih yang paling cocok ->
 * ditambahkan lewat [onAdd]. Dihentikan lewat pembatalan coroutine. Hitungan dan [status] dibaca
 * pemanggil sesudah [run] selesai, dibatalkan, atau melempar.
 */
class ImportEngine(
    private val tracks: List<SpotifyTrack>,
    existing: Collection<LocalAlbumTrack>,
    private val searcher: YtSearcher,
    private val sourceName: String,
    private val sourceId: String,
    private val onProgress: (ImportProgress) -> Unit,
    private val onAdd: (LocalAlbumTrack) -> Unit,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val retryDelayMs: Long = 800L,
    private val pauseMs: Long = 60L,
    private val minScore: Float = 0.5f
) {
    private val keys = HashSet<String>().apply { existing.forEach { add(it.key) } }
    private val videos = HashSet<String>().apply { existing.forEach { add(it.videoId) } }

    var done = 0; private set
    var added = 0; private set
    var duplicates = 0; private set
    var notFound = 0; private set
    var failed = 0; private set
    var status = ImportStatus.RUNNING; private set
    var message: String? = null; private set
    val notFoundList = ArrayList<String>()

    private enum class Outcome { ADDED, DUPLICATE, NOT_FOUND, FAILED, FAILED_NET }

    private fun label(t: SpotifyTrack) = if (t.artist.isBlank()) t.title else "${t.artist} - ${t.title}"

    private fun emit(current: String) = onProgress(
        ImportProgress(
            ImportPhase.SEARCHING, sourceName, tracks.size, done, added, duplicates, notFound, failed,
            current, null, null
        )
    )

    suspend fun run() {
        var consecutiveNet = 0
        try {
            emit("")
            for (t in tracks) {
                currentCoroutineContext().ensureActive()
                emit(label(t))
                val outcome = process(t)
                done++
                when (outcome) {
                    Outcome.ADDED -> { added++; consecutiveNet = 0 }
                    Outcome.DUPLICATE -> duplicates++
                    Outcome.NOT_FOUND -> {
                        notFound++; consecutiveNet = 0
                        if (notFoundList.size < 300) notFoundList.add(label(t))
                    }
                    Outcome.FAILED -> { failed++; consecutiveNet = 0 }
                    Outcome.FAILED_NET -> { failed++; consecutiveNet++ }
                }
                emit(label(t))
                if (consecutiveNet >= 4) {
                    status = ImportStatus.NETWORK_ERROR
                    message = "Koneksi ke YouTube terus gagal. Periksa internet lalu impor ulang; lagu yang sudah masuk akan dilewati."
                    return
                }
                if (outcome == Outcome.ADDED || outcome == Outcome.NOT_FOUND) delay(pauseMs)
            }
            status = ImportStatus.COMPLETED
        } catch (e: CancellationException) {
            status = ImportStatus.CANCELED
            message = "Impor dibatalkan. Lagu yang sudah masuk tetap tersimpan."
            throw e
        } catch (e: YtException) {
            status = when (e.kind) {
                YtException.Kind.QUOTA -> ImportStatus.QUOTA
                YtException.Kind.KEY -> ImportStatus.KEY_ERROR
                else -> ImportStatus.NETWORK_ERROR
            }
            message = e.message
        }
    }

    private suspend fun process(t: SpotifyTrack): Outcome {
        val ks = DupeKeys.candidates(t)
        if (ks.any { it in keys }) return Outcome.DUPLICATE

        var cands: List<YtCandidate>? = null
        var net = false
        var attempt = 0
        while (cands == null) {
            try {
                cands = searcher.search(t)
            } catch (e: CancellationException) {
                throw e
            } catch (e: YtException) {
                when (e.kind) {
                    YtException.Kind.QUOTA, YtException.Kind.KEY -> throw e
                    YtException.Kind.NETWORK -> {
                        if (attempt < 2) { attempt++; delay(retryDelayMs * attempt) } else { net = true; break }
                    }
                    YtException.Kind.OTHER -> break
                }
            } catch (e: Exception) {
                break
            }
        }
        if (cands == null) return if (net) Outcome.FAILED_NET else Outcome.FAILED

        val best = YtMatcher.best(t, cands, minScore) ?: return Outcome.NOT_FOUND
        if (best.videoId in videos) {
            keys.add(ks[0])
            return Outcome.DUPLICATE
        }
        keys.add(ks[0])
        videos.add(best.videoId)
        onAdd(
            LocalAlbumTrack(
                id = "yt_" + best.videoId, title = t.title, artist = t.artist, videoId = best.videoId,
                videoTitle = best.title, channel = best.channel, thumbUrl = best.thumbUrl,
                durationMs = best.durationMs, sourceName = sourceName, sourceId = sourceId,
                key = ks[0], addedAt = clock()
            )
        )
        return Outcome.ADDED
    }
}
