package com.base.musicapp.data

import android.content.ContentUris
import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val duration: Long,
    val dateAdded: Long,
    val uri: Uri,
    val folder: String = "",
    val genre: String = "",
    val year: Int = 0
) {
    companion object {
        fun uriFor(id: Long): Uri = ContentUris.withAppendedId(
            android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
        )
    }
}

data class Detail(val title: String, val subtitle: String, val songs: List<Song>)

enum class SortMode(val label: String) {
    TITLE("Judul"), ARTIST("Artis"), RECENT("Terbaru"), DURATION("Durasi")
}

/** Koreksi metadata yang disimpan di aplikasi (file asli tidak diubah). */
data class MetaOverride(val title: String?, val artist: String?, val album: String?)

data class CustomTheme(
    val id: String,
    val name: String,
    val accent: Int,
    val accent2: Int,
    val bgTop: Int,
    val bgBottom: Int,
    val dark: Boolean
)
