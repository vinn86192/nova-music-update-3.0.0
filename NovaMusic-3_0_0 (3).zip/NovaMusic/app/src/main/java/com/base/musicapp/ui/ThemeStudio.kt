package com.base.musicapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.CustomTheme
import com.base.musicapp.data.Palette
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.ui.theme.Nova
import com.base.musicapp.ui.theme.PreviewTheme
import com.base.musicapp.ui.theme.bestOn

private data class Preset(val name: String, val accent: Long, val accent2: Long, val top: Long, val bottom: Long, val dark: Boolean)

private val presets = listOf(
    Preset("Aurora", 0xFF4ADE80, 0xFF22D3EE, 0xFF0F3B3A, 0xFF05090F, true),
    Preset("Sakura", 0xFFFF7AA8, 0xFFFFC2D9, 0xFFFFE3EE, 0xFFFFF6FA, false),
    Preset("Matcha", 0xFF84CC16, 0xFFA3E635, 0xFF1F2A12, 0xFF0A0D06, true),
    Preset("Midnight", 0xFF6366F1, 0xFFA78BFA, 0xFF14143A, 0xFF05050F, true),
    Preset("Lemon", 0xFFFACC15, 0xFFFB923C, 0xFFFFF8D6, 0xFFFFFDF2, false)
)

private fun hsvOf(argb: Int): FloatArray {
    val h = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, h)
    return h
}

@Composable
private fun ColorEditor(argb: Int, onChange: (Int) -> Unit) {
    val c = Nova.c
    val hsv = hsvOf(argb)
    fun push(h: Float = hsv[0], s: Float = hsv[1], v: Float = hsv[2]) = onChange(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) or (0xFF shl 24))
    val colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.onBg.copy(alpha = 0.18f))
    Column {
        Text("Rona (hue)", color = c.muted, fontSize = 11.sp)
        Slider(hsv[0], { push(h = it) }, valueRange = 0f..360f, colors = colors)
        Text("Kejenuhan", color = c.muted, fontSize = 11.sp)
        Slider(hsv[1], { push(s = it) }, valueRange = 0f..1f, colors = colors)
        Text("Kecerahan", color = c.muted, fontSize = 11.sp)
        Slider(hsv[2], { push(v = it) }, valueRange = 0f..1f, colors = colors)
        Text("#%06X".format(argb and 0xFFFFFF), color = c.onBg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ThemeStudioScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val cfg by vm.cfg.state.collectAsState()
    val saved by vm.customThemes.collectAsState()
    var id by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("Tema saya") }
    var dark by remember { mutableStateOf(true) }
    var accent by remember { mutableIntStateOf(0xFF8B7CFF.toInt()) }
    var accent2 by remember { mutableIntStateOf(0xFF3DD6FF.toInt()) }
    var top by remember { mutableIntStateOf(0xFF2A1B5E.toInt()) }
    var bottom by remember { mutableIntStateOf(0xFF07070D.toInt()) }
    var target by remember { mutableIntStateOf(0) }
    val labels = listOf("Aksen", "Aksen 2", "Latar atas", "Latar bawah")
    val current = CustomTheme(id.ifEmpty { "new" }, name, accent, accent2, top, bottom, dark)

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { PageHeader("Studio tema", onBack, "Buat tema warna sendiri") }
        item {
            // pratinjau langsung memakai gaya yang sedang aktif
            PreviewTheme(cfg.copy(palette = Palette.CUSTOM), current) {
                val pc = Nova.c
                Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(pc.bgTop, pc.bgBottom))).padding(14.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth().panel().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(pc.accent, pc.accent2))))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Judul lagu", color = pc.onBg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Nama artis", color = pc.muted, fontSize = 12.sp)
                            }
                        }
                        Box(Modifier.height(36.dp).width(120.dp).panel(radius = 12.dp, fill = pc.accent), contentAlignment = Alignment.Center) {
                            Text("Putar", color = pc.onAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        item {
            Text("Mulai dari preset", color = c.muted, fontSize = 12.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { p ->
                    NovaChip(p.name, false, {
                        accent = p.accent.toInt(); accent2 = p.accent2.toInt(); top = p.top.toInt(); bottom = p.bottom.toInt(); dark = p.dark
                    })
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                NovaField(name, { name = it.take(24) }, "Nama tema", Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mode gelap", color = c.onBg, modifier = Modifier.weight(1f))
                    NovaSwitch(dark) { dark = it }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(labels.indices.toList()) { i ->
                        val col = listOf(accent, accent2, top, bottom)[i]
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { target = i }) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(Color(col)).border(if (target == i) 3.dp else 1.dp, if (target == i) c.onBg else c.onBg.copy(alpha = 0.3f), CircleShape))
                            Text(labels[i], color = if (target == i) c.onBg else c.muted, fontSize = 11.sp)
                        }
                    }
                }
                ColorEditor(listOf(accent, accent2, top, bottom)[target]) { v ->
                    when (target) { 0 -> accent = v; 1 -> accent2 = v; 2 -> top = v; else -> bottom = v }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NovaButton("Simpan & pakai", {
                        val tid = id.ifEmpty { "t" + System.currentTimeMillis() }
                        vm.saveTheme(CustomTheme(tid, name.ifBlank { "Tema saya" }, accent, accent2, top, bottom, dark))
                        vm.applyTheme(tid); id = tid
                    }, icon = Icons.Rounded.Check)
                    if (id.isNotEmpty()) NovaButton("Tema baru", { id = ""; name = "Tema saya" }, icon = Icons.Rounded.Add, kind = BtnKind.Secondary)
                }
            }
        }
        item { SectionTitle("Tema tersimpan") }
        if (saved.isEmpty()) item { EmptyNote("Belum ada tema tersimpan.") }
        items(saved, key = { it.id }) { t ->
            val active = cfg.palette == Palette.CUSTOM && cfg.themeId == t.id
            Row(Modifier.fillMaxWidth().panel(flat = true).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(t.accent), Color(t.accent2)))))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.name, color = c.onBg, fontWeight = FontWeight.SemiBold)
                    Text(if (active) "Sedang dipakai" else if (t.dark) "Gelap" else "Terang", color = if (active) c.accent else c.muted, fontSize = 11.sp)
                }
                IconButton(onClick = { vm.applyTheme(t.id) }) { Icon(Icons.Rounded.CheckCircle, "Pakai", tint = if (active) c.accent else c.muted) }
                IconButton(onClick = { id = t.id; name = t.name; accent = t.accent; accent2 = t.accent2; top = t.bgTop; bottom = t.bgBottom; dark = t.dark }) { Icon(Icons.Rounded.Edit, "Edit", tint = c.onBg) }
                IconButton(onClick = { vm.deleteTheme(t.id) }) { Icon(Icons.Rounded.Delete, "Hapus", tint = c.muted) }
            }
        }
    }
}
