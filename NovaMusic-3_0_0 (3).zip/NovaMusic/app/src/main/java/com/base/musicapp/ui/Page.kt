package com.base.musicapp.ui

/** Halaman tambahan yang dibuka dari Beranda / Setting (di atas tab aktif). */
enum class Page {
    SPOTIFY, ALBUM_IMPORT, ALBUM, STATS, SMART, MOODS, GENERATOR, DUPES, META, FOLDERS, TIMELINE, FAVARTISTS, THEMES, ABOUT
}
