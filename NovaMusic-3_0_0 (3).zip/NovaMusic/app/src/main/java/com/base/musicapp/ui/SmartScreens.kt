package com.base.musicapp.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.data.*
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.player.fmt
import com.base.musicapp.ui.theme.Nova
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun SongActions(vm: MusicViewModel, list: List<Song>, saveName: String) {
    val ctx = LocalContext.current
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
        item { NovaButton("Putar", { vm.playSongs(list, 0) }, icon = Icons.Rounded.PlayArrow, enabled = list.isNotEmpty()) }
        item { NovaButton("Acak", { vm.shuffleAll(list) }, icon = Icons.Rounded.Shuffle, kind = BtnKind.Secondary, enabled = list.isNotEmpty()) }
        item {
            NovaButton("Simpan playlist", {
                val n = vm.createPlaylistWith(saveName, list)
                Toast.makeText(ctx, "Playlist \"$n\" dibuat (${list.size} lagu)", Toast.LENGTH_SHORT).show()
            }, icon = Icons.Rounded.PlaylistAdd, kind = BtnKind.Secondary, enabled = list.isNotEmpty())
        }
    }
}

// ================================================================ HUB
@Composable
fun SmartHubScreen(vm: MusicViewModel, onBack: () -> Unit, open: (Page) -> Unit) {
    val songs by vm.songs.collectAsState()
    val entries = listOf(
        Triple(Page.GENERATOR, Icons.Rounded.AutoAwesome, "Generator playlist" to "Ketik permintaan, misalnya \"santai 45 menit\""),
        Triple(Page.MOODS, Icons.Rounded.Mood, "Playlist berdasarkan mood" to "Santai, semangat, galau, fokus, pesta, romantis"),
        Triple(Page.TIMELINE, Icons.Rounded.Timeline, "Timeline baru ditambahkan" to "Lagu dikelompokkan menurut tanggal masuk"),
        Triple(Page.FAVARTISTS, Icons.Rounded.Star, "Artis favorit" to "Tandai artis dan lihat yang paling sering kamu putar"),
        Triple(Page.DUPES, Icons.Rounded.ContentCopy, "Pendeteksi duplikat" to "Temukan lagu ganda lalu sembunyikan atau hapus"),
        Triple(Page.META, Icons.Rounded.Build, "Perbaiki metadata" to "Rapikan judul dan artis yang berantakan"),
        Triple(Page.FOLDERS, Icons.Rounded.FolderOpen, "Folder pemindaian" to "Pilih folder yang dipakai atau diabaikan")
    )
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PageHeader("Library pintar", onBack, "${songs.size} lagu") }
        items(entries) { (page, icon, text) ->
            val c = Nova.c
            Row(Modifier.fillMaxWidth().panel(onClick = { open(page) }).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = c.accent, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(text.first, color = c.onBg, fontWeight = FontWeight.Bold)
                    Text(text.second, color = c.muted, fontSize = 12.sp)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = c.muted)
            }
        }
    }
}

// ================================================================ MOOD
@Composable
fun MoodScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    val groups by produceState<Map<Mood, List<Song>>>(emptyMap(), songs) { value = withContext(Dispatchers.Default) { Smart.byMood(songs) } }
    var sel by remember { mutableStateOf(Mood.CHILL) }
    val list = groups[sel].orEmpty()
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { PageHeader("Playlist mood", onBack, "Dikelompokkan otomatis") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Mood.values().toList()) { m -> NovaChip("${m.label} (${groups[m]?.size ?: 0})", sel == m, { sel = m }) }
            }
        }
        item { Text("${sel.label}: ${sel.hint}. Mood diperkirakan dari genre tag, kata di judul/artis/album, dan durasi (bukan analisis suara), jadi hasilnya bisa meleset.", color = c.muted, fontSize = 12.sp) }
        item { SongActions(vm, list, "Mood ${sel.label}") }
        if (list.isEmpty()) item { EmptyNote("Belum ada lagu yang terdeteksi untuk mood ini.") }
        items(list.take(150), key = { it.id }) { s -> SongRow(vm, s) { vm.playSongs(list, list.indexOf(s)) } }
    }
}

// ================================================================ GENERATOR
@Composable
fun GeneratorScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    val favs by vm.favorites.collectAsState()
    val recents by vm.recents.collectAsState()
    var prompt by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<GenResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun run(text: String) {
        prompt = text
        busy = true
        scope.launch {
            val counts = vm.playCountsNow()
            result = withContext(Dispatchers.Default) { Smart.generate(text, songs, favs, counts, recents.map { it.id }) }
            busy = false
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PageHeader("Generator playlist", onBack, "Dibuat di perangkat, tanpa AI online") }
        item {
            Column(Modifier.fillMaxWidth().panel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Tulis permintaanmu. Bisa memuat mood, nama artis, durasi (\"45 menit\"), jumlah (\"20 lagu\"), atau kata seperti favorit, terbaru, jarang diputar.", color = c.muted, fontSize = 12.sp)
                NovaField(prompt, { prompt = it }, "contoh: santai malam 1 jam", Modifier.fillMaxWidth(), Icons.Rounded.AutoAwesome)
                NovaButton(if (busy) "Membuat…" else "Buat playlist", { run(prompt) }, Modifier.fillMaxWidth(), Icons.Rounded.AutoAwesome, enabled = !busy && songs.isNotEmpty())
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("semangat olahraga 30 menit", "santai 45 menit", "fokus belajar 1 jam", "paling sering diputar", "lagu jarang diputar", "terbaru ditambahkan", "favorit 20 lagu")) { t ->
                        NovaChip(t, false, { run(t) })
                    }
                }
            }
        }
        result?.let { r ->
            item { Text(r.title, color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            item { Text(r.note, color = c.muted, fontSize = 12.sp) }
            item { SongActions(vm, r.songs, r.title) }
            items(r.songs, key = { it.id }) { s -> SongRow(vm, s) { vm.playSongs(r.songs, r.songs.indexOf(s)) } }
        }
    }
}

// ================================================================ TIMELINE
@Composable
fun TimelineScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    val groups = remember(songs) {
        val now = System.currentTimeMillis()
        val today = PlayStats.dayStart(now)
        val monthFmt = SimpleDateFormat("MMMM yyyy", Locale("id"))
        songs.sortedByDescending { it.dateAdded }.groupBy { s ->
            val t = s.dateAdded * 1000L
            when {
                t >= today -> "Hari ini"
                t >= today - 86_400_000L -> "Kemarin"
                t >= today - 6 * 86_400_000L -> "Minggu ini"
                t >= today - 29 * 86_400_000L -> "30 hari terakhir"
                else -> monthFmt.format(Date(t)).replaceFirstChar { it.uppercase() }
            }
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { PageHeader("Baru ditambahkan", onBack, "Timeline library") }
        groups.forEach { (label, list) ->
            item(key = "h_$label") {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = c.onBg, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("${list.size} lagu", color = c.muted, fontSize = 12.sp)
                }
            }
            items(list.take(30), key = { "t_${it.id}" }) { s -> SongRow(vm, s) { vm.playSongs(list, list.indexOf(s)) } }
        }
    }
}

// ================================================================ ARTIS FAVORIT
@Composable
fun FavArtistsScreen(vm: MusicViewModel, onBack: () -> Unit, onDetail: (Detail) -> Unit) {
    val c = Nova.c
    val songs by vm.songs.collectAsState()
    val favs by vm.favoriteArtists.collectAsState()
    val top by produceState<List<RankItem>>(emptyList()) { value = vm.computeStats(0).topArtists }
    val byArtist = remember(songs) { songs.groupBy { it.artist } }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { PageHeader("Artis favorit", onBack) }
        item { SectionTitle("Favoritmu") }
        if (favs.isEmpty()) item { EmptyNote("Belum ada. Ketuk bintang di daftar di bawah, atau di Library → Artis.") }
        items(favs.toList().sorted()) { name ->
            ArtistLine(name, byArtist[name]?.size ?: 0, true, { vm.toggleFavoriteArtist(name) }) {
                byArtist[name]?.let { onDetail(Detail(name, "${it.size} lagu", it)) }
            }
        }
        val suggest = top.filter { it.name !in favs && !it.name.startsWith("Artis tidak") }
        if (suggest.isNotEmpty()) {
            item { SectionTitle("Paling sering kamu putar") }
            items(suggest) { r ->
                ArtistLine(r.name, byArtist[r.name]?.size ?: 0, false, { vm.toggleFavoriteArtist(r.name) }) {
                    byArtist[r.name]?.let { onDetail(Detail(r.name, "${it.size} lagu", it)) }
                }
            }
        }
    }
}

@Composable
fun ArtistLine(name: String, count: Int, fav: Boolean, onStar: () -> Unit, onOpen: () -> Unit) {
    val c = Nova.c
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onOpen).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(start = 6.dp)) {
            Text(name, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$count lagu", color = c.muted, fontSize = 12.sp)
        }
        IconButton(onClick = onStar) { Icon(if (fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, "Favorit", tint = if (fav) c.accent else c.muted) }
    }
}

// ================================================================ DUPLIKAT
@Composable
fun DuplicatesScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsState()
    val groups by produceState<List<List<Song>>?>(null, songs) { value = withContext(Dispatchers.Default) { Smart.duplicates(songs) } }
    var confirmDelete by remember { mutableStateOf<List<Long>?>(null) }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { vm.load(true) }
    val g = groups
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { PageHeader("Duplikat", onBack, "Judul + artis sama, durasi hampir sama") }
        if (g == null) { item { Text("Memindai…", color = c.muted) }; return@LazyColumn }
        if (g.isEmpty()) item { EmptyNote("Tidak ada duplikat ditemukan.") }
        else {
            item {
                val extras = g.flatMap { it.drop(1) }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${g.size} grup, ${extras.size} salinan berlebih.", color = c.muted, fontSize = 13.sp)
                    NovaButton("Sembunyikan semua salinan", { vm.hideSongs(extras.map { it.id }); Toast.makeText(ctx, "${extras.size} lagu disembunyikan", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth(), Icons.Rounded.VisibilityOff)
                    NovaButton("Hapus file salinan…", { confirmDelete = extras.map { it.id } }, Modifier.fillMaxWidth(), Icons.Rounded.Delete, BtnKind.Secondary)
                    Text("Menyembunyikan tidak menghapus file; bisa dibatalkan lewat Setting → Library. Salinan pertama di tiap grup dipertahankan.", color = c.muted, fontSize = 11.sp)
                }
            }
            items(g) { grp ->
                Column(Modifier.fillMaxWidth().panel().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    grp.forEachIndexed { i, s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.title, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                Text("${s.artist} • ${fmt(s.duration)} • ${s.folder.substringAfterLast('/').ifEmpty { "?" }}", color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(if (i == 0) "Simpan" else "Salinan", color = if (i == 0) c.accent else c.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            if (i > 0) IconButton(onClick = { vm.hideSongs(listOf(s.id)) }, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.VisibilityOff, "Sembunyikan", tint = c.muted) }
                        }
                    }
                }
            }
        }
    }
    confirmDelete?.let { ids ->
        NovaDialog("Hapus ${ids.size} file?", { confirmDelete = null }, "Hapus", {
            val sender = vm.deleteRequest(ids)
            if (sender != null) deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
            else Toast.makeText(ctx, "Hapus file langsung butuh Android 11+. Gunakan Sembunyikan.", Toast.LENGTH_LONG).show()
            confirmDelete = null
        }) { Text("File akan dihapus permanen dari perangkat setelah kamu mengonfirmasi di dialog sistem.", color = c.onBg) }
    }
}

// ================================================================ METADATA
@Composable
fun MetadataScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val songs by vm.songs.collectAsState()
    var version by remember { mutableIntStateOf(0) }
    val sugg by produceState<List<MetaSuggestion>?>(null, songs, version) {
        value = withContext(Dispatchers.Default) { Smart.suggestions(songs, emptyMap()).filter { s -> s.newTitle != s.song.title || s.newArtist != null } }
    }
    val chosen = remember { mutableStateMapOf<Long, Boolean>() }
    val list = sugg
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { PageHeader("Perbaiki metadata", onBack, "Disimpan di NovaMusic, file asli tidak diubah") }
        if (list == null) { item { Text("Menganalisis…", color = c.muted) }; return@LazyColumn }
        if (list.isEmpty()) item { EmptyNote("Metadata terlihat rapi. Tidak ada saran perbaikan.") }
        else {
            item {
                val picked = list.filter { chosen[it.song.id] != false }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${list.size} saran. Hapus centang yang tidak mau diterapkan.", color = c.muted, fontSize = 13.sp)
                    NovaButton("Terapkan ${picked.size} perbaikan", {
                        vm.applySuggestions(picked); version++
                        Toast.makeText(ctx, "${picked.size} lagu diperbaiki", Toast.LENGTH_SHORT).show()
                    }, Modifier.fillMaxWidth(), Icons.Rounded.Build, enabled = picked.isNotEmpty())
                }
            }
            items(list.take(300), key = { it.song.id }) { sg ->
                val on = chosen[sg.song.id] != false
                Row(Modifier.fillMaxWidth().panel(flat = true).clickable { chosen[sg.song.id] = !on }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (on) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank, null, tint = if (on) c.accent else c.muted)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(sg.song.title, color = c.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(sg.newTitle + (sg.newArtist?.let { "  •  $it" } ?: ""), color = c.onBg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(sg.reason, color = c.accent, fontSize = 11.sp)
                    }
                }
            }
        }
        item { NovaButton("Batalkan semua koreksi", { vm.resetMeta(); version++ }, Modifier.fillMaxWidth(), Icons.Rounded.RestartAlt, BtnKind.Secondary) }
    }
}

// ================================================================ FOLDER
@Composable
fun FoldersScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val folders by vm.folders.collectAsState()
    val excluded by vm.excludedFolders.collectAsState()
    val hidden by vm.hiddenIds.collectAsState()
    val loading by vm.loading.collectAsState()
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { PageHeader("Folder pemindaian", onBack, "${folders.size} folder berisi musik") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Matikan folder yang tidak ingin muncul (misalnya rekaman suara atau nada dering). Library juga otomatis diperbarui saat ada file baru.", color = c.muted, fontSize = 12.sp)
                NovaButton(if (loading) "Memindai…" else "Pindai ulang sekarang", { vm.load(true) }, Modifier.fillMaxWidth(), Icons.Rounded.Refresh, BtnKind.Secondary, enabled = !loading)
                if (hidden.isNotEmpty()) NovaButton("Tampilkan kembali ${hidden.size} lagu tersembunyi", { vm.unhideAll() }, Modifier.fillMaxWidth(), Icons.Rounded.Visibility, BtnKind.Secondary)
            }
        }
        items(folders.entries.sortedBy { it.key }.toList(), key = { it.key }) { (path, n) ->
            val on = path !in excluded
            Row(Modifier.fillMaxWidth().panel(flat = true).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(path.substringAfterLast('/').ifEmpty { path }, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$n lagu • ${path.removePrefix("/storage/emulated/0/")}", color = c.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                NovaSwitch(on) { vm.toggleFolder(path) }
            }
        }
    }
}
