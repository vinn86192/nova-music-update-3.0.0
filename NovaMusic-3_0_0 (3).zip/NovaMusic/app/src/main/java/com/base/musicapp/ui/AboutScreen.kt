package com.base.musicapp.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.ui.theme.Nova
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * About minimalis. Foto profil: pakai file res/drawable-nodpi/profile_rkaa.(png|jpg) bila ada di project;
 * jika belum ada, ketuk lingkaran untuk memilih foto (disimpan di perangkat).
 */
@Composable
fun AboutScreen(vm: MusicViewModel, onBack: () -> Unit) {
    val c = Nova.c
    val ctx = LocalContext.current
    val ver by vm.profileVersion.collectAsState()
    val bundled = remember { ctx.resources.getIdentifier("profile_rkaa", "drawable", ctx.packageName) }
    val picked by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, ver) {
        value = withContext(Dispatchers.IO) {
            runCatching { vm.profileFile().takeIf { it.isFile }?.let { android.graphics.BitmapFactory.decodeFile(it.absolutePath)?.asImageBitmap() } }.getOrNull()
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setProfilePhoto(uri) { }
    }

    Box(Modifier.fillMaxSize()) {
        IconButton(onClick = onBack, modifier = Modifier.padding(8.dp)) { Icon(Icons.Rounded.ArrowBack, "Kembali", tint = c.onBg) }
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier.size(132.dp).clip(CircleShape)
                    .border(3.dp, Brush.linearGradient(listOf(c.accent, c.accent2)), CircleShape)
                    .padding(6.dp).clip(CircleShape).background(c.onBg.copy(alpha = 0.08f))
                    .then(if (bundled == 0) Modifier.clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) } else Modifier),
                contentAlignment = Alignment.Center
            ) {
                val img = picked
                when {
                    bundled != 0 -> Image(painterResource(bundled), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    img != null -> Image(img, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    else -> Text("r", color = c.onBg, fontSize = 52.sp, fontWeight = FontWeight.Light)
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("rkaa", color = c.onBg, fontSize = 30.sp, fontWeight = if (Nova.look.neo) FontWeight.Black else FontWeight.SemiBold, letterSpacing = 1.sp)
            Text("Creator", color = c.muted, fontSize = 13.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(36.dp))
            Box(Modifier.width(40.dp).height(2.dp).background(c.accent))
            Spacer(Modifier.height(36.dp))
            Image(painterResource(com.base.musicapp.R.drawable.nova_logo), null, modifier = Modifier.size(72.dp))
            Spacer(Modifier.height(10.dp))
            Text("NovaMusic", color = c.onBg, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            Text("Galaxy Evolution", color = c.accent, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("Versi ${vm.appVersion()}", color = c.muted, fontSize = 12.sp)
            if (bundled == 0 && picked == null) {
                Spacer(Modifier.height(28.dp))
                Text("Ketuk lingkaran untuk memasang foto profil", color = c.muted, fontSize = 11.sp)
            }
        }
    }
}
