package com.base.musicapp.data

import java.text.Normalizer
import kotlin.math.abs

/** Mencocokkan daftar lagu Spotify dengan lagu di perangkat (judul, artis, durasi). */
object SpotifyMatcher {
    private class Cand(
        val song: Song,
        val title: String,
        val tTokens: Set<String>,
        val aTokens: Set<String>,
        val unknownArtist: Boolean
    )

    private val diacritics = Regex("\\p{M}+")
    private val parens = Regex("""\s*[(\[{][^)\]}]*[)\]}]""")
    private val dashSuffix = Regex(
        """\s+-\s+(remaster(ed)?|live|remix|radio edit|single version|album version|mono|stereo|deluxe|bonus|acoustic|version|\d{4}).*$"""
    )
    private val feat = Regex("""\b(feat|ft|featuring)\.?\s.*$""")
    private val nonWord = Regex("""[^\p{L}\p{N}\s]""")
    private val spaces = Regex("\\s+")

    fun norm(s: String): String {
        val base = Normalizer.normalize(s, Normalizer.Form.NFD).replace(diacritics, "").lowercase()
        var t = parens.replace(base, " ")
        t = dashSuffix.replace(t, "")
        t = feat.replace(t, "")
        t = nonWord.replace(t, " ").trim().replace(spaces, " ")
        if (t.isNotEmpty()) return t
        return nonWord.replace(base, " ").trim().replace(spaces, " ")
    }

    private fun tokens(s: String): Set<String> = s.split(' ').filter { it.isNotEmpty() }.toSet()

    /** level: 0 longgar, 1 sedang, 2 ketat. */
    fun match(tracks: List<SpotifyTrack>, songs: List<Song>, level: Int): List<MatchResult> {
        val cands = songs.map { s ->
            val t = norm(s.title)
            Cand(s, t, tokens(t), tokens(norm(s.artist)), s.artist.startsWith("Artis tidak"))
        }
        val (minTitle, minScore) = when (level) {
            0 -> 0.55f to 0.55f
            2 -> 0.90f to 0.80f
            else -> 0.70f to 0.68f
        }
        return tracks.map { MatchResult(it, best(it, cands, minTitle, minScore)) }
    }

    private fun best(t: SpotifyTrack, cands: List<Cand>, minTitle: Float, minScore: Float): Song? {
        val variants =
            if (t.swappable && t.artist.isNotBlank()) listOf(t.title to t.artist, t.artist to t.title)
            else listOf(t.title to t.artist)
        var bestSong: Song? = null
        var bestScore = 0f
        for ((title, artist) in variants) {
            val tn = norm(title)
            if (tn.isEmpty()) continue
            val tt = tokens(tn)
            val an = norm(artist)
            val at = tokens(an)
            for (c in cands) {
                if (c.title.isEmpty()) continue
                if (tt.none { it in c.tTokens } && !(c.title.contains(tn) || tn.contains(c.title))) continue
                val ts = similarity(tn, c.title, tt, c.tTokens)
                if (ts < minTitle) continue
                val score = 0.62f * ts + 0.28f * artistSim(an, at, c) + 0.10f * durSim(t.durationMs, c.song.duration)
                if (score > bestScore) { bestScore = score; bestSong = c.song }
            }
        }
        return if (bestScore >= minScore) bestSong else null
    }

    private fun similarity(a: String, b: String, ta: Set<String>, tb: Set<String>): Float {
        if (a == b) return 1f
        val union = (ta + tb).size
        val jac = if (union == 0) 0f else ta.count { it in tb }.toFloat() / union
        val short = if (a.length < b.length) a else b
        val long = if (a.length < b.length) b else a
        val contain = if (short.length >= 5 && long.contains(short)) 0.55f + 0.45f * short.length / long.length else 0f
        return maxOf(jac, contain)
    }

    private fun artistSim(an: String, at: Set<String>, c: Cand): Float {
        if (an.isEmpty() || c.unknownArtist) return 0.5f
        if (c.title.contains(an)) return 0.85f
        val denom = minOf(at.size, c.aTokens.size)
        if (denom == 0) return 0.5f
        return at.count { it in c.aTokens }.toFloat() / denom
    }

    private fun durSim(a: Long, b: Long): Float {
        if (a <= 0 || b <= 0) return 0.5f
        val d = abs(a - b)
        return when {
            d <= 3_000 -> 1f
            d <= 8_000 -> 0.6f
            d <= 15_000 -> 0.3f
            else -> 0f
        }
    }
}
