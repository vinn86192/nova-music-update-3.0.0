package com.base.musicapp.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Pencarian lewat YouTube Data API v3 (resmi, butuh kunci API milik pengguna).
 * Biaya kuota: search.list = 100 poin, videos.list = 1 poin. Jatah bawaan 10.000 poin/hari,
 * jadi sekitar 99 lagu per hari.
 */
class YouTubeApi(private val key: String) : YtSearcher {

    override suspend fun search(track: SpotifyTrack): List<YtCandidate> = withContext(Dispatchers.IO) {
        val q = if (track.artist.isBlank()) track.title else "${track.artist} ${track.title}"
        val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10" +
            "&maxResults=5&q=${enc(q)}&key=${enc(key)}"
        val items = get(url).optJSONArray("items") ?: return@withContext emptyList()
        val out = ArrayList<YtCandidate>()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val vid = o.optJSONObject("id")?.optString("videoId").orEmpty()
            val sn = o.optJSONObject("snippet") ?: continue
            if (vid.isEmpty()) continue
            val thumbs = sn.optJSONObject("thumbnails")
            val thumb = thumbs?.optJSONObject("medium")?.optString("url")
                ?: thumbs?.optJSONObject("high")?.optString("url")
                ?: thumbs?.optJSONObject("default")?.optString("url")
                ?: "https://i.ytimg.com/vi/$vid/mqdefault.jpg"
            out.add(
                YtCandidate(
                    vid, decodeHtmlEntities(sn.optString("title")), decodeHtmlEntities(sn.optString("channelTitle")),
                    thumb, 0L
                )
            )
        }
        // Durasi hanya dibutuhkan bila durasi lagu Spotify diketahui (1 poin kuota per 50 video).
        if (out.isNotEmpty() && track.durationMs > 0) {
            val durations = try {
                durationsFor(out.map { it.videoId })
            } catch (e: YtException) {
                if (e.kind == YtException.Kind.QUOTA || e.kind == YtException.Kind.KEY) throw e
                emptyMap()
            }
            return@withContext out.map { c -> c.copy(durationMs = durations[c.videoId] ?: 0L) }
        }
        out
    }

    private fun durationsFor(ids: List<String>): Map<String, Long> {
        val url = "https://www.googleapis.com/youtube/v3/videos?part=contentDetails" +
            "&id=${enc(ids.joinToString(","))}&key=${enc(key)}"
        val items = get(url).optJSONArray("items") ?: return emptyMap()
        val m = HashMap<String, Long>()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val d = o.optJSONObject("contentDetails")?.optString("duration").orEmpty()
            m[o.optString("id")] = parseIsoDuration(d)
        }
        return m
    }

    /** Memeriksa kunci dengan permintaan termurah (videos.list = 1 poin). null = kunci valid. */
    suspend fun validate(): YtException? = withContext(Dispatchers.IO) {
        try {
            get("https://www.googleapis.com/youtube/v3/videos?part=id&id=dQw4w9WgXcQ&key=${enc(key)}")
            null
        } catch (e: YtException) {
            e
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code in 200..299) return JSONObject(body)
            var reason = ""
            var msg = ""
            try {
                val e = JSONObject(body).getJSONObject("error")
                msg = e.optString("message")
                reason = e.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
            } catch (e: Exception) { /* badan error tak terbaca: pakai kode HTTP saja */ }
            throw classifyYtError(code, reason, msg)
        } catch (e: YtException) {
            throw e
        } catch (e: IOException) {
            throw YtException(YtException.Kind.NETWORK, "Tidak bisa terhubung ke YouTube. Periksa koneksi internet.")
        } catch (e: Exception) {
            throw YtException(YtException.Kind.OTHER, "Jawaban YouTube tidak bisa dibaca.")
        } finally {
            c.disconnect()
        }
    }
}

/** Memuat thumbnail dari URL dengan cache memori kecil. */
object ThumbLoader {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun peek(url: String): Bitmap? = cache.get(url)

    suspend fun load(url: String): Bitmap? {
        if (url.isBlank()) return null
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8_000
                c.readTimeout = 10_000
                try {
                    if (c.responseCode !in 200..299) return@withContext null
                    val bytes = c.inputStream.use { it.readBytes() }
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var sample = 1
                    while (maxOf(o.outWidth, o.outHeight) / sample > 480) sample *= 2
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                    if (bmp != null) cache.put(url, bmp)
                    bmp
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}
