package com.base.musicapp.ui

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.base.musicapp.ui.theme.*
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Navigasi bawah "Liquid Glass": kapsul melayang dengan sudut membulat, permukaan kaca tembus pandang
 * (terang/gelap mengikuti tema), indikator aktif yang meluncur dengan pegas dan sedikit memanjang saat
 * bergerak, serta bisa digeser dengan jari. Perpindahan tab baru dipicu saat jari dilepas.
 * Gaya Neobrutalism memakai permukaan solid bergaris tebal tetapi fitur geser/animasinya sama.
 */
@Composable
fun NovaNavBar(items: List<NavItem>, selected: Int, onSelect: (Int) -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val density = LocalDensity.current
    val n = items.size.coerceAtLeast(1)
    val sel = selected.coerceIn(0, n - 1)
    val currentSel by rememberUpdatedState(sel)
    val currentOnSelect by rememberUpdatedState(onSelect)

    var innerW by remember { mutableFloatStateOf(0f) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val target = drag ?: sel.toFloat()
    val pos by animateFloatAsState(
        targetValue = target,
        animationSpec = if (drag != null) spring(dampingRatio = 1f, stiffness = Spring.StiffnessHigh)
        else spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "navPos"
    )
    val hot = pos.roundToInt().coerceIn(0, n - 1)
    val stretch = 1f + (abs(pos - target)).coerceAtMost(1f) * 0.28f

    val neo = look.neo
    val radius = if (neo) look.radius + 6.dp else 30.dp
    val shape = RoundedCornerShape(radius)
    val itemShape = RoundedCornerShape(if (neo) look.radius else 24.dp)

    val glassFill = if (c.dark)
        Brush.verticalGradient(listOf(c.surfaceSolid.copy(alpha = 0.62f), c.surfaceSolid.copy(alpha = 0.42f)))
    else
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.78f), Color.White.copy(alpha = 0.55f)))
    val glassEdge = if (c.dark)
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.06f)))
    else
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.95f), Color.Black.copy(alpha = 0.07f)))

    val container: Modifier =
        if (neo) Modifier.padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth()
            .panel(radius = radius, fill = c.surfaceSolid)
        else Modifier.padding(horizontal = 16.dp, vertical = 10.dp).fillMaxWidth()
            .shadow(
                elevation = 18.dp, shape = shape, clip = false,
                ambientColor = Color.Black.copy(alpha = if (c.dark) 0.55f else 0.18f),
                spotColor = c.accent.copy(alpha = if (c.dark) 0.35f else 0.25f)
            )
            .clip(shape)
            .background(glassFill)
            .border(1.dp, glassEdge, shape)

    Box(container.padding(6.dp)) {
        Box(
            Modifier.fillMaxWidth()
                .onSizeChanged { innerW = it.width.toFloat() }
                .pointerInput(n) {
                    detectHorizontalDragGestures(
                        onDragStart = { o ->
                            drag = (o.x / (size.width.toFloat() / n) - 0.5f).coerceIn(0f, (n - 1).toFloat())
                        },
                        onDragEnd = {
                            val t = drag?.roundToInt()
                            drag = null
                            if (t != null && t != currentSel) currentOnSelect(t)
                        },
                        onDragCancel = { drag = null },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            val itemPx = size.width.toFloat() / n
                            drag = ((drag ?: currentSel.toFloat()) + amount / itemPx).coerceIn(0f, (n - 1).toFloat())
                        }
                    )
                }
        ) {
            val itemW = if (innerW > 0f) innerW / n else 0f
            if (itemW > 0f) {
                val itemWdp = with(density) { itemW.toDp() }
                // cahaya lembut di belakang indikator (blur nyata hanya di Android 12+)
                if (!neo && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Box(
                        Modifier.offset { IntOffset((pos * itemW).roundToInt(), 0) }
                            .width(itemWdp).height(54.dp)
                            .graphicsLayer { scaleX = stretch }
                            .blur(16.dp)
                            .background(c.accent.copy(alpha = if (c.dark) 0.42f else 0.30f), itemShape)
                    )
                }
                Box(
                    Modifier.offset { IntOffset((pos * itemW).roundToInt(), 0) }
                        .width(itemWdp).height(54.dp)
                        .graphicsLayer { scaleX = stretch }
                        .then(
                            if (neo) Modifier.panel(radius = look.radius, fill = c.accent, flat = true)
                            else Modifier
                                .clip(itemShape)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(c.accent.copy(alpha = if (c.dark) 0.34f else 0.26f), c.accent.copy(alpha = if (c.dark) 0.16f else 0.12f))
                                    )
                                )
                                .border(
                                    1.dp,
                                    Brush.verticalGradient(listOf(Color.White.copy(alpha = if (c.dark) 0.45f else 0.9f), c.accent.copy(alpha = 0.25f))),
                                    itemShape
                                )
                        )
                )
            }
            Row(Modifier.fillMaxWidth()) {
                items.forEachIndexed { i, item ->
                    val active = i == hot
                    val fg by animateColorAsState(
                        if (active) (if (neo) c.onAccent else c.accent) else c.muted, label = "navFg"
                    )
                    val iconScale by animateFloatAsState(
                        if (active) 1.14f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "navIcon"
                    )
                    Column(
                        Modifier.weight(1f).height(54.dp)
                            .clip(itemShape)
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(item.icon, item.label, tint = fg, modifier = Modifier.size(22.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
                        Text(
                            item.label, color = fg, fontSize = 10.5.sp, maxLines = 1,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
