package com.base.musicapp.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.view.LayoutInflater
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.base.musicapp.R
import com.base.musicapp.data.ArtLoader
import com.base.musicapp.data.BgType
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size as GSize
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.base.musicapp.data.ArtShape
import com.base.musicapp.data.Song
import com.base.musicapp.player.MusicViewModel
import com.base.musicapp.player.fmt
import com.base.musicapp.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// =============================================================== PERMUKAAN (glass / neo)

/**
 * Permukaan utama aplikasi. Mengikuti gaya aktif:
 * - Glassmorphism: isi kaca tembus pandang + garis tepi gradien.
 * - Neobrutalism: isi solid, border tebal, hard shadow; saat ditekan panel "masuk" ke bayangannya.
 * [flat] = tanpa bayangan (neo) / tanpa kaca (glass) kecuali [fill] diberikan.
 */
@Composable
fun Modifier.panel(
    radius: Dp? = null,
    fill: Color? = null,
    brush: Brush? = null,
    flat: Boolean = false,
    onClick: (() -> Unit)? = null
): Modifier {
    val c = Nova.c
    val look = Nova.look
    val r = radius ?: look.radius
    val shape = RoundedCornerShape(r)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val indication = if (look.neo) null else LocalIndication.current
    val click: Modifier = if (onClick == null) Modifier
    else Modifier.clickable(interactionSource = source, indication = indication, onClick = onClick)

    if (look.neo) {
        val off = if (flat) 0.dp else look.shadow
        val bw = if (flat && look.border > 2.dp) 2.dp else look.border
        val press by animateDpAsState(
            if (pressed && onClick != null && off > 0.dp) off else 0.dp, label = "press"
        )
        val bg: Brush = brush ?: SolidColor(fill ?: c.surfaceSolid)
        return this
            .padding(end = off, bottom = off)
            .drawBehind {
                if (off > 0.dp) {
                    drawRoundRect(c.shadow, Offset(off.toPx(), off.toPx()), size, CornerRadius(r.toPx()))
                }
            }
            .offset { IntOffset(press.roundToPx(), press.roundToPx()) }
            .clip(shape)
            .background(bg)
            .border(bw, c.border, shape)
            .then(click)
    }

    val a = look.glassAlpha
    val bg: Brush = brush ?: when {
        fill != null -> SolidColor(fill)
        flat -> SolidColor(Color.Transparent)
        c.dark -> Brush.verticalGradient(listOf(Color.White.copy(alpha = (a * 1.5f).coerceAtMost(1f)), Color.White.copy(alpha = a * 0.7f)))
        else -> Brush.verticalGradient(listOf(Color.White.copy(alpha = (a * 5f).coerceAtMost(0.9f)), Color.White.copy(alpha = (a * 3.5f).coerceAtMost(0.7f))))
    }
    val showStroke = !(flat && fill == null && brush == null)
    val stroke = Brush.linearGradient(
        listOf(Color.White.copy(alpha = if (c.dark) 0.35f else 0.9f), Color.White.copy(alpha = if (c.dark) 0.05f else 0.3f))
    )
    return this
        .clip(shape)
        .background(bg)
        .then(if (showStroke) Modifier.border(1.dp, stroke, shape) else Modifier)
        .then(click)
}

private fun DrawScope.orb(cx: Float, cy: Float, r: Float, col: Color) {
    drawCircle(
        brush = Brush.radialGradient(listOf(col, Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r, center = Offset(cx, cy)
    )
}

/** Konfigurasi latar kustom (foto / video / album) + parallax. Diisi dari AppActivity. */
data class AppBg(
    val type: BgType = BgType.NONE,
    val photoPath: String = "",
    val videoPath: String = "",
    val blur: Int = 0,
    val dark: Int = 35,
    val videoVolume: Int = 0,
    val parallax: Boolean = false,
    val strength: Int = 50,
    val album: Bitmap? = null
)

val LocalAppBg = staticCompositionLocalOf { AppBg() }

@Composable
fun rememberTilt(enabled: Boolean): State<Offset> {
    val ctx = LocalContext.current
    val st = remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(enabled) {
        if (!enabled) { st.value = Offset.Zero; return@DisposableEffect onDispose { } }
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var fx = 0f
        var fy = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                fx += (-e.values[0] / 9.81f - fx) * 0.08f
                fy += (e.values[1] / 9.81f - fy) * 0.08f
                st.value = Offset(fx.coerceIn(-1f, 1f), fy.coerceIn(-1f, 1f))
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }
    return st
}

/** Decode foto dengan batas ukuran; blur = perkecil lalu diperbesar lagi (bekerja di semua versi Android). */
private fun decodeBackground(path: String, blur: Int): Bitmap? = runCatching {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var sample = 1
    while (maxOf(o.outWidth, o.outHeight) / sample > 1400) sample *= 2
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return@runCatching null
    shrinkForBlur(bmp, blur)
}.getOrNull()

private fun shrinkForBlur(bmp: Bitmap, blur: Int): Bitmap {
    if (blur <= 0) return bmp
    val f = 1f - Math.pow((blur / 100.0), 0.6).toFloat() * 0.97f
    val w = maxOf(8, (bmp.width * f).toInt())
    val h = maxOf(8, (bmp.height * f).toInt())
    return Bitmap.createScaledBitmap(bmp, w, h, true)
}

@Composable
private fun BackgroundMedia(bg: AppBg) {
    val c = Nova.c
    val tilt = rememberTilt(bg.parallax)
    val k = bg.strength / 50f
    val layer = Modifier.fillMaxSize().graphicsLayer {
        val t = tilt.value
        val zoom = if (bg.parallax) 1.12f + 0.06f * k else 1f
        scaleX = zoom; scaleY = zoom
        translationX = t.x * size.width * 0.035f * k
        translationY = t.y * size.height * 0.025f * k
    }
    when (bg.type) {
        BgType.PHOTO -> {
            val bmp by produceState<ImageBitmap?>(null, bg.photoPath, bg.blur) {
                value = withContext(Dispatchers.IO) { decodeBackground(bg.photoPath, bg.blur)?.asImageBitmap() }
            }
            bmp?.let {
                Image(it, null, contentScale = ContentScale.Crop,
                    modifier = layer.then(if (bg.blur > 0 && Build.VERSION.SDK_INT >= 31) Modifier.blur(6.dp) else Modifier))
            }
        }
        BgType.ALBUM -> {
            val art = bg.album
            if (art != null) {
                val shown = remember(art, bg.blur) { shrinkForBlur(art, maxOf(bg.blur, 60)).asImageBitmap() }
                Image(shown, null, contentScale = ContentScale.Crop,
                    modifier = layer.then(if (Build.VERSION.SDK_INT >= 31) Modifier.blur(10.dp) else Modifier))
            }
        }
        BgType.VIDEO -> VideoBackground(bg, layer)
        BgType.NONE -> {}
    }
    Box(Modifier.fillMaxSize().background(c.bgBottom.copy(alpha = (bg.dark / 100f).coerceIn(0f, 0.95f))))
}

@Composable
private fun VideoBackground(bg: AppBg, modifier: Modifier) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val exo = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), false)
            .build().apply { repeatMode = Player.REPEAT_MODE_ONE }
    }
    LaunchedEffect(bg.videoPath) {
        exo.setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(java.io.File(bg.videoPath))))
        exo.prepare()
        exo.playWhenReady = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
    }
    LaunchedEffect(bg.videoVolume) { exo.volume = bg.videoVolume / 100f }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) exo.pause()
            if (e == Lifecycle.Event.ON_RESUME) exo.play()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); exo.release() }
    }
    AndroidView(
        factory = { c -> (LayoutInflater.from(c).inflate(R.layout.view_video, null) as PlayerView).also { it.player = exo } },
        modifier = modifier
    )
}

/** Latar: glass = gradien + cahaya bergerak; neo = warna rata + titik. Latar kustom (foto/video/album) di bawahnya. */
@Composable
fun NovaBackground(modifier: Modifier = Modifier, withMedia: Boolean = true, content: @Composable BoxScope.() -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val bg = LocalAppBg.current
    val hasMedia = withMedia && when (bg.type) {
        BgType.PHOTO -> bg.photoPath.isNotEmpty() && java.io.File(bg.photoPath).isFile
        BgType.VIDEO -> bg.videoPath.isNotEmpty() && java.io.File(bg.videoPath).isFile
        BgType.ALBUM -> bg.album != null
        BgType.NONE -> false
    }
    val t = rememberInfiniteTransition(label = "bg")
    val phase: State<Float> = if (look.animations && !look.neo)
        t.animateFloat(0f, 1f, infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    else remember { mutableFloatStateOf(0.4f) }

    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))) {
        if (hasMedia) BackgroundMedia(bg)
        Box(
            Modifier.fillMaxSize().drawBehind {
                if (look.neo) {
                    if (!hasMedia) {
                        val step = 22.dp.toPx()
                        val dot = 1.6.dp.toPx()
                        var y = step / 2
                        while (y < size.height) {
                            var x = step / 2
                            while (x < size.width) { drawCircle(c.onBg.copy(alpha = 0.10f), dot, Offset(x, y)); x += step }
                            y += step
                        }
                    }
                } else {
                    val p = phase.value
                    val w = size.width; val h = size.height
                    val k = if (hasMedia) 0.45f else 1f
                    orb(w * (0.15f + 0.3f * p), h * 0.16f, w * 0.85f, c.accent.copy(alpha = (if (c.dark) 0.20f else 0.30f) * k))
                    orb(w * (0.95f - 0.25f * p), h * 0.55f, w * 0.75f, c.accent2.copy(alpha = (if (c.dark) 0.10f else 0.22f) * k))
                    orb(w * 0.1f, h * (0.98f - 0.15f * p), w * 0.8f, c.accent.copy(alpha = (if (c.dark) 0.08f else 0.16f) * k))
                }
            }
        )
        content()
    }
}

// =============================================================== TEKS & KOMPONEN DASAR

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    val c = Nova.c
    val neo = Nova.look.neo
    Column(modifier) {
        Text(
            title, fontSize = 30.sp, color = c.onBg,
            fontWeight = if (neo) FontWeight.Black else FontWeight.Bold,
            letterSpacing = if (neo) (-0.5).sp else (-0.8).sp
        )
        if (subtitle != null) Text(subtitle, color = c.muted, fontSize = 13.sp)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    val c = Nova.c
    val neo = Nova.look.neo
    Row(modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (!neo) {
            Box(Modifier.width(3.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(Brush.verticalGradient(listOf(c.accent, c.accent2))))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text, fontSize = 19.sp, color = c.onBg, letterSpacing = (-0.3).sp,
            fontWeight = if (neo) FontWeight.Black else FontWeight.SemiBold
        )
    }
}

@Composable
fun EmptyNote(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Nova.c.muted, fontSize = 13.sp, modifier = modifier.padding(vertical = 8.dp))
}

enum class BtnKind { Primary, Secondary }

@Composable
fun NovaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    kind: BtnKind = BtnKind.Primary,
    enabled: Boolean = true
) {
    val c = Nova.c
    val look = Nova.look
    val primary = kind == BtnKind.Primary
    val radius = if (look.neo) look.radius else 16.dp
    val fg: Color
    val surface: Modifier
    if (primary) {
        fg = if (look.neo) c.onAccent else bestOn(lerp(c.accent, c.accent2, 0.5f))
        surface = if (look.neo) Modifier.panel(radius, fill = c.accent, onClick = if (enabled) onClick else null)
        else Modifier.panel(radius, brush = Brush.linearGradient(listOf(c.accent, c.accent2)), onClick = if (enabled) onClick else null)
    } else {
        fg = c.onBg
        surface = Modifier.panel(radius, onClick = if (enabled) onClick else null)
    }
    Row(
        modifier
            .then(if (primary && !look.neo && enabled) Modifier.shadow(14.dp, RoundedCornerShape(radius), ambientColor = c.accent.copy(alpha = 0.25f), spotColor = c.accent.copy(alpha = 0.55f)) else Modifier)
            .then(surface).heightIn(min = 46.dp).padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(
            text, color = fg, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            fontWeight = if (look.neo) FontWeight.Black else FontWeight.SemiBold
        )
    }
}

@Composable
fun NovaChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = Nova.c
    val look = Nova.look
    val r = if (look.neo) look.radius else 100.dp
    val fg = if (selected) c.onAccent else c.onBg
    val surf = if (selected) Modifier.panel(r, fill = c.accent, brush = if (look.neo) null else Brush.linearGradient(listOf(c.accent, c.accent2)), flat = true, onClick = onClick)
    else Modifier.panel(r, onClick = onClick)
    Text(
        label, color = fg, fontSize = 13.sp, maxLines = 1,
        fontWeight = if (selected || look.neo) FontWeight.Bold else FontWeight.Medium,
        modifier = modifier.then(surf).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun NovaSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val x by animateDpAsState(if (checked) 23.dp else 3.dp, label = "knob")
    val track = if (checked) c.accent else c.onBg.copy(alpha = 0.18f)
    Box(
        Modifier.size(50.dp, 30.dp).clip(CircleShape).background(track)
            .then(if (look.neo) Modifier.border(look.border.coerceAtMost2(), c.border, CircleShape) else Modifier)
            .clickable { onChange(!checked) },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier.offset(x = x).size(24.dp).clip(CircleShape)
                .background(if (look.neo) c.surfaceSolid else Color.White)
                .then(if (look.neo) Modifier.border(2.dp, c.border, CircleShape) else Modifier)
        )
    }
}

private fun Dp.coerceAtMost2(): Dp = if (this > 3.dp) 3.dp else this

@Composable
fun NovaField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    leading: ImageVector? = null,
    singleLine: Boolean = true,
    keyboard: KeyboardType = KeyboardType.Text,
    minHeight: Dp = 48.dp
) {
    val c = Nova.c
    Row(
        modifier.panel(radius = if (Nova.look.neo) Nova.look.radius else 16.dp, fill = if (Nova.look.neo) c.surfaceSolid else null)
            .heightIn(min = minHeight).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = if (singleLine) Alignment.CenterVertically else Alignment.Top
    ) {
        if (leading != null) { Icon(leading, null, tint = c.muted, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)) }
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = singleLine,
            textStyle = TextStyle(color = c.onBg, fontSize = 15.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(keyboardType = keyboard),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box { if (value.isEmpty()) Text(placeholder, color = c.muted, fontSize = 15.sp); inner() }
            }
        )
        if (value.isNotEmpty() && singleLine) {
            Icon(Icons.Rounded.Close, null, tint = c.muted, modifier = Modifier.size(20.dp).clip(CircleShape).clickable { onChange("") })
        }
    }
}

@Composable
fun NovaDialog(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String? = null,
    onConfirm: (() -> Unit)? = null,
    dismissText: String? = "Batal",
    content: @Composable ColumnScope.() -> Unit
) {
    val c = Nova.c
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().panel(fill = c.surfaceSolid).padding(20.dp)) {
            Text(title, color = c.onBg, fontSize = 20.sp, fontWeight = if (Nova.look.neo) FontWeight.Black else FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            content()
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                if (dismissText != null) NovaButton(dismissText, onDismiss, kind = BtnKind.Secondary)
                if (confirmText != null && onConfirm != null) NovaButton(confirmText, onConfirm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SheetHost(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val top = if (look.neo) look.radius else (look.radius + 6.dp)
    ModalBottomSheet(
        onDismissRequest = onDismiss, containerColor = c.surfaceSolid, contentColor = c.onBg,
        shape = RoundedCornerShape(topStart = top, topEnd = top)
    ) {
        if (look.neo) Box(Modifier.fillMaxWidth().height(look.border).background(c.border))
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            Text(title, fontSize = 20.sp, color = c.onBg, fontWeight = if (look.neo) FontWeight.Black else FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

// =============================================================== NAVIGASI

data class NavItem(val label: String, val icon: ImageVector)

// =============================================================== COVER & DAFTAR LAGU

@Composable
fun artShape(radius: Dp = 14.dp): Shape = when (Nova.look.artShape) {
    ArtShape.CIRCLE -> CircleShape
    ArtShape.SQUARE -> RoundedCornerShape(2.dp)
    ArtShape.ROUNDED -> RoundedCornerShape(radius)
}

@Composable
fun Artwork(song: Song?, modifier: Modifier = Modifier, shape: Shape = artShape(), big: Boolean = false) {
    val ctx = LocalContext.current
    val c = Nova.c
    val look = Nova.look
    val bmp by produceState<ImageBitmap?>(song?.let { ArtLoader.peek(it, big)?.asImageBitmap() }, song?.id, big) {
        value = if (song == null) null else withContext(Dispatchers.IO) { ArtLoader.load(ctx, song, big)?.asImageBitmap() }
    }
    Box(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(c.accent.copy(alpha = 0.26f), Color(0xFF0E0E10), c.accent2.copy(alpha = 0.18f))))
            .then(if (look.neo) Modifier.border(2.dp, c.border, shape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.nova_logo), null, alpha = 0.9f, modifier = Modifier.fillMaxSize(0.52f))
        bmp?.let { Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
    }
}

@Composable
fun EqBars(modifier: Modifier = Modifier, color: Color = Color.White) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(modifier.height(18.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        listOf(380, 520, 450).forEach { d ->
            val h by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(d, easing = LinearEasing), RepeatMode.Reverse), label = "b")
            Box(Modifier.width(4.dp).fillMaxHeight(h).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

@Composable
fun SongRow(vm: MusicViewModel, song: Song, onClick: () -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val current by vm.current.collectAsState()
    val playing by vm.isPlaying.collectAsState()
    val favs by vm.favorites.collectAsState()
    val isCur = current?.id == song.id
    var menu by remember { mutableStateOf(false) }
    var addDlg by remember { mutableStateOf(false) }
    var editDlg by remember { mutableStateOf(false) }
    val artSize = if (look.compact) 40.dp else 52.dp
    val onRow = if (isCur && look.neo) c.onAccent else c.onBg
    val onRowMuted = if (isCur && look.neo) c.onAccent.copy(alpha = 0.75f) else c.muted
    val fill: Color? = if (isCur) (if (look.neo) c.accent else c.accent.copy(alpha = 0.22f)) else if (look.neo) c.surfaceSolid else null

    Row(
        Modifier.fillMaxWidth().padding(vertical = if (look.neo) 3.dp else 0.dp)
            .panel(radius = if (look.neo) look.radius else 16.dp, fill = fill, flat = true, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = if (look.compact) 4.dp else 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (look.showArt) {
            Box(contentAlignment = Alignment.Center) {
                Artwork(song, Modifier.size(artSize))
                if (isCur && playing) {
                    Box(Modifier.size(artSize).clip(artShape()).background(Color.Black.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) { EqBars() }
                }
            }
            Spacer(Modifier.width(12.dp))
        } else if (isCur && playing) {
            EqBars(Modifier.padding(end = 10.dp), onRow)
        }
        Column(Modifier.weight(1f)) {
            Text(song.title, color = onRow, fontWeight = if (look.neo) FontWeight.Bold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.artist} • ${fmt(song.duration)}", color = onRowMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (song.id in favs) Icon(Icons.Rounded.Favorite, null, tint = Heart, modifier = Modifier.size(18.dp))
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null, tint = onRowMuted) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Putar berikutnya") }, leadingIcon = { Icon(Icons.Rounded.SkipNext, null) }, onClick = { vm.playNext(song); menu = false })
                DropdownMenuItem(text = { Text("Tambah ke antrean") }, leadingIcon = { Icon(Icons.Rounded.QueueMusic, null) }, onClick = { vm.addToQueue(song); menu = false })
                DropdownMenuItem(
                    text = { Text(if (song.id in favs) "Hapus dari favorit" else "Tambah ke favorit") },
                    leadingIcon = { Icon(Icons.Rounded.FavoriteBorder, null) },
                    onClick = { vm.toggleFavorite(song); menu = false }
                )
                DropdownMenuItem(text = { Text("Tambah ke playlist") }, leadingIcon = { Icon(Icons.Rounded.PlaylistAdd, null) }, onClick = { addDlg = true; menu = false })
                DropdownMenuItem(text = { Text("Tambah lagu mirip") }, leadingIcon = { Icon(Icons.Rounded.AutoAwesome, null) }, onClick = { vm.addSimilar(song); menu = false })
                DropdownMenuItem(text = { Text("Edit info lagu") }, leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { editDlg = true; menu = false })
            }
        }
    }
    if (addDlg) AddToPlaylistDialog(vm, song) { addDlg = false }
    if (editDlg) EditMetaDialog(vm, song) { editDlg = false }
}

@Composable
fun EditMetaDialog(vm: MusicViewModel, song: Song, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(song.title) }
    var artist by remember { mutableStateOf(if (song.artist.startsWith("Artis tidak")) "" else song.artist) }
    var album by remember { mutableStateOf(if (song.album.startsWith("Album tidak")) "" else song.album) }
    NovaDialog("Edit info lagu", onDismiss, "Simpan", { vm.editMeta(song, title, artist, album); onDismiss() }) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            NovaField(title, { title = it }, "Judul", Modifier.fillMaxWidth())
            NovaField(artist, { artist = it }, "Artis", Modifier.fillMaxWidth())
            NovaField(album, { album = it }, "Album", Modifier.fillMaxWidth())
            Text("Perubahan disimpan di NovaMusic (file lagu aslinya tidak diubah).", color = Nova.c.muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun AddToPlaylistDialog(vm: MusicViewModel, song: Song, onDismiss: () -> Unit) {
    val c = Nova.c
    val pls by vm.playlists.collectAsState()
    NovaDialog("Tambah ke playlist", onDismiss, dismissText = "Tutup") {
        if (pls.isEmpty()) Text("Belum ada playlist. Buat dulu di tab Playlist.", color = c.muted)
        pls.keys.forEach { name ->
            Text(
                name, color = c.onBg, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .clickable { vm.addToPlaylist(name, song); onDismiss() }.padding(vertical = 12.dp, horizontal = 6.dp)
            )
        }
    }
}

@Composable
fun SongCard(song: Song, onClick: () -> Unit) {
    val c = Nova.c
    Column(Modifier.width(140.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        Artwork(song, Modifier.size(140.dp), artShape(18.dp))
        Spacer(Modifier.height(6.dp))
        Text(song.title, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        Text(song.artist, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
    }
}

@Composable
fun MiniPlayer(vm: MusicViewModel, onOpen: () -> Unit) {
    val c = Nova.c
    val look = Nova.look
    val song by vm.current.collectAsState()
    val playing by vm.isPlaying.collectAsState()
    val pos by vm.position.collectAsState()
    val dur by vm.duration.collectAsState()
    val s = song ?: return
    Column(
        Modifier.padding(horizontal = 12.dp, vertical = 6.dp).fillMaxWidth()
            .panel(radius = if (look.neo) look.radius else 22.dp, fill = c.surfaceSolid.copy(alpha = if (look.neo) 1f else 0.9f), onClick = onOpen)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(s, Modifier.size(44.dp), if (look.neo) RoundedCornerShape(look.radius.coerceAtMost(12.dp)) else CircleShape)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(s.title, color = c.onBg, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                Text(s.artist, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
            }
            IconButton(onClick = { vm.prev() }) { Icon(Icons.Rounded.SkipPrevious, null, tint = c.onBg) }
            IconButton(onClick = { vm.toggle() }) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = c.onBg, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, null, tint = c.onBg) }
        }
        val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(3.dp).background(c.onBg.copy(alpha = 0.12f))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Brush.horizontalGradient(listOf(c.accent, c.accent2))))
        }
    }
}
