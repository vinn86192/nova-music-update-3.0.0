package com.base.musicapp.data

import android.content.Context
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

enum class UiStyle(val label: String) {
    GLASS("Glassmorphism"), NEO("Neobrutalism")
}

enum class ThemeMode(val label: String) {
    DARK("Gelap"), LIGHT("Terang"), SYSTEM("Sistem")
}

enum class ArtShape(val label: String) {
    ROUNDED("Membulat"), CIRCLE("Lingkaran"), SQUARE("Kotak")
}

enum class BgType(val label: String) {
    NONE("Bawaan"), PHOTO("Foto"), VIDEO("Video"), ALBUM("Album")
}

enum class PlayerLayout(val label: String) {
    CLASSIC("Klasik"), VINYL("Vinyl"), COMPACT("Kompak"), MINIMAL("Minimal")
}

enum class NowEffect(val label: String) {
    NONE("Tanpa"), PULSE("Napas"), GLOW("Glow"), STARS("Bintang")
}

enum class Palette(val label: String, val accent: Color, val accent2: Color) {
    NOVA("Nova", Color(0xFFFF9A1F), Color(0xFFF26A00)),
    GALAXY("Galaxy", Color(0xFF8B7CFF), Color(0xFF3DD6FF)),
    OCEAN("Ocean", Color(0xFF3B82F6), Color(0xFF22D3EE)),
    SUNSET("Sunset", Color(0xFFFF7A45), Color(0xFFFFC857)),
    EMERALD("Emerald", Color(0xFF1ED760), Color(0xFFA3E635)),
    ROSE("Rose", Color(0xFFFF5FA2), Color(0xFFC084FC)),
    MONO("Mono", Color(0xFFE5E5E5), Color(0xFF9CA3AF)),
    CUSTOM("Kustom", Color(0xFF8B7CFF), Color(0xFF3DD6FF))
}

/** Semua angka disimpan sebagai Int (persen / dp) supaya cadangan JSON aman. */
data class AppSettings(
    // Gaya & tema
    val style: UiStyle = UiStyle.GLASS,
    val palette: Palette = Palette.NOVA,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val glassOpacity: Int = 10,
    val glassRadius: Int = 22,
    val neoRadius: Int = 10,
    val neoBorder: Int = 3,
    val neoShadow: Int = 5,
    val animations: Boolean = true,
    // Tipografi & daftar
    val fontScale: Int = 100,
    val compactList: Boolean = false,
    val showArt: Boolean = true,
    val artShape: ArtShape = ArtShape.ROUNDED,
    val blurNowPlaying: Boolean = true,
    // Beranda
    val userName: String = "",
    val showStats: Boolean = true,
    val showRecents: Boolean = true,
    val showLatest: Boolean = true,
    val showFavs: Boolean = true,
    val homeSongLimit: Int = 40,
    // Pemutaran & library
    val resumeQueue: Boolean = true,
    val skipSilence: Boolean = false,
    val pauseOnNoisy: Boolean = true,
    val audioFocus: Boolean = true,
    val defaultSort: SortMode = SortMode.TITLE,
    val minDurationSec: Int = 30,
    // Spotify
    val matchLevel: Int = 1,
    // Latar & personalisasi
    val bgType: BgType = BgType.NONE,
    val bgPhotoPath: String = "",
    val bgVideoPath: String = "",
    val bgBlur: Int = 0,
    val bgDark: Int = 35,
    val bgVideoVolume: Int = 0,
    val bgParallax: Boolean = false,
    val bgParallaxStrength: Int = 50,
    val dynamicColor: Boolean = false,
    val themeId: String = "",
    val playerLayout: PlayerLayout = PlayerLayout.CLASSIC,
    val nowEffect: NowEffect = NowEffect.NONE,
    val gestures: Boolean = true,
    val appIcon: String = "galaxy",
    // Lirik
    val lyricsAuto: Boolean = true,
    val lyricsTranslate: Boolean = false,
    val lyricsLang: String = "id",
    // Audio
    val crossfadeSec: Int = 0,
    val fadeOnPause: Boolean = true,
    val fadeMs: Int = 400,
    val smartQueue: Boolean = false,
    val autoPlayHeadset: Boolean = false,
    // Pengingat
    val reminderOn: Boolean = false,
    val reminderHour: Int = 20,
    val reminderMin: Int = 0
)

private val LOCAL_ONLY = setOf("bgPhotoPath", "bgVideoPath", "appIcon")

class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
    val state = MutableStateFlow(load())

    private inline fun <reified E : Enum<E>> enumOf(key: String, def: E): E =
        runCatching { enumValueOf<E>(sp.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    private fun load(): AppSettings {
        val d = AppSettings()
        return runCatching {
            AppSettings(
                style = enumOf("style", d.style),
                palette = enumOf("palette", d.palette),
                themeMode = enumOf("themeMode", d.themeMode),
                glassOpacity = sp.getInt("glassOpacity", d.glassOpacity),
                glassRadius = sp.getInt("glassRadius", d.glassRadius),
                neoRadius = sp.getInt("neoRadius", d.neoRadius),
                neoBorder = sp.getInt("neoBorder", d.neoBorder),
                neoShadow = sp.getInt("neoShadow", d.neoShadow),
                animations = sp.getBoolean("animations", d.animations),
                fontScale = sp.getInt("fontScale", d.fontScale),
                compactList = sp.getBoolean("compactList", d.compactList),
                showArt = sp.getBoolean("showArt", d.showArt),
                artShape = enumOf("artShape", d.artShape),
                blurNowPlaying = sp.getBoolean("blurNowPlaying", d.blurNowPlaying),
                userName = sp.getString("userName", d.userName) ?: "",
                showStats = sp.getBoolean("showStats", d.showStats),
                showRecents = sp.getBoolean("showRecents", d.showRecents),
                showLatest = sp.getBoolean("showLatest", d.showLatest),
                showFavs = sp.getBoolean("showFavs", d.showFavs),
                homeSongLimit = sp.getInt("homeSongLimit", d.homeSongLimit),
                resumeQueue = sp.getBoolean("resumeQueue", d.resumeQueue),
                skipSilence = sp.getBoolean("skipSilence", d.skipSilence),
                pauseOnNoisy = sp.getBoolean("pauseOnNoisy", d.pauseOnNoisy),
                audioFocus = sp.getBoolean("audioFocus", d.audioFocus),
                defaultSort = enumOf("defaultSort", d.defaultSort),
                minDurationSec = sp.getInt("minDurationSec", d.minDurationSec),
                matchLevel = sp.getInt("matchLevel", d.matchLevel),
                bgType = enumOf("bgType", d.bgType),
                bgPhotoPath = sp.getString("bgPhotoPath", "") ?: "",
                bgVideoPath = sp.getString("bgVideoPath", "") ?: "",
                bgBlur = sp.getInt("bgBlur", d.bgBlur),
                bgDark = sp.getInt("bgDark", d.bgDark),
                bgVideoVolume = sp.getInt("bgVideoVolume", d.bgVideoVolume),
                bgParallax = sp.getBoolean("bgParallax", d.bgParallax),
                bgParallaxStrength = sp.getInt("bgParallaxStrength", d.bgParallaxStrength),
                dynamicColor = sp.getBoolean("dynamicColor", d.dynamicColor),
                themeId = sp.getString("themeId", "") ?: "",
                playerLayout = enumOf("playerLayout", d.playerLayout),
                nowEffect = enumOf("nowEffect", d.nowEffect),
                gestures = sp.getBoolean("gestures", d.gestures),
                appIcon = sp.getString("appIcon", d.appIcon) ?: "galaxy",
                lyricsAuto = sp.getBoolean("lyricsAuto", d.lyricsAuto),
                lyricsTranslate = sp.getBoolean("lyricsTranslate", d.lyricsTranslate),
                lyricsLang = sp.getString("lyricsLang", d.lyricsLang) ?: "id",
                crossfadeSec = sp.getInt("crossfadeSec", d.crossfadeSec),
                fadeOnPause = sp.getBoolean("fadeOnPause", d.fadeOnPause),
                fadeMs = sp.getInt("fadeMs", d.fadeMs),
                smartQueue = sp.getBoolean("smartQueue", d.smartQueue),
                autoPlayHeadset = sp.getBoolean("autoPlayHeadset", d.autoPlayHeadset),
                reminderOn = sp.getBoolean("reminderOn", d.reminderOn),
                reminderHour = sp.getInt("reminderHour", d.reminderHour),
                reminderMin = sp.getInt("reminderMin", d.reminderMin)
            )
        }.getOrDefault(d)
    }

    private fun save(s: AppSettings) {
        sp.edit()
            .putString("style", s.style.name)
            .putString("palette", s.palette.name)
            .putString("themeMode", s.themeMode.name)
            .putInt("glassOpacity", s.glassOpacity)
            .putInt("glassRadius", s.glassRadius)
            .putInt("neoRadius", s.neoRadius)
            .putInt("neoBorder", s.neoBorder)
            .putInt("neoShadow", s.neoShadow)
            .putBoolean("animations", s.animations)
            .putInt("fontScale", s.fontScale)
            .putBoolean("compactList", s.compactList)
            .putBoolean("showArt", s.showArt)
            .putString("artShape", s.artShape.name)
            .putBoolean("blurNowPlaying", s.blurNowPlaying)
            .putString("userName", s.userName)
            .putBoolean("showStats", s.showStats)
            .putBoolean("showRecents", s.showRecents)
            .putBoolean("showLatest", s.showLatest)
            .putBoolean("showFavs", s.showFavs)
            .putInt("homeSongLimit", s.homeSongLimit)
            .putBoolean("resumeQueue", s.resumeQueue)
            .putBoolean("skipSilence", s.skipSilence)
            .putBoolean("pauseOnNoisy", s.pauseOnNoisy)
            .putBoolean("audioFocus", s.audioFocus)
            .putString("defaultSort", s.defaultSort.name)
            .putInt("minDurationSec", s.minDurationSec)
            .putInt("matchLevel", s.matchLevel)
            .putString("bgType", s.bgType.name)
            .putString("bgPhotoPath", s.bgPhotoPath)
            .putString("bgVideoPath", s.bgVideoPath)
            .putInt("bgBlur", s.bgBlur)
            .putInt("bgDark", s.bgDark)
            .putInt("bgVideoVolume", s.bgVideoVolume)
            .putBoolean("bgParallax", s.bgParallax)
            .putInt("bgParallaxStrength", s.bgParallaxStrength)
            .putBoolean("dynamicColor", s.dynamicColor)
            .putString("themeId", s.themeId)
            .putString("playerLayout", s.playerLayout.name)
            .putString("nowEffect", s.nowEffect.name)
            .putBoolean("gestures", s.gestures)
            .putString("appIcon", s.appIcon)
            .putBoolean("lyricsAuto", s.lyricsAuto)
            .putBoolean("lyricsTranslate", s.lyricsTranslate)
            .putString("lyricsLang", s.lyricsLang)
            .putInt("crossfadeSec", s.crossfadeSec)
            .putBoolean("fadeOnPause", s.fadeOnPause)
            .putInt("fadeMs", s.fadeMs)
            .putBoolean("smartQueue", s.smartQueue)
            .putBoolean("autoPlayHeadset", s.autoPlayHeadset)
            .putBoolean("reminderOn", s.reminderOn)
            .putInt("reminderHour", s.reminderHour)
            .putInt("reminderMin", s.reminderMin)
            .apply()
    }

    fun update(block: (AppSettings) -> AppSettings) {
        val n = block(state.value)
        state.value = n
        save(n)
    }

    fun reset() {
        sp.edit().clear().apply()
        state.value = AppSettings()
    }

    fun exportJson(): JSONObject {
        val o = JSONObject()
        sp.all.forEach { (k, v) ->
            if (k !in LOCAL_ONLY && (v is Boolean || v is Int || v is String)) o.put(k, v)
        }
        return o
    }

    fun importJson(o: JSONObject) {
        val e = sp.edit()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in LOCAL_ONLY) continue
            when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is String -> e.putString(k, v)
            }
        }
        e.apply()
        state.value = load()
    }
}
