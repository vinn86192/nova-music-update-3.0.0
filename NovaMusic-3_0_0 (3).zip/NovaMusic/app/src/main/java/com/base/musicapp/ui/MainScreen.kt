package com.base.musicapp.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.material.icons.outlined.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.base.musicapp.data.Detail
import com.base.musicapp.player.MusicViewModel

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Beranda", Icons.Outlined.Home),
    LIBRARY("Library", Icons.Outlined.LibraryMusic),
    SEARCH("Cari", Icons.Outlined.Search),
    PLAYLIST("Playlist", Icons.Outlined.QueueMusic),
    SETTINGS("Setting", Icons.Outlined.Settings)
}

private fun SnapshotStateList<Page>.pop() { if (isNotEmpty()) removeAt(lastIndex) }

@Composable
fun MainScreen(vm: MusicViewModel) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showNow by remember { mutableStateOf(false) }
    var spotifyId by remember { mutableStateOf<String?>(null) }
    val pages = remember { mutableStateListOf<Page>() }
    val song by vm.current.collectAsState()
    val share by vm.pendingSpotifyShare.collectAsState()
    val navItems = remember { Tab.values().map { NavItem(it.label, it.icon) } }

    // tautan Spotify yang dibagikan dari aplikasi Spotify -> langsung buka layar import
    LaunchedEffect(share) {
        if (share != null && pages.lastOrNull() != Page.SPOTIFY) { showNow = false; detail = null; spotifyId = null; pages.add(Page.SPOTIFY) }
    }

    BackHandler(showNow) { showNow = false }
    BackHandler(!showNow && pages.isNotEmpty()) { pages.pop() }
    BackHandler(!showNow && pages.isEmpty() && spotifyId != null) { spotifyId = null }
    BackHandler(!showNow && pages.isEmpty() && spotifyId == null && detail != null) { detail = null }

    val back: () -> Unit = { pages.pop() }
    val open: (Page) -> Unit = { pages.add(it) }

    NovaBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                Column(Modifier.navigationBarsPadding()) {
                    if (song != null) MiniPlayer(vm) { showNow = true }
                    NovaNavBar(navItems, tab.ordinal) { tab = Tab.values()[it]; detail = null; spotifyId = null; pages.clear() }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).statusBarsPadding()) {
                val d = detail
                val sid = spotifyId
                val page = pages.lastOrNull()
                when {
                    page != null -> when (page) {
                        Page.SPOTIFY -> SpotifyImportScreen(vm, back)
                        Page.ALBUM_IMPORT -> AlbumImportScreen(vm, back) { pages.pop(); pages.add(Page.ALBUM) }
                        Page.ALBUM -> LocalAlbumScreen(vm, back) { pages.pop(); pages.add(Page.ALBUM_IMPORT) }
                        Page.STATS -> StatsScreen(vm, back)
                        Page.SMART -> SmartHubScreen(vm, back, open)
                        Page.MOODS -> MoodScreen(vm, back)
                        Page.GENERATOR -> GeneratorScreen(vm, back)
                        Page.DUPES -> DuplicatesScreen(vm, back)
                        Page.META -> MetadataScreen(vm, back)
                        Page.FOLDERS -> FoldersScreen(vm, back)
                        Page.TIMELINE -> TimelineScreen(vm, back)
                        Page.FAVARTISTS -> FavArtistsScreen(vm, back) { pages.clear(); detail = it }
                        Page.THEMES -> ThemeStudioScreen(vm, back)
                        Page.ABOUT -> AboutScreen(vm, back)
                    }
                    d != null -> DetailScreen(vm, d) { detail = null }
                    sid != null -> SpotifyDetailScreen(vm, sid) { spotifyId = null }
                    else -> AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            val dir = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                            (slideInHorizontally(tween(360, easing = FastOutSlowInEasing)) { it / 10 * dir } + fadeIn(tween(300, delayMillis = 60))) togetherWith
                                (slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it / 14 * dir } + fadeOut(tween(160)))
                        },
                        label = "tabs"
                    ) { t ->
                        when (t) {
                            Tab.HOME -> HomeScreen(vm, { detail = it }, open)
                            Tab.LIBRARY -> LibraryScreen(vm) { detail = it }
                            Tab.SEARCH -> SearchScreen(vm)
                            Tab.PLAYLIST -> PlaylistsScreen(
                                vm, { detail = it }, { pages.add(Page.SPOTIFY) }, { spotifyId = it },
                                { pages.add(Page.ALBUM_IMPORT) }, { pages.add(Page.ALBUM) }
                            )
                            Tab.SETTINGS -> SettingsScreen(vm, open)
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showNow && song != null,
            enter = slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(340, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(240))
        ) {
            NowPlayingScreen(vm) { showNow = false }
        }
    }
}
